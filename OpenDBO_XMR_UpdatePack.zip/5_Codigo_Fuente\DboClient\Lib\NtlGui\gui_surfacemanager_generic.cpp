#include "gui_precomp.h"
#include "gui_surfacemanager_generic.h"
#include "gui_surfacefilepaser.h"
#include "gui_surfacemanager.h"
#include "gui_resourcemanager.h"
#include "Commdlg.h"


START_GUI


CSurfaceManager_Generic::CSurfaceManager_Generic()
: m_nRefCount(0)
{
}


CSurfaceManager_Generic::~CSurfaceManager_Generic()
{
	CSurfacePage *pPage;
	std::map<std::string,CSurfacePage*>::iterator the;
	for(the=m_stlPage.begin() ; 
			the!=m_stlPage.end() ; 
			the++)
			{
				pPage = (*the).second;

				NTL_DELETE( pPage );
			}

	m_stlPage.clear();
}



static std::string NormalizeSurfacePageKey(const std::string& str)
{
	std::string key = str;
	size_t nPos = str.find_last_of("\\/");
	if (nPos != std::string::npos)
	{
		key = str.substr(nPos + 1);
	}
	for (size_t i = 0; i < key.size(); ++i)
	{
		key[i] = (char)tolower((unsigned char)key[i]);
	}
	return key;
}

bool CSurfaceManager_Generic::AddPage(const std::string& str)
{
	CSurfacePage *pPage;
	std::map<std::string,CSurfacePage*>::iterator it;
	std::string key = NormalizeSurfacePageKey(str);

	it = m_stlPageKey.find(key);
	if(it != m_stlPageKey.end())
	{
		pPage = (*it).second;
		pPage->AddRef();
		return true;
	}

	it = m_stlPage.find(str);
	if(it != m_stlPage.end())
	{
		pPage = (*it).second;
		pPage->AddRef(); 
		return true;
	}

	pPage = NTL_NEW CSurfacePage(str);
	pPage->AddRef(); 

	m_stlPage.insert(std::map<std::string,CSurfacePage*>::value_type(str,pPage));
	m_stlPageKey.insert(std::map<std::string,CSurfacePage*>::value_type(key,pPage));

	return true;
}

VOID CSurfaceManager_Generic::RemovePage(const std::string& str)
{
	std::string key = NormalizeSurfacePageKey(str);
	std::map<std::string,CSurfacePage*>::iterator itKey = m_stlPageKey.find(key);
	std::map<std::string,CSurfacePage*>::iterator it = m_stlPage.find(str);

	CSurfacePage* pPage = NULL;
	if(itKey != m_stlPageKey.end())
		pPage = (*itKey).second;
	else if(it != m_stlPage.end())
		pPage = (*it).second;
	else
		return;

	if(pPage->ReleaseRef() > 0)
		return;

	if(it != m_stlPage.end() && (*it).second == pPage)
	{
		m_stlPage.erase(it);
	}
	else
	{
		for(std::map<std::string,CSurfacePage*>::iterator itPage = m_stlPage.begin(); itPage != m_stlPage.end(); )
		{
			if((*itPage).second == pPage)
				itPage = m_stlPage.erase(itPage);
			else
				++itPage;
		}
	}

	if(itKey != m_stlPageKey.end())
		m_stlPageKey.erase(itKey);

	NTL_DELETE( pPage );
}

CSurfacePage* CSurfaceManager_Generic::GetPage(const std::string& str)
{
	std::map<std::string,CSurfacePage*>::iterator it;	
	std::string key = NormalizeSurfacePageKey(str);

	it = m_stlPageKey.find( key );
	if( it == m_stlPageKey.end() )
		return NULL;

	return (*it).second;

}

END_GUI

