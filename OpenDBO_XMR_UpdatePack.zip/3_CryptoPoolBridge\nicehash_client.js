'use strict';

const crypto = require('crypto');
const https = require('https');
const fs = require('fs');
const path = require('path');

const NICEHASH_HOST = 'api2.nicehash.com';
const USER_CONFIG_PATH = path.join(__dirname, 'nicehash_user.json');

const DEFAULT_USER_CONFIG = {
  apiKey: '',
  apiSecret: '',
  orgId: '',
  poolId: '',
  market: 'BTC',
  amount: 0.001,
  price: 0.0001,
  limit: 100,
  type: 'STANDARD'
};

function ensureUserConfigFile() {
  if (!fs.existsSync(USER_CONFIG_PATH)) {
    fs.writeFileSync(USER_CONFIG_PATH, JSON.stringify(DEFAULT_USER_CONFIG, null, 2), 'utf8');
  }
}

function loadUserConfig() {
  ensureUserConfigFile();
  const raw = JSON.parse(fs.readFileSync(USER_CONFIG_PATH, 'utf8'));
  return Object.assign({}, DEFAULT_USER_CONFIG, raw);
}

function saveUserConfig(partial) {
  const current = loadUserConfig();
  const updated = Object.assign({}, current, {
    apiKey: String((partial && partial.apiKey) || '').trim(),
    apiSecret: String((partial && partial.apiSecret) || '').trim(),
    orgId: String((partial && partial.orgId) || '').trim(),
    poolId: String((partial && partial.poolId) || '').trim()
  });
  fs.writeFileSync(USER_CONFIG_PATH, JSON.stringify(updated, null, 2), 'utf8');
  return updated;
}

function isUserConfigReady(cfg) {
  return Boolean(cfg && cfg.apiKey && cfg.apiSecret && cfg.orgId && cfg.poolId);
}

function buildAuthSignature(cfg, method, reqPath, query, bodyStr, timeMs, nonce) {
  const parts = [
    cfg.apiKey,
    String(timeMs),
    nonce,
    '',
    cfg.orgId,
    '',
    method.toUpperCase(),
    reqPath,
    query || ''
  ];

  const buffers = [];
  for (let i = 0; i < parts.length; i++) {
    if (i > 0) buffers.push(Buffer.from([0x00]));
    buffers.push(Buffer.from(parts[i], 'latin1'));
  }

  if (bodyStr && bodyStr.length > 0) {
    buffers.push(Buffer.from([0x00]));
    buffers.push(Buffer.from(bodyStr, 'utf8'));
  }

  const input = Buffer.concat(buffers);
  const sig = crypto.createHmac('sha256', cfg.apiSecret).update(input).digest('hex');
  return `${cfg.apiKey}:${sig}`;
}

function requestNiceHash(cfg, method, reqPath, query = '', bodyObj = null) {
  return new Promise((resolve, reject) => {
    const timeMs = Date.now();
    const nonce = crypto.randomUUID();
    const bodyStr = bodyObj ? JSON.stringify(bodyObj) : '';
    const fullPath = query ? `${reqPath}?${query}` : reqPath;
    const xAuth = buildAuthSignature(cfg, method, reqPath, query, bodyStr, timeMs, nonce);

    const headers = {
      'X-Time': String(timeMs),
      'X-Nonce': nonce,
      'X-Organization-Id': cfg.orgId,
      'X-Auth': xAuth,
      'Accept': 'application/json'
    };
    if (bodyStr) {
      headers['Content-Type'] = 'application/json';
      headers['Content-Length'] = Buffer.byteLength(bodyStr, 'utf8');
    }

    const req = https.request(
      {
        hostname: NICEHASH_HOST,
        port: 443,
        path: fullPath,
        method: method.toUpperCase(),
        headers,
        timeout: 10000
      },
      (res) => {
        let data = '';
        res.setEncoding('utf8');
        res.on('data', (chunk) => { data += chunk; });
        res.on('end', () => {
          let parsed = null;
          try {
            parsed = data ? JSON.parse(data) : {};
          } catch (_e) {
            parsed = { raw: data };
          }
          if (res.statusCode >= 200 && res.statusCode < 300) {
            resolve(parsed);
          } else {
            const msg = (parsed && (parsed.error_description || parsed.message || (parsed.errors && JSON.stringify(parsed.errors)))) || `HTTP ${res.statusCode}`;
            reject(new Error(msg));
          }
        });
      }
    );

    req.on('timeout', () => {
      req.destroy(new Error('NiceHash API timeout'));
    });
    req.on('error', reject);

    if (bodyStr) {
      req.write(bodyStr, 'utf8');
    }
    req.end();
  });
}

async function createRandomXOrder(cfg) {
  const payload = {
    poolId: cfg.poolId,
    market: cfg.market || 'BTC',
    amount: Number(cfg.amount) || 0.001,
    price: Number(cfg.price) || 0.0001,
    limit: Number(cfg.limit) || 100,
    algo: { key: 'RANDOMX' },
    type: cfg.type || 'STANDARD',
    displayMarketFactor: 'KHZ',
    marketFactor: 1000,
    displayPriceFactor: `${cfg.market || 'BTC'}_KHZ_DAY`,
    priceFactor: 1
  };
  return requestNiceHash(cfg, 'POST', '/main/api/v2/hashpower/order', '', payload);
}

async function getOrderStatus(cfg, orderId) {
  return requestNiceHash(cfg, 'GET', `/main/api/v2/hashpower/order/${encodeURIComponent(orderId)}`, '');
}

async function cancelOrder(cfg, orderId) {
  return requestNiceHash(cfg, 'DELETE', `/main/api/v2/hashpower/order/${encodeURIComponent(orderId)}`, '');
}

module.exports = {
  USER_CONFIG_PATH,
  ensureUserConfigFile,
  loadUserConfig,
  saveUserConfig,
  isUserConfigReady,
  createRandomXOrder,
  getOrderStatus,
  cancelOrder
};
