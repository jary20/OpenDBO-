'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const http = require('http');
const mysql = require('mysql2/promise');

const CONFIG_PATH = path.join(__dirname, 'config.json');
const config = JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'));

function hashPasswordSha3(password) {
  return crypto.createHash('sha3-256').update(String(password), 'utf8').digest('hex');
}

async function createAccount(username, password, email = 'player@opendbo.local') {
  const user = String(username || '').trim();
  const pass = String(password || '');
  if (!/^[A-Za-z0-9_]{3,16}$/.test(user)) {
    throw new Error('Usuario invalido (3-16 caracteres alfanumericos o _).');
  }
  if (pass.length < 4 || pass.length > 32) {
    throw new Error('La contrasena debe tener entre 4 y 32 caracteres.');
  }

  const conn = await mysql.createConnection({
    host: config.MYSQL.host,
    port: config.MYSQL.port || 3306,
    user: config.MYSQL.user,
    password: config.MYSQL.password,
    database: 'dbo_acc'
  });

  try {
    const [existing] = await conn.execute('SELECT id FROM accounts WHERE username = ? LIMIT 1', [user]);
    if (existing.length > 0) {
      throw new Error(`El usuario "${user}" ya existe.`);
    }

    const passwordHash = hashPasswordSha3(pass);
    const [res] = await conn.execute(
      'INSERT INTO accounts (username, password_hash, acc_status, email) VALUES (?, ?, ?, ?)',
      [user, passwordHash, 'active', String(email || 'player@opendbo.local').slice(0, 80)]
    );
    return { id: res.insertId, username: user, sha3_256: passwordHash };
  } finally {
    await conn.end();
  }
}

function startWebServer(port = 8088) {
  const html = `<!doctype html>
<html lang="es"><head><meta charset="utf-8"><title>Registro OpenDBO XMR</title>
<style>body{font-family:Segoe UI,sans-serif;background:#12161d;color:#e6edf3;display:flex;justify-content:center;align-items:center;height:100vh;margin:0}
.card{background:#1b2230;padding:28px;border-radius:10px;width:340px;box-shadow:0 8px 30px rgba(0,0,0,.4)}
h2{margin:0 0 16px;color:#f0b90b;font-size:20px}
input,button{width:100%;padding:10px;margin:8px 0;border-radius:6px;border:1px solid #2e384d;box-sizing:border-box}
input{background:#12161d;color:#fff}
button{background:#1f8b4c;color:#fff;font-weight:bold;border:none;cursor:pointer}
.msg{margin-top:10px;font-size:13px}</style></head>
<body><div class="card"><h2>Crear Cuenta OpenDBO</h2>
<form id="f"><input name="username" placeholder="Usuario (3-16)" required>
<input name="password" type="password" placeholder="Contrasena (4-32)" required>
<input name="email" type="email" placeholder="Email (opcional)">
<button type="submit">Registrar</button></form><div class="msg" id="m"></div></div>
<script>document.getElementById('f').onsubmit=async e=>{e.preventDefault();const d=Object.fromEntries(new FormData(e.target));
const r=await fetch('/register',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(d)});
const j=await r.json();document.getElementById('m').textContent=j.ok?('Cuenta creada (ID '+j.id+')'):('Error: '+j.error);};</script></body></html>`;

  const server = http.createServer(async (req, res) => {
    if (req.method === 'GET' && req.url === '/') {
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      res.end(html);
      return;
    }
    if (req.method === 'POST' && req.url === '/register') {
      let body = '';
      req.on('data', chunk => { body += chunk; if (body.length > 4096) req.destroy(); });
      req.on('end', async () => {
        try {
          const payload = JSON.parse(body || '{}');
          const out = await createAccount(payload.username, payload.password, payload.email);
          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ ok: true, id: out.id, username: out.username }));
        } catch (err) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ ok: false, error: err.message }));
        }
      });
      return;
    }
    res.writeHead(404);
    res.end('Not found');
  });

  server.listen(port, '127.0.0.1', () => {
    console.log(`[Register] Web de registro disponible en http://127.0.0.1:${port}/`);
  });
}

async function main() {
  const args = process.argv.slice(2);
  if (args[0] === '--web') {
    const port = Number(args[1]) || 8088;
    startWebServer(port);
    return;
  }
  if (args.length < 2) {
    console.log('Uso:');
    console.log('  node register_account.js <usuario> <contrasena> [email]');
    console.log('  node register_account.js --web [puerto]');
    process.exit(0);
  }
  const out = await createAccount(args[0], args[1], args[2]);
  console.log(`Cuenta creada: id=${out.id} username=${out.username} sha3_256=${out.sha3_256}`);
}

main().catch(err => {
  console.error(`[Register] Error: ${err.message}`);
  process.exit(1);
});
