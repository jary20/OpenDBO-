////////////////////////////////////////////////////////////////////////////////
// File: MiningRigGui.h
// Desc: ZeniCoin (ZNC) CPU Mining Rig dialog.
//       Allows equipping up to 4 charm/card items as mining rigs, configuring
//       CPU thread count, starting/stopping mining via non-blocking Win32
//       Named Pipe IPC (\\.\pipe\DBO_RandomX_Miner), and viewing live telemetry.
////////////////////////////////////////////////////////////////////////////////

#ifndef __MINING_RIG_GUI_H__
#define __MINING_RIG_GUI_H__

#include "ceventhandler.h"
#include "NtlPLGui.h"
#include "NtlSLDef.h"

class CNtlSobItem;
class CNtlSobItemAttr;

class CMiningRigGui : public CNtlPLGui, public RWS::CEventHandler
{
public:
	enum
	{
		MAX_RIG_SLOTS = 4,
		DEFAULT_MIN_THREADS = 1,
		MAX_HARDWARE_THREADS = 16,
		NICEHASH_LICENSE_ITEM_TBLIDX = 2992003
	};

	struct sRIG_SLOT
	{
		SERIAL_HANDLE		hItemSerial;
		RwUInt32			tblidx;
		RwUInt8				byRank;
		RwUInt8				byRepairCount;
		RwInt32				nDurability;
		RwInt32				nMaxDurability;
		RwInt32				nMaxThreads;
		RwInt32				nBonusPercent;
		std::wstring		wstrItemName;

		gui::CButton*		pbtnSlot;
		gui::CStaticBox*	pstbSlotInfo;
		gui::CSlot			slotClicked;

		sRIG_SLOT()
			: hItemSerial(INVALID_SERIAL_ID)
			, tblidx(0xFFFFFFFF)
			, byRank(0)
			, byRepairCount(0)
			, nDurability(0)
			, nMaxDurability(0)
			, nMaxThreads(0)
			, nBonusPercent(0)
			, pbtnSlot(NULL)
			, pstbSlotInfo(NULL)
		{
		}
	};

public:
	CMiningRigGui(const RwChar* pName);
	virtual ~CMiningRigGui(VOID);

	RwBool	Create(VOID);
	VOID	Destroy(VOID);

	RwInt32	SwitchDialog(bool bOpen);
	VOID	Update(RwReal fElapsed);
	VOID	HandleEvents(RWS::CMsg& msg);

	RwBool	IsItemEquipped(SERIAL_HANDLE hItemSerial) const;
	static RwBool IsItemEquippedInAnyRig(SERIAL_HANDLE hItemSerial);

private:
	// Rig item & tier helpers
	RwBool	IsValidRigItem(CNtlSobItemAttr* pItemAttr) const;
	VOID	GetTierStatsForRank(RwUInt8 byRank, RwInt32& outMaxThreads, RwInt32& outBonusPercent) const;
	RwBool	EquipRigSlot(RwInt32 nSlotIdx, SERIAL_HANDLE hItemSerial);
	VOID	UnequipRigSlot(RwInt32 nSlotIdx);
	VOID	ClearAllRigSlots(VOID);
	VOID	RecalculateRigStats(VOID);
	VOID	SaveRigSlots(VOID) const;
	VOID	RestoreSavedRigSlots(VOID);
	RwUInt32 GetRepairCostZNC(VOID) const;

	// UI helpers
	VOID	CreateControls(VOID);
	VOID	CreateNiceHashConfigPanel(VOID);
	VOID	OpenNiceHashConfigPanel(VOID);
	VOID	CreateXmrClaimPanel(VOID);
	VOID	OpenXmrClaimPanel(VOID);
	VOID	RefreshXmrClaimPanel(VOID);
	VOID	RefreshUI(VOID);
	VOID	PositionAlign(RwInt32 nScreenWidth, RwInt32 nScreenHeight);

	// Non-blocking Win32 Named Pipe IPC (\\.\pipe\DBO_RandomX_Miner)
	RwBool	ConnectPipeNonBlocking(VOID);
	VOID	ClosePipe(VOID);
	RwBool	SendPipeCommand(const std::string& strCmd);
	VOID	PollPipeResponses(VOID);
	VOID	ParsePipeLine(const std::string& strLine);
	std::string GetWorkerId(VOID) const;

	// Callbacks
	VOID	OnClickedClose(gui::CComponent* pComponent);
	VOID	OnClickedToggleMining(gui::CComponent* pComponent);
	VOID	OnClickedRepairCards(gui::CComponent* pComponent);
	VOID	OnClickedThreadDown(gui::CComponent* pComponent);
	VOID	OnClickedThreadUp(gui::CComponent* pComponent);
	VOID	OnClickedRigSlot(gui::CComponent* pComponent);
	VOID	OnClickedNiceHash(gui::CComponent* pComponent);
	VOID	OnClickedNiceHashConfig(gui::CComponent* pComponent);
	VOID	OnClickedNiceHashWeb(gui::CComponent* pComponent);
	VOID	OnClickedNhSave(gui::CComponent* pComponent);
	VOID	OnClickedNhCancel(gui::CComponent* pComponent);
	VOID	OnClickedXmrClaim(gui::CComponent* pComponent);
	VOID	OnClickedXmrMax50(gui::CComponent* pComponent);
	VOID	OnClickedXmrClaimSubmit(gui::CComponent* pComponent);
	VOID	OnClickedXmrClaimClose(gui::CComponent* pComponent);

private:
	// UI Components
	gui::CStaticBox*	m_pstbTitle;
	gui::CStaticBox*	m_pstbRigHeader;
	gui::CStaticBox*	m_pstbThreadLabel;
	gui::CStaticBox*	m_pstbStatusLabel;
	gui::CStaticBox*	m_pstbHashrateLabel;
	gui::CStaticBox*	m_pstbSharesLabel;
	gui::CStaticBox*	m_pstbMinedZncLabel;
	gui::CStaticBox*	m_pstbRuleNotice;

	gui::CButton*		m_pbtnClose;
	gui::CButton*		m_pbtnThreadDown;
	gui::CButton*		m_pbtnThreadUp;
	gui::CButton*		m_pbtnToggleMining;
	gui::CButton*		m_pbtnRepair;
	gui::CButton*		m_pbtnNiceHash;
	gui::CButton*		m_pbtnNiceHashConfig;
	gui::CStaticBox*	m_pstbNiceHashStatus;
	gui::CButton*		m_pbtnNiceHashWeb;
	gui::CStaticBox*	m_pstbNiceHashWebLine1;
	gui::CStaticBox*	m_pstbNiceHashWebLine2;

	// NiceHash Credentials Sub-Window (Panel)
	gui::CPanel*		m_ppnlNiceHashConfig;
	gui::CStaticBox*	m_pstbNhCfgTitle;
	gui::CStaticBox*	m_pstbNhCfgNotice;
	gui::CInputBox*		m_pinpNhApiKey;
	gui::CInputBox*		m_pinpNhApiSecret;
	gui::CInputBox*		m_pinpNhOrgId;
	gui::CInputBox*		m_pinpNhPoolId;
	gui::CButton*		m_pbtnNhSave;
	gui::CButton*		m_pbtnNhCancel;

	// XMR Claim Sub-Window (Panel)
	gui::CButton*		m_pbtnXmrClaim;
	gui::CPanel*		m_ppnlXmrClaim;
	gui::CStaticBox*	m_pstbXmrTitle;
	gui::CStaticBox*	m_pstbXmrBalance;
	gui::CStaticBox*	m_pstbXmrMaxClaim;
	gui::CStaticBox*	m_pstbXmrCooldown;
	gui::CStaticBox*	m_pstbXmrNotice;
	gui::CInputBox*		m_pinpXmrWallet;
	gui::CInputBox*		m_pinpXmrAmount;
	gui::CButton*		m_pbtnXmrMax50;
	gui::CButton*		m_pbtnXmrSubmit;
	gui::CButton*		m_pbtnXmrClose;

	gui::CSlot			m_slotClose;
	gui::CSlot			m_slotThreadDown;
	gui::CSlot			m_slotThreadUp;
	gui::CSlot			m_slotToggleMining;
	gui::CSlot			m_slotRepair;
	gui::CSlot			m_slotNiceHash;
	gui::CSlot			m_slotNiceHashConfig;
	gui::CSlot			m_slotNiceHashWeb;
	gui::CSlot			m_slotNhSave;
	gui::CSlot			m_slotNhCancel;
	gui::CSlot			m_slotXmrClaim;
	gui::CSlot			m_slotXmrMax50;
	gui::CSlot			m_slotXmrSubmit;
	gui::CSlot			m_slotXmrClose;

	gui::CTexture*		m_pSolidTex;

	// Rig Slots
	sRIG_SLOT			m_aRigSlots[MAX_RIG_SLOTS];
	RwInt32				m_nMaxAllowedThreads;
	RwInt32				m_nSelectedThreads;
	RwInt32				m_nTotalBonusPercent;

	// Mining Telemetry State
	RwBool				m_bMiningActive;
	RwReal				m_fHashrate;
	RwUInt32			m_dwAcceptedShares;
	RwUInt32			m_dwMinedZNC;
	RwUInt32			m_dwLastRepairMinedZNC;

	// Non-blocking Named Pipe IPC State
	HANDLE				m_hPipe;
	std::string			m_strPipeRecvBuffer;
	RwReal				m_fStatusPollTimer;
	RwReal				m_fDurabilityWearTimer;
	RwBool				m_bRestoredSavedSlots;
	RwBool				m_bSuppressSave;

	// NiceHash Hashpower State
	RwBool				m_bNiceHashUnlocked;
	RwBool				m_bNiceHashActive;
	RwBool				m_bNiceHashConfigured;
	std::string			m_strNiceHashStatus;
	std::string			m_strNiceHashSpeed;

	// XMR Claim State
	DWORD				m_dwXmrBalanceUnits;
	DWORD				m_dwXmrMaxClaimUnits;
	DWORD				m_dwXmrCooldownRemainingSec;
	BYTE				m_byXmrCanClaim;
	RwBool				m_bXmrClaimPending;
};

#endif // __MINING_RIG_GUI_H__
