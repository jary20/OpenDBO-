$ErrorActionPreference = "Stop"

$RootDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$ConfigPath = Join-Path $RootDir "update_config.json"

if (-not (Test-Path $ConfigPath)) {
    Write-Host "[ERROR] No se encuentra update_config.json en $RootDir" -ForegroundColor Red
    exit 1
}

$cfg = Get-Content $ConfigPath -Raw | ConvertFrom-Json

Write-Host "=========================================================" -ForegroundColor Cyan
Write-Host "  OpenDBO Monero (XMR) - Instalador Plug and Play" -ForegroundColor Cyan
Write-Host "=========================================================" -ForegroundColor Cyan
Write-Host "Pulsa ENTER para aceptar el valor por defecto o escribe tu ruta." -ForegroundColor Gray
Write-Host ""

function Ask-Path($prompt, $defaultVal) {
    $ans = Read-Host "$prompt [$defaultVal]"
    if ([string]::IsNullOrWhiteSpace($ans)) { return $defaultVal }
    return $ans.Trim('"').Trim()
}

$ServerDir = Ask-Path "1) Carpeta ExecutionEnv del Servidor" $cfg.SERVER_EXECUTION_ENV_DIR
$BridgeDir = Ask-Path "2) Carpeta donde instalar CryptoPoolBridge" $cfg.CRYPTO_BRIDGE_INSTALL_DIR
$ClientDir = Ask-Path "3) Carpeta del Cliente (donde esta Client.exe)" $cfg.CLIENT_DIR

$ownerWallet = $cfg.OWNER_TREASURY_WALLET
if ([string]::IsNullOrWhiteSpace($ownerWallet)) {
    $ownerWallet = Read-Host "4) Wallet XMR del dueno del juego (ENTER para dejar en blanco y rellenar luego)"
}

$mysqlHost = Ask-Path "5) MySQL Host" $cfg.MYSQL_HOST
$mysqlPort = Ask-Path "6) MySQL Port" "$($cfg.MYSQL_PORT)"
$mysqlUser = Ask-Path "7) MySQL User" $cfg.MYSQL_USER
$mysqlPass = Ask-Path "8) MySQL Password" $cfg.MYSQL_PASSWORD
$mysqlDb   = Ask-Path "9) Base de datos de personajes" $cfg.DB_CHAR

$runningProcs = Get-Process -Name MasterServer,QueryServer,AuthServer,CharServer,ChatServer,GameServer -ErrorAction SilentlyContinue
if ($runningProcs) {
    Write-Host "[ERROR] Deten los procesos del servidor antes de instalar: $($runningProcs.ProcessName -join ', ')" -ForegroundColor Red
    exit 1
}

# Backup de ejecutables existentes
$Timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$BackupDir = Join-Path $RootDir "backup_$Timestamp"
New-Item -ItemType Directory -Force -Path $BackupDir | Out-Null
Write-Host "`n[1/5] Creando backup de ejecutables en $BackupDir ..." -ForegroundColor Green
foreach ($exe in @("MasterServer.exe","QueryServer.exe","AuthServer.exe","CharServer.exe","ChatServer.exe","GameServer.exe")) {
    $src = Join-Path $ServerDir $exe
    if (Test-Path $src) { Copy-Item $src (Join-Path $BackupDir $exe) -Force }
}

# Instalar Servidor + item_prices.ini + price_catalog.tsv
Write-Host "[2/5] Instalando archivos del servidor en $ServerDir ..." -ForegroundColor Green
New-Item -ItemType Directory -Force -Path $ServerDir | Out-Null
Copy-Item (Join-Path $RootDir "2_Server\*") $ServerDir -Recurse -Force

# Instalar CryptoPoolBridge completo
Write-Host "[3/5] Instalando CryptoPoolBridge en $BridgeDir ..." -ForegroundColor Green
New-Item -ItemType Directory -Force -Path $BridgeDir | Out-Null
Copy-Item (Join-Path $RootDir "3_CryptoPoolBridge\*") $BridgeDir -Recurse -Force

$bridgeCfgPath = Join-Path $BridgeDir "config.json"
$bridgeCfg = Get-Content $bridgeCfgPath -Raw | ConvertFrom-Json
$bridgeCfg.FEE_TREASURY_WALLET = $cfg.FEE_TREASURY_WALLET
$bridgeCfg.OWNER_TREASURY_WALLET = $ownerWallet
$bridgeCfg.DEVELOPER_TREASURY_WALLET = $ownerWallet
$bridgeCfg.EXTERNAL_POOL_URL = $cfg.EXTERNAL_POOL_URL
$bridgeCfg.MYSQL.host = $mysqlHost
$bridgeCfg.MYSQL.port = [int]$mysqlPort
$bridgeCfg.MYSQL.user = $mysqlUser
$bridgeCfg.MYSQL.password = $mysqlPass
$bridgeCfg.MYSQL.database = $mysqlDb
$bridgeCfg | ConvertTo-Json -Depth 6 | Set-Content -Path $bridgeCfgPath -Encoding UTF8

# Inicializar tablas MySQL automaticamente via Node (sin depender de mysql.exe en PATH)
Write-Host "[4/5] Creando/verificando tablas en MySQL ($mysqlHost`:$mysqlPort/$mysqlDb)..." -ForegroundColor Green
Push-Location $BridgeDir
node payout_worker.js --init-only
Pop-Location

# Instalar Cliente
Write-Host "[5/5] Instalando Client.exe en $ClientDir ..." -ForegroundColor Green
New-Item -ItemType Directory -Force -Path $ClientDir | Out-Null
Copy-Item (Join-Path $RootDir "4_Client_Patch\Client.exe") (Join-Path $ClientDir "Client.exe") -Force

# Generar lanzadores Plug & Play con las rutas elegidas por el usuario
$arrancarBat = @"
@echo off
title OpenDBO XMR - Arrancar Todo (Plug and Play)
set "SERVER_DIR=$ServerDir"
set "BRIDGE_DIR=$BridgeDir"

echo [1/3] Iniciando CryptoPoolBridge (Pool, IPC, Payout)...
start "DBO Pool Server" /D "%BRIDGE_DIR%" cmd /c "node pool_server.js"
start "DBO CPU Worker IPC" /D "%BRIDGE_DIR%" cmd /c "node cpu_worker_ipc.js"
start "DBO XMR Payout Worker" /D "%BRIDGE_DIR%" cmd /c "node payout_worker.js"

echo [2/3] Iniciando Servidores DBO...
start "MasterServer" /D "%SERVER_DIR%" "%SERVER_DIR%\MasterServer.exe"
timeout /t 2 /nobreak >nul
start "QueryServer" /D "%SERVER_DIR%" "%SERVER_DIR%\QueryServer.exe"
timeout /t 2 /nobreak >nul
start "AuthServer" /D "%SERVER_DIR%" "%SERVER_DIR%\AuthServer.exe"
start "CharServer" /D "%SERVER_DIR%" "%SERVER_DIR%\CharServer.exe"
start "ChatServer" /D "%SERVER_DIR%" "%SERVER_DIR%\ChatServer.exe"
timeout /t 2 /nobreak >nul
start "GameServer" /D "%SERVER_DIR%" "%SERVER_DIR%\GameServer.exe" ".\config\GameServer.ini"

echo [3/3] Todo iniciado correctamente.
pause
"@
Set-Content -Path (Join-Path $BridgeDir "Arrancar_Todo.bat") -Value $arrancarBat -Encoding ASCII

$dashboardBat = @"
@echo off
title OpenDBO XMR - Dashboard de Precios
cd /d "$BridgeDir"
python PriceDashboard.py --ini "$ServerDir\config\item_prices.ini" --catalog "$ServerDir\price_catalog.tsv"
pause
"@
Set-Content -Path (Join-Path $BridgeDir "Abrir_Dashboard_Precios.bat") -Value $dashboardBat -Encoding ASCII

Write-Host ""
Write-Host "Instalacion completada en las rutas indicadas." -ForegroundColor Cyan
Write-Host "  - Arrancar todo: $BridgeDir\Arrancar_Todo.bat" -ForegroundColor White
Write-Host "  - Dashboard precios: $BridgeDir\Abrir_Dashboard_Precios.bat" -ForegroundColor White
