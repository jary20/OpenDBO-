#include "stdafx.h"
//***********************************************************************************
//
//	File		:	NtlBattle.cpp
//
//	Begin		:	2006-04-24
//
//	Copyright	:	-----------------
//
//	Author		:	---------------------
//
//	Desc		:
//
//***********************************************************************************

#include "NtlBattle.h"

#include <crtdbg.h>
#include <stdlib.h>

//-----------------------------------------------------------------------------------
// static variable
//-----------------------------------------------------------------------------------
const char *s_battle_attack_type_string[BATTLE_ATTACK_TYPE_COUNT] = {
    "BATTLE_ATTACK_TYPE_PHYSICAL",
    "BATTLE_ATTACK_TYPE_ENERGY",
};

const char *s_battle_attack_result_string[BATTLE_ATTACK_RESULT_COUNT] = {
    "BATTLE_ATTACK_RESULT_HIT",          // 일반 공격
    "BATTLE_ATTACK_RESULT_CRITICAL_HIT", // 크리티칼 공격
    "BATTLE_ATTACK_RESULT_DODGE",        // 회피
    "BATTLE_ATTACK_RESULT_RESISTED",     // 저항
    "BATTLE_ATTACK_RESULT_BLOCK",        // 블락
    "BATTLE_ATTACK_RESULT_KNOCKDOWN",    // 넉다운
    "BATTLE_ATTACK_RESULT_SLIDING",      // 슬라이딩
};

const char *s_freebattle_result_string[FREEBATTLE_RESULT_COUNT] = {
    "FREEBATTLE_RESULT_WIN",
    "FREEBATTLE_RESULT_LOSE",
    "FREEBATTLE_RESULT_DRAW",
};

//-----------------------------------------------------------------------------------
//		Purpose	:
//		Return	:
//-----------------------------------------------------------------------------------
const char *NtlGetBattleAttackTypeString(BYTE byAttackType) {
  if (byAttackType >= BATTLE_ATTACK_TYPE_COUNT) {
    return "NOT DEFINED";
  }

  return s_battle_attack_type_string[byAttackType];
}

//-----------------------------------------------------------------------------------
//		Purpose	:
//		Return	:
//-----------------------------------------------------------------------------------
const char *DboGetFreeBattleResultString(BYTE byBattleResult) {
  if (byBattleResult >= FREEBATTLE_RESULT_COUNT) {
    return "NOT DEFINED";
  }

  return s_freebattle_result_string[byBattleResult];
}

//-----------------------------------------------------------------------------------
//		Purpose	:
//		Return	:
//-----------------------------------------------------------------------------------
const char *NtlGetBattleAttackResultString(BYTE byAttackResult) {
  if (byAttackResult >= BATTLE_ATTACK_RESULT_COUNT) {
    return "NOT DEFINED";
  }

  return s_battle_attack_result_string[byAttackResult];
}

//-----------------------------------------------------------------------------------
//		Purpose	:
//		Return	:
//-----------------------------------------------------------------------------------
float NtlGetBattleChainAttackBounsRate(BYTE byAttackSequence) {
  // NTL_BATTLE_MAX_CHAIN_ATTACK_COUNT_PLAYER is simply the max possible attack
  // chain number (6).
  static float
      s_afChainAttackBonusRate[NTL_BATTLE_MAX_CHAIN_ATTACK_COUNT_PLAYER] = {
          0.0f, 0.5f, 1.0f, 2.0f, 3.0f, 4.0f};

  if (byAttackSequence <= 0) {
    return 0.0f;
  }

  if (byAttackSequence > NTL_BATTLE_MAX_CHAIN_ATTACK_COUNT_PLAYER) {
    _ASSERT(0);
    return 0.0f;
  }

  return s_afChainAttackBonusRate[byAttackSequence - 1];
}

//-----------------------------------------------------------------------------------
//		Purpose	:
//		Return	:
//-----------------------------------------------------------------------------------
BYTE NtlGetBattleChainAttackSequence(WORD byCharLevel) {
  if (byCharLevel >= 20)
    return 6;

  if (byCharLevel >= 16)
    return 5;

  if (byCharLevel >= 12)
    return 4;

  if (byCharLevel >= 8)
    return 3;

  if (byCharLevel >= 4)
    return 2;

  return 1;
}

////-----------------------------------------------------------------------------------
////		Purpose	:
////		Return	:
////-----------------------------------------------------------------------------------
float NtlGetBattleAttributeBonusRate(BYTE bySubjectAtt, BYTE byTargetAtt) {
  static float afBattleAttributeBonusRate
      [BATTLE_ATTRIBUTE_COUNT][BATTLE_ATTRIBUTE_COUNT] = {
          // BATTLE_ATTRIBUTE_NONE
          {0.0f, -5.0f, -5.0f, -5.0f, -5.0f, -5.0f, -500.0f},

          // BATTLE_ATTRIBUTE_HONEST
          {5.0f, 0.0f, 5.0f, 10.0f, -10.0f, -5.0f, -500.0f},

          // BATTLE_ATTRIBUTE_STRANGE
          {5.0f, -5.0f, 0.0f, 5.0f, 10.0f, -10.0f, -500.0f},

          // BATTLE_ATTRIBUTE_WILD
          {5.0f, -10.0f, -5.0f, 0.0f, 5.0f, 10.0f, -500.0f},

          // BATTLE_ATTRIBUTE_ELEGANCE
          {5.0f, 10.0f, -10.0f, -5.0f, 0.0f, 5.0f, -500.0f},

          // BATTLE_ATTRIBUTE_FUNNY
          {5.0f, 5.0f, 10.0f, -10.0f, -5.0f, 0.0f, -500.0f},

          // BATTLE_ATTRIBUTE_GOD
          {500.0f, 500.0f, 500.0f, 500.0f, 500.0f, 500.0f, 0.0f},

      };

  if (bySubjectAtt >= BATTLE_ATTRIBUTE_COUNT ||
      byTargetAtt >= BATTLE_ATTRIBUTE_COUNT) {
    _ASSERT(0);
    return 0.0f;
  }

  return afBattleAttributeBonusRate[bySubjectAtt][byTargetAtt];
}

//-----------------------------------------------------------------------------------
//		Purpose	:
//		Return	:
//-----------------------------------------------------------------------------------
eSYSTEM_EFFECT_CODE GetBattleAttributeEffectCode(BYTE byAtt) {
  static eSYSTEM_EFFECT_CODE awBattleAttribute[BATTLE_ATTRIBUTE_COUNT] = {
      INVALID_SYSTEM_EFFECT_CODE,        ACTIVE_CRITICAL_BLOCK_UP,
      ACTIVE_ENERGY_CRITICAL_DEFENSE_UP, ACTIVE_PHYSICAL_ARMOR_PEN_UP,
      ACTIVE_ENERGY_ARMOR_PEN_UP,        ACTIVE_PHYSICAL_CRITICAL_DEFENSE_UP,
      ACTIVE_CRITICAL_BLOCK_UP};

  if (byAtt >= BATTLE_ATTRIBUTE_COUNT) {
    return INVALID_SYSTEM_EFFECT_CODE;
  }

  return awBattleAttribute[byAtt];
}

//-----------------------------------------------------------------------------------
//		Purpose	:
//		Return	:
//-----------------------------------------------------------------------------------
BYTE GetBattleAttributeEffectApplyType(BYTE byAtt) {
  static BYTE abyBattleAttributeApplyType[BATTLE_ATTRIBUTE_COUNT] = {
      SYSTEM_EFFECT_APPLY_TYPE_UNKNOWN, SYSTEM_EFFECT_APPLY_TYPE_VALUE,
      SYSTEM_EFFECT_APPLY_TYPE_VALUE,   SYSTEM_EFFECT_APPLY_TYPE_VALUE,
      SYSTEM_EFFECT_APPLY_TYPE_VALUE,   SYSTEM_EFFECT_APPLY_TYPE_VALUE};

  if (byAtt >= BATTLE_ATTRIBUTE_COUNT) {
    return SYSTEM_EFFECT_APPLY_TYPE_UNKNOWN;
  }

  return abyBattleAttributeApplyType[byAtt];
}

float GetBattleAttributeEffectApplyValue(BYTE byAtt, BYTE Source) {

  float afBattleAttributeApplyValue[BATTLE_ATTRIBUTE_COUNT] = {5.f, 5.f, 5.f,
                                                               5.f, 5.f, 5.f};

  switch (Source) {
  case BATTLE_ATTRIBUTE_NONE:
    afBattleAttributeApplyValue[0] = 0.f;
    afBattleAttributeApplyValue[1] = -5.f;
    afBattleAttributeApplyValue[2] = -5.f;
    afBattleAttributeApplyValue[3] = -5.f;
    afBattleAttributeApplyValue[4] = -5.f;
    afBattleAttributeApplyValue[5] = -5.f;
    afBattleAttributeApplyValue[6] = -500.f;
    break;
  case BATTLE_ATTRIBUTE_HONEST:
    afBattleAttributeApplyValue[0] = 10.f;
    afBattleAttributeApplyValue[1] = 5.f;
    afBattleAttributeApplyValue[2] = 10.f;
    afBattleAttributeApplyValue[3] = 15.f;
    afBattleAttributeApplyValue[4] = -5.f;
    afBattleAttributeApplyValue[5] = 0.f;
    afBattleAttributeApplyValue[6] = -500.f;
    break;
  case BATTLE_ATTRIBUTE_STRANGE:
    afBattleAttributeApplyValue[0] = 10.f;
    afBattleAttributeApplyValue[1] = 0.f;
    afBattleAttributeApplyValue[2] = 5.f;
    afBattleAttributeApplyValue[3] = 10.f;
    afBattleAttributeApplyValue[4] = 15.f;
    afBattleAttributeApplyValue[5] = -5.f;
    afBattleAttributeApplyValue[6] = -500.f;
    break;
  case BATTLE_ATTRIBUTE_WILD:
    afBattleAttributeApplyValue[0] = 10.f;
    afBattleAttributeApplyValue[1] = -5.f;
    afBattleAttributeApplyValue[2] = 0.f;
    afBattleAttributeApplyValue[3] = 5.f;
    afBattleAttributeApplyValue[4] = 10.f;
    afBattleAttributeApplyValue[5] = 15.f;
    afBattleAttributeApplyValue[6] = -500.f;
    break;
  case BATTLE_ATTRIBUTE_ELEGANCE:
    afBattleAttributeApplyValue[0] = 10.f;
    afBattleAttributeApplyValue[1] = 15.f;
    afBattleAttributeApplyValue[2] = -5.f;
    afBattleAttributeApplyValue[3] = 0.f;
    afBattleAttributeApplyValue[4] = 5.f;
    afBattleAttributeApplyValue[5] = 10.f;
    afBattleAttributeApplyValue[6] = -500.f;
    break;
  case BATTLE_ATTRIBUTE_FUNNY:
    afBattleAttributeApplyValue[0] = 10.f;
    afBattleAttributeApplyValue[1] = 10.f;
    afBattleAttributeApplyValue[2] = 15.f;
    afBattleAttributeApplyValue[3] = -5.f;
    afBattleAttributeApplyValue[4] = 0.f;
    afBattleAttributeApplyValue[5] = 5.f;
    afBattleAttributeApplyValue[6] = -500.f;
    break;
  case BATTLE_ATTRIBUTE_GOD:
    afBattleAttributeApplyValue[0] = 500.f;
    afBattleAttributeApplyValue[1] = 500.f;
    afBattleAttributeApplyValue[2] = 500.f;
    afBattleAttributeApplyValue[3] = 500.f;
    afBattleAttributeApplyValue[4] = 500.f;
    afBattleAttributeApplyValue[5] = 500.f;
    afBattleAttributeApplyValue[6] = 0.f;
    break;
  default:
    return 0.f;
  }

  if (byAtt >= BATTLE_ATTRIBUTE_COUNT) {
    return 0.f;
  }

  return afBattleAttributeApplyValue[byAtt];
}

//-----------------------------------------------------------------------------------
//		Purpose	: check if player is in korin arena. This function is no
// longer required. Use DBO_WORLD_ATTR_BASIC_FREE_PVP_ZONE 		Return
// :
//-----------------------------------------------------------------------------------
bool IsInBattleArena(TBLIDX worldTblidx, CNtlVector &vCurLoc) {
  if (worldTblidx == 1 /*&& vCurLoc.y >= -97.268f*/ &&
      (vCurLoc.x < 5792 && vCurLoc.z < 788 && vCurLoc.x > 5752 &&
       vCurLoc.z > 748))
    return true;

  return false;
}