'use strict';

const fs = require('fs');
const path = require('path');
const mysql = require('mysql2/promise');

const CONFIG_PATH = path.join(__dirname, 'config.json');
const config = JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'));

function printHelp() {
  console.log(`
${config.CURRENCY_NAME} (${config.CURRENCY_TICKER}) Treasury & Rewards CLI
Usage:
  node treasury_cli.js [command] [options]

Commands:
  summary             Show treasury_ledger totals (MINING_FEE, MARKET_TAX, NPC_TAX)
                      and mining_rewards_queue status counts (default).
  withdraw-treasury   Mark all unwithdrawn (withdrawn = 0) treasury_ledger fees as
                      withdrawn (withdrawn = 1). Pass --rpc to send on-chain via
                      monero-wallet-rpc to FEE_TREASURY_WALLET first.
  process-pending     List PENDING entries in mining_rewards_queue.
                      Pass --mark-claimed to mark them CLAIMED manually.
  help                Show this help message.
`);
}

async function createConnection() {
  return mysql.createConnection({
    host: config.MYSQL.host,
    port: config.MYSQL.port || 3306,
    user: config.MYSQL.user,
    password: config.MYSQL.password,
    database: config.MYSQL.database
  });
}

async function showSummary(conn) {
  const feeWallet = config.FEE_TREASURY_WALLET || config.DEVELOPER_TREASURY_WALLET;
  console.log(`=== ${config.CURRENCY_NAME} (${config.CURRENCY_TICKER}) Treasury Summary ===`);
  console.log(`Mining Wallet:        ${config.DEVELOPER_TREASURY_WALLET}`);
  console.log(`Fee Treasury Wallet:  ${feeWallet}\n`);

  const [ledgerRows] = await conn.execute(`
    SELECT
      source_type,
      COUNT(*) AS entry_count,
      COALESCE(SUM(gross_amount), 0) AS total_gross,
      COALESCE(SUM(fee_amount), 0) AS total_fee,
      COALESCE(SUM(CASE WHEN withdrawn = 0 THEN fee_amount ELSE 0 END), 0) AS unwithdrawn_fee,
      COALESCE(SUM(CASE WHEN withdrawn = 1 THEN fee_amount ELSE 0 END), 0) AS withdrawn_fee
    FROM treasury_ledger
    GROUP BY source_type
    ORDER BY source_type ASC
  `);

  console.log('--- treasury_ledger ---');
  if (ledgerRows.length === 0) {
    console.log('No entries found in treasury_ledger.');
  } else {
    let grandUnwithdrawn = 0;
    let grandTotalFee = 0;
    for (const row of ledgerRows) {
      grandUnwithdrawn += Number(row.unwithdrawn_fee);
      grandTotalFee += Number(row.total_fee);
      console.log(
        `  ${row.source_type.padEnd(12)} | entries=${String(row.entry_count).padStart(6)} | ` +
        `gross=${String(row.total_gross).padStart(10)} | fee=${String(row.total_fee).padStart(10)} | ` +
        `unwithdrawn=${String(row.unwithdrawn_fee).padStart(10)} | withdrawn=${row.withdrawn_fee}`
      );
    }
    console.log(`  TOTAL FEES: ${grandTotalFee} ${config.CURRENCY_TICKER} (Available to withdraw: ${grandUnwithdrawn} ${config.CURRENCY_TICKER})`);
  }

  const [queueRows] = await conn.execute(`
    SELECT
      status,
      COUNT(*) AS entry_count,
      COALESCE(SUM(shares), 0) AS total_shares,
      COALESCE(SUM(gross_amount), 0) AS total_gross,
      COALESCE(SUM(fee_amount), 0) AS total_fee,
      COALESCE(SUM(net_amount), 0) AS total_net
    FROM mining_rewards_queue
    GROUP BY status
    ORDER BY status ASC
  `);

  console.log('\n--- mining_rewards_queue ---');
  if (queueRows.length === 0) {
    console.log('No entries found in mining_rewards_queue.');
  } else {
    for (const row of queueRows) {
      console.log(
        `  ${row.status.padEnd(10)} | entries=${String(row.entry_count).padStart(6)} | ` +
        `shares=${String(row.total_shares).padStart(8)} | net=${row.total_net} ${config.CURRENCY_TICKER}`
      );
    }
  }
}

const PICONEROS_PER_UNIT = 100n;

async function rpcTransfer(address, amountUnits) {
  const rpcCfg = config.MONERO_RPC || {};
  const rpcUrl = rpcCfg.url || 'http://127.0.0.1:18082/json_rpc';
  const piconeros = BigInt(Math.floor(amountUnits)) * PICONEROS_PER_UNIT;
  const body = JSON.stringify({
    jsonrpc: '2.0',
    id: '0',
    method: 'transfer',
    params: {
      destinations: [{ amount: Number(piconeros), address }],
      priority: 1,
      get_tx_key: true
    }
  });
  const headers = { 'Content-Type': 'application/json' };
  if (rpcCfg.username || rpcCfg.password) {
    const auth = Buffer.from(`${rpcCfg.username || ''}:${rpcCfg.password || ''}`).toString('base64');
    headers.Authorization = `Basic ${auth}`;
  }
  const res = await fetch(rpcUrl, { method: 'POST', headers, body, signal: AbortSignal.timeout(15000) });
  if (!res.ok) throw new Error(`Monero RPC HTTP ${res.status}`);
  const data = await res.json();
  if (data.error) throw new Error(data.error.message || JSON.stringify(data.error));
  return data.result;
}

async function withdrawTreasury(conn, useRpc = false) {
  await conn.beginTransaction();
  try {
    const [sumRows] = await conn.execute(`
      SELECT
        COUNT(*) AS row_count,
        COALESCE(SUM(fee_amount), 0) AS available_fee
      FROM treasury_ledger
      WHERE withdrawn = 0
      FOR UPDATE
    `);

    const rowCount = Number(sumRows[0].row_count);
    const availableFee = Number(sumRows[0].available_fee);

    if (rowCount === 0 || availableFee <= 0) {
      await conn.rollback();
      console.log('No unwithdrawn treasury fees available.');
      return;
    }

    const feeWallet = (config.FEE_TREASURY_WALLET || config.DEVELOPER_TREASURY_WALLET || '').split('/')[0];
    if (useRpc) {
      if (!feeWallet || feeWallet.length < 90) {
        throw new Error('FEE_TREASURY_WALLET is missing or invalid for --rpc transfer.');
      }
      const txRes = await rpcTransfer(feeWallet, availableFee);
      console.log(`[TreasuryCLI] RPC transfer sent: tx_hash=${txRes.tx_hash} amount_units=${availableFee}`);
    }

    await conn.execute(`UPDATE treasury_ledger SET withdrawn = 1 WHERE withdrawn = 0`);
    await conn.commit();

    console.log(
      `Withdrew ${availableFee} ${config.CURRENCY_TICKER} across ${rowCount} ledger entries ` +
      `to ${feeWallet}${useRpc ? ' (on-chain RPC)' : ' (ledger-only)'}.`
    );
  } catch (err) {
    await conn.rollback();
    throw err;
  }
}

async function processPending(conn, markClaimed) {
  const [pendingRows] = await conn.execute(`
    SELECT
      char_id,
      COUNT(*) AS entry_count,
      COALESCE(SUM(shares), 0) AS total_shares,
      COALESCE(SUM(net_amount), 0) AS total_net
    FROM mining_rewards_queue
    WHERE status = 'PENDING'
    GROUP BY char_id
    ORDER BY total_net DESC
  `);

  if (pendingRows.length === 0) {
    console.log('No PENDING rewards in mining_rewards_queue.');
    return;
  }

  console.log(`Found ${pendingRows.length} character(s) with PENDING rewards:`);
  for (const row of pendingRows) {
    console.log(
      `  char_id=${row.char_id} | entries=${row.entry_count} | shares=${row.total_shares} | ` +
      `pending_net=${row.total_net} ${config.CURRENCY_TICKER}`
    );
  }

  if (markClaimed) {
    const [res] = await conn.execute(
      `UPDATE mining_rewards_queue SET status = 'CLAIMED' WHERE status = 'PENDING'`
    );
    console.log(`Marked ${res.affectedRows} PENDING row(s) as CLAIMED.`);
  } else {
    console.log('Note: QueryServer normally claims PENDING rows for online players. Pass --mark-claimed to force-claim.');
  }
}

async function main() {
  const args = process.argv.slice(2);
  const command = (args[0] || 'summary').toLowerCase();

  if (command === 'help' || command === '--help' || command === '-h') {
    printHelp();
    return;
  }

  let conn;
  try {
    conn = await createConnection();
    switch (command) {
      case 'summary':
        await showSummary(conn);
        break;
      case 'withdraw-treasury':
        await withdrawTreasury(conn, args.includes('--rpc'));
        break;
      case 'process-pending':
        await processPending(conn, args.includes('--mark-claimed'));
        break;
      default:
        console.error(`Unknown command: ${command}`);
        printHelp();
        process.exitCode = 1;
        break;
    }
  } catch (err) {
    console.error(`[TreasuryCLI] Error: ${err.message}`);
    process.exitCode = 1;
  } finally {
    if (conn) {
      await conn.end();
    }
  }
}

main();
