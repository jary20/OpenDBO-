'use strict';

const fs = require('fs');
const path = require('path');
const http = require('http');
const https = require('https');
const crypto = require('crypto');
const mysql = require('mysql2/promise');

const CONFIG_PATH = path.join(__dirname, 'config.json');
const config = JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'));

const MONERO_ADDR_REGEX = /^[48][1-9A-HJ-NP-Za-km-z]{94}$|^[48][1-9A-HJ-NP-Za-km-z]{105}$/;
const PICONEROS_PER_UNIT = 100n; // 1 internal unit = 10^-10 XMR = 100 piconeros
const RPC_TIMEOUT_MS = 15000;
const TRANSIENT_NET_CODES = new Set([
  'ECONNREFUSED',
  'ECONNRESET',
  'ETIMEDOUT',
  'ENOTFOUND',
  'EHOSTUNREACH',
  'ENETUNREACH',
  'EPIPE'
]);

let dbPool = null;
let pollTimer = null;
let isPolling = false;
let isShuttingDown = false;
let digestNonceCounter = 0;

/**
 * Custom error class for Monero RPC protocol/wallet rejections vs transient network failures.
 */
class MoneroRpcError extends Error {
  /**
   * @param {string} message
   * @param {{ code?: number, isTransient?: boolean }} [opts]
   */
  constructor(message, opts = {}) {
    super(message);
    this.name = 'MoneroRpcError';
    this.code = opts.code ?? null;
    this.isTransient = Boolean(opts.isTransient);
  }
}

/**
 * Validate a Monero standard (95 chars) or integrated (106 chars) Base58 address
 * starting with '4' or '8'.
 * @param {string} address
 * @returns {boolean}
 */
function isValidMoneroAddress(address) {
  if (typeof address !== 'string') return false;
  return MONERO_ADDR_REGEX.test(address.trim());
}

/**
 * Parse a WWW-Authenticate: Digest header into key/value pairs.
 * @param {string} header
 * @returns {Record<string, string>}
 */
function parseDigestChallenge(header) {
  const params = {};
  const stripped = header.replace(/^Digest\s+/i, '');
  const regex = /([a-zA-Z0-9_-]+)=("([^"]*)"|([^,\s]+))/g;
  let match;
  while ((match = regex.exec(stripped)) !== null) {
    params[match[1].toLowerCase()] = match[3] !== undefined ? match[3] : match[4];
  }
  return params;
}

/**
 * Compute an HTTP Digest Authorization header value (RFC 2617 / RFC 7617 MD5).
 * @param {string} method
 * @param {string} uri
 * @param {string} username
 * @param {string} password
 * @param {Record<string, string>} challenge
 * @returns {string}
 */
function buildDigestAuthHeader(method, uri, username, password, challenge) {
  const realm = challenge.realm || '';
  const nonce = challenge.nonce || '';
  const qop = challenge.qop ? challenge.qop.split(',')[0].trim() : '';
  const opaque = challenge.opaque;

  digestNonceCounter += 1;
  const nc = digestNonceCounter.toString(16).padStart(8, '0');
  const cnonce = crypto.randomBytes(8).toString('hex');

  const md5 = (str) => crypto.createHash('md5').update(str).digest('hex');
  const ha1 = md5(`${username}:${realm}:${password}`);
  const ha2 = md5(`${method}:${uri}`);

  let response;
  if (qop === 'auth') {
    response = md5(`${ha1}:${nonce}:${nc}:${cnonce}:${qop}:${ha2}`);
  } else {
    response = md5(`${ha1}:${nonce}:${ha2}`);
  }

  const parts = [
    `username="${username}"`,
    `realm="${realm}"`,
    `nonce="${nonce}"`,
    `uri="${uri}"`,
    `response="${response}"`
  ];
  if (qop) {
    parts.push(`qop=${qop}`, `nc=${nc}`, `cnonce="${cnonce}"`);
  }
  if (opaque) {
    parts.push(`opaque="${opaque}"`);
  }
  return `Digest ${parts.join(', ')}`;
}

/**
 * Perform a single HTTP/HTTPS POST request.
 * @param {URL} parsedUrl
 * @param {string} body
 * @param {Record<string, string>} extraHeaders
 * @returns {Promise<{ statusCode: number, headers: http.IncomingHttpHeaders, body: string }>}
 */
function httpPost(parsedUrl, body, extraHeaders = {}) {
  return new Promise((resolve, reject) => {
    const transport = parsedUrl.protocol === 'https:' ? https : http;
    const req = transport.request(
      {
        hostname: parsedUrl.hostname,
        port: parsedUrl.port || (parsedUrl.protocol === 'https:' ? 443 : 80),
        path: `${parsedUrl.pathname}${parsedUrl.search}`,
        method: 'POST',
        timeout: RPC_TIMEOUT_MS,
        headers: {
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(body, 'utf8'),
          ...extraHeaders
        }
      },
      (res) => {
        const chunks = [];
        res.on('data', (chunk) => chunks.push(chunk));
        res.on('end', () => {
          resolve({
            statusCode: res.statusCode || 0,
            headers: res.headers,
            body: Buffer.concat(chunks).toString('utf8')
          });
        });
      }
    );

    req.on('timeout', () => {
      req.destroy(Object.assign(new Error(`RPC request timed out after ${RPC_TIMEOUT_MS}ms`), { code: 'ETIMEDOUT' }));
    });
    req.on('error', reject);
    req.write(body);
    req.end();
  });
}

/**
 * Call monero-wallet-rpc JSON-RPC endpoint with optional Basic/Digest authentication.
 * @param {string} method
 * @param {object} [params]
 * @returns {Promise<any>}
 */
async function callMoneroRpc(method, params = {}) {
  const rpcCfg = config.MONERO_RPC || {};
  const rpcUrl = rpcCfg.url || 'http://127.0.0.1:18082/json_rpc';
  const parsedUrl = new URL(rpcUrl);
  const payload = JSON.stringify({
    jsonrpc: '2.0',
    id: '0',
    method,
    params
  });

  const username = rpcCfg.username || '';
  const password = rpcCfg.password || '';
  const hasCreds = username !== '' || password !== '';

  let res;
  try {
    res = await httpPost(parsedUrl, payload);

    if (res.statusCode === 401 && hasCreds) {
      const wwwAuth = String(res.headers['www-authenticate'] || '');
      let authHeader = null;
      if (/^Digest\s+/i.test(wwwAuth)) {
        const challenge = parseDigestChallenge(wwwAuth);
        authHeader = buildDigestAuthHeader('POST', `${parsedUrl.pathname}${parsedUrl.search}`, username, password, challenge);
      } else if (/^Basic\s+/i.test(wwwAuth) || wwwAuth === '') {
        const token = Buffer.from(`${username}:${password}`, 'utf8').toString('base64');
        authHeader = `Basic ${token}`;
      }

      if (authHeader) {
        res = await httpPost(parsedUrl, payload, { Authorization: authHeader });
      }
    }
  } catch (err) {
    const code = err && err.code;
    if (TRANSIENT_NET_CODES.has(code)) {
      throw new MoneroRpcError(`monero-wallet-rpc unreachable (${code}: ${err.message})`, { isTransient: true });
    }
    throw new MoneroRpcError(`monero-wallet-rpc transport error: ${err.message}`, { isTransient: true });
  }

  if (res.statusCode >= 500 || res.statusCode === 429) {
    throw new MoneroRpcError(`monero-wallet-rpc HTTP ${res.statusCode}`, { isTransient: true });
  }
  if (res.statusCode === 401 || res.statusCode === 403) {
    throw new MoneroRpcError(`monero-wallet-rpc authentication failed (HTTP ${res.statusCode})`, { isTransient: true });
  }
  if (res.statusCode < 200 || res.statusCode >= 300) {
    throw new MoneroRpcError(`monero-wallet-rpc HTTP ${res.statusCode}: ${res.body.slice(0, 200)}`, { isTransient: false });
  }

  let parsed;
  try {
    parsed = JSON.parse(res.body);
  } catch (_err) {
    throw new MoneroRpcError(`Invalid JSON from monero-wallet-rpc: ${res.body.slice(0, 200)}`, { isTransient: true });
  }

  if (parsed.error) {
    const rpcCode = parsed.error.code ?? -1;
    const rpcMsg = parsed.error.message || 'Unknown RPC error';
    throw new MoneroRpcError(`RPC error ${rpcCode}: ${rpcMsg}`, { code: rpcCode, isTransient: false });
  }

  return parsed.result;
}

/**
 * Ensure the dbo_char.xmr_withdrawals table exists.
 * @returns {Promise<void>}
 */
async function ensureSchema() {
  await dbPool.query(`
    CREATE TABLE IF NOT EXISTS xmr_withdrawals (
      id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
      account_id INT UNSIGNED NOT NULL,
      char_id INT UNSIGNED NOT NULL,
      wallet_address VARCHAR(128) NOT NULL,
      amount_units BIGINT UNSIGNED NOT NULL,
      balance_snapshot BIGINT UNSIGNED NOT NULL DEFAULT 0,
      status ENUM('PENDING','PROCESSING','WAITING_ADMIN','SENT','FAILED') NOT NULL DEFAULT 'PENDING',
      tx_hash VARCHAR(128) NULL DEFAULT NULL,
      error_msg VARCHAR(512) NULL DEFAULT NULL,
      created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      processed_at DATETIME NULL DEFAULT NULL,
      PRIMARY KEY (id),
      INDEX idx_char_created (char_id, created_at),
      INDEX idx_status (status)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
  `);
  await dbPool.query(`
    ALTER TABLE xmr_withdrawals
    MODIFY COLUMN status ENUM('PENDING','PROCESSING','WAITING_ADMIN','SENT','FAILED') NOT NULL DEFAULT 'PENDING'
  `);
}

/**
 * Mark a PROCESSING withdrawal as FAILED and atomically refund amount_units to characters.money.
 * @param {number|string} withdrawalId
 * @param {number} charId
 * @param {bigint} amountUnits
 * @param {string} errorMsg
 * @returns {Promise<void>}
 */
async function failAndRefundWithdrawal(withdrawalId, charId, amountUnits, errorMsg) {
  const safeMsg = String(errorMsg || 'Withdrawal failed').slice(0, 512);
  const conn = await dbPool.getConnection();
  try {
    await conn.beginTransaction();

    const [updResult] = await conn.execute(
      `UPDATE xmr_withdrawals
       SET status = 'FAILED', error_msg = ?, processed_at = NOW()
       WHERE id = ? AND status = 'PROCESSING'`,
      [safeMsg, withdrawalId]
    );

    if (updResult.affectedRows === 1) {
      await conn.execute(
        `UPDATE characters SET money = money + ? WHERE id = ?`,
        [amountUnits.toString(), charId]
      );
    }

    await conn.commit();
  } catch (err) {
    await conn.rollback();
    throw err;
  } finally {
    conn.release();
  }
}

/**
 * Revert a PROCESSING withdrawal back to PENDING for later retry (no refund).
 * @param {number|string} withdrawalId
 * @returns {Promise<void>}
 */
async function revertToPending(withdrawalId) {
  await dbPool.execute(
    `UPDATE xmr_withdrawals
     SET status = 'PENDING'
     WHERE id = ? AND status = 'PROCESSING'`,
    [withdrawalId]
  );
}

/**
 * Mark a PROCESSING withdrawal as WAITING_ADMIN when the server wallet lacks sufficient unlocked balance.
 * @param {number|string} withdrawalId
 * @param {string} reasonMsg
 * @returns {Promise<void>}
 */
async function markWaitingAdmin(withdrawalId, reasonMsg) {
  const safeMsg = String(reasonMsg || 'Saldo insuficiente en wallet del servidor; en espera de confirmacion del administrador').slice(0, 512);
  await dbPool.execute(
    `UPDATE xmr_withdrawals
     SET status = 'WAITING_ADMIN', error_msg = ?
     WHERE id = ? AND status = 'PROCESSING'`,
    [safeMsg, withdrawalId]
  );
}

/**
 * Process a single claimed withdrawal row.
 * @param {object} row
 * @returns {Promise<void>}
 */
async function processWithdrawal(row) {
  const withdrawalId = row.id;
  const charId = Number(row.char_id);
  const address = String(row.wallet_address || '').trim();
  const amountUnits = BigInt(row.amount_units);

  if (amountUnits <= 0n) {
    await failAndRefundWithdrawal(withdrawalId, charId, 0n, 'Invalid withdrawal amount (must be > 0)');
    console.warn(`[Payout] Withdrawal #${withdrawalId} FAILED: non-positive amount (${amountUnits})`);
    return;
  }

  if (!isValidMoneroAddress(address)) {
    await failAndRefundWithdrawal(
      withdrawalId,
      charId,
      amountUnits,
      'Invalid Monero wallet address (expected 95 or 106 Base58 chars starting with 4 or 8)'
    );
    console.warn(`[Payout] Withdrawal #${withdrawalId} FAILED & refunded ${amountUnits} units to CharID=${charId}: invalid address`);
    return;
  }

  const piconeros = amountUnits * PICONEROS_PER_UNIT;

  try {
    const balanceRes = await callMoneroRpc('get_balance', { account_index: 0 });
    const unlockedBalance = BigInt(balanceRes.unlocked_balance ?? 0);

    if (unlockedBalance < piconeros) {
      await markWaitingAdmin(
        withdrawalId,
        `Saldo insuficiente en wallet del servidor (disponible=${unlockedBalance}, requerido=${piconeros} piconeros); en espera de confirmacion del administrador.`
      );
      console.warn(
        `[Payout] Withdrawal #${withdrawalId} -> WAITING_ADMIN: insufficient unlocked wallet balance ` +
        `(have=${unlockedBalance} piconeros, need=${piconeros} piconeros). Run --approve ${withdrawalId} or --approve-all after funding.`
      );
      return;
    }

    const transferRes = await callMoneroRpc('transfer', {
      destinations: [{ amount: Number(piconeros), address }],
      account_index: 0,
      priority: 0,
      get_tx_key: true
    });

    if (!transferRes || !transferRes.tx_hash) {
      await failAndRefundWithdrawal(
        withdrawalId,
        charId,
        amountUnits,
        'monero-wallet-rpc transfer returned no tx_hash'
      );
      console.error(`[Payout] Withdrawal #${withdrawalId} FAILED & refunded: missing tx_hash`);
      return;
    }

    await dbPool.execute(
      `UPDATE xmr_withdrawals
       SET status = 'SENT', tx_hash = ?, error_msg = NULL, processed_at = NOW()
       WHERE id = ? AND status = 'PROCESSING'`,
      [transferRes.tx_hash, withdrawalId]
    );

    console.log(
      `[Payout] Withdrawal #${withdrawalId} SENT | CharID=${charId} | ` +
      `${amountUnits} units (${piconeros} piconeros) -> ${address.slice(0, 12)}... | tx=${transferRes.tx_hash}`
    );
  } catch (err) {
    if (err instanceof MoneroRpcError && err.isTransient) {
      await revertToPending(withdrawalId);
      console.warn(
        `[Payout] Withdrawal #${withdrawalId} reverted to PENDING (${err.message}). Will retry automatically.`
      );
      return;
    }

    const errMsg = err instanceof Error ? err.message : String(err);
    await failAndRefundWithdrawal(withdrawalId, charId, amountUnits, errMsg);
    console.error(
      `[Payout] Withdrawal #${withdrawalId} FAILED & refunded ${amountUnits} units to CharID=${charId}: ${errMsg}`
    );
  }
}

/**
 * Poll PENDING withdrawals and process them sequentially with atomic row claiming.
 * @returns {Promise<void>}
 */
async function pollPendingWithdrawals() {
  if (isPolling || isShuttingDown) return;
  if (config.MONERO_RPC && config.MONERO_RPC.auto_transfer_enabled === false) {
    return;
  }

  isPolling = true;
  try {
    const [rows] = await dbPool.query(
      `SELECT id, account_id, char_id, wallet_address, amount_units, balance_snapshot
       FROM xmr_withdrawals
       WHERE status = 'PENDING'
       ORDER BY created_at ASC, id ASC
       LIMIT 25`
    );

    for (const row of rows) {
      if (isShuttingDown) break;

      const [claimRes] = await dbPool.execute(
        `UPDATE xmr_withdrawals SET status = 'PROCESSING' WHERE id = ? AND status = 'PENDING'`,
        [row.id]
      );

      if (claimRes.affectedRows !== 1) {
        continue;
      }

      await processWithdrawal(row);
    }
  } catch (err) {
    console.error(`[Payout] Poll cycle error: ${err.message}`);
  } finally {
    isPolling = false;
  }
}

/**
 * Initialize MySQL pool, ensure xmr_withdrawals table, and optionally run worker loop.
 * @returns {Promise<void>}
 */
async function main() {
  const initOnly = process.argv.includes('--init-only');

  dbPool = mysql.createPool({
    host: config.MYSQL.host,
    port: config.MYSQL.port || 3306,
    user: config.MYSQL.user,
    password: config.MYSQL.password,
    database: config.MYSQL.database,
    waitForConnections: true,
    connectionLimit: config.MYSQL.connectionLimit || 10,
    supportBigNumbers: true,
    bigNumberStrings: true
  });

  const conn = await dbPool.getConnection();
  await conn.ping();
  conn.release();
  console.log(`[Payout] Connected to MySQL (${config.MYSQL.host}:${config.MYSQL.port || 3306}/${config.MYSQL.database})`);

  await ensureSchema();
  console.log('[Payout] Verified table dbo_char.xmr_withdrawals');

  if (initOnly) {
    await dbPool.end();
    return;
  }

  if (process.argv.includes('--list-waiting')) {
    const [rows] = await dbPool.query(
      `SELECT id, char_id, wallet_address, amount_units, error_msg, created_at
       FROM xmr_withdrawals
       WHERE status = 'WAITING_ADMIN'
       ORDER BY id ASC`
    );
    console.log(JSON.stringify(rows, null, 2));
    await dbPool.end();
    return;
  }

  if (process.argv.includes('--approve-all')) {
    const [res] = await dbPool.execute(
      `UPDATE xmr_withdrawals
       SET status = 'PENDING', error_msg = NULL
       WHERE status = 'WAITING_ADMIN'`
    );
    console.log(`[Payout] Approved ${res.affectedRows} WAITING_ADMIN withdrawal(s) -> PENDING`);
    await dbPool.end();
    return;
  }

  const approveIdx = process.argv.indexOf('--approve');
  if (approveIdx !== -1 && process.argv[approveIdx + 1]) {
    const id = Number(process.argv[approveIdx + 1]);
    const [res] = await dbPool.execute(
      `UPDATE xmr_withdrawals
       SET status = 'PENDING', error_msg = NULL
       WHERE id = ? AND status = 'WAITING_ADMIN'`,
      [id]
    );
    console.log(`[Payout] Approved withdrawal #${id}: ${res.affectedRows} row(s) -> PENDING`);
    await dbPool.end();
    return;
  }

  const pollIntervalMs = Math.max(1000, Number(config.MONERO_RPC?.poll_interval_ms) || 10000);
  console.log(
    `[Payout] Worker started | RPC=${config.MONERO_RPC?.url || 'http://127.0.0.1:18082/json_rpc'} | ` +
    `poll=${pollIntervalMs}ms | auto_transfer=${config.MONERO_RPC?.auto_transfer_enabled !== false}`
  );

  await pollPendingWithdrawals();
  pollTimer = setInterval(pollPendingWithdrawals, pollIntervalMs);

  const shutdown = async () => {
    if (isShuttingDown) return;
    isShuttingDown = true;
    console.log('\n[Payout] Shutting down...');
    if (pollTimer) clearInterval(pollTimer);
    if (dbPool) await dbPool.end();
    process.exit(0);
  };

  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);
}

main().catch(async (err) => {
  console.error('[Payout] Fatal error:', err);
  if (dbPool) {
    try {
      await dbPool.end();
    } catch (_e) {
      // ignore cleanup error
    }
  }
  process.exit(1);
});
