@echo off
title OpenDBO XMR - Arrancar Todo (Plug and Play)
set "SERVER_DIR=G:\serverlocal dbo pasar a C\OpenDBO-Core\DboServer\ExecutionEnv"
set "BRIDGE_DIR=G:\serverlocal dbo pasar a C\CryptoPoolBridge"

echo [1/3] Iniciando CryptoPoolBridge (Pool, IPC, Payout)...
start "DBO Pool Server" /D "%BRIDGE_DIR%" cmd /c "node pool_server.js"
start "DBO CPU Worker IPC" /D "%BRIDGE_DIR%" cmd /c "node cpu_worker_ipc.js"
start "DBO XMR Payout Worker" /D "%BRIDGE_DIR%" cmd /c "node payout_worker.js"

echo [2/3] Iniciando Servidores DBO...
start "MasterServer" /D "%SERVER_DIR%" "%SERVER_DIR%\MasterServer.exe"
timeout /t 2 /nobreak >nul
start "QueryServer" /D "%SERVER_DIR%" "%SERVER_DIR%\QueryServer.exe"
timeout /t 2 /nobreak >nul
start "AuthServer" /D "%SERVER_DIR%" "%SERVER_DIR%\AuthServer.exe"
start "CharServer" /D "%SERVER_DIR%" "%SERVER_DIR%\CharServer.exe"
start "ChatServer" /D "%SERVER_DIR%" "%SERVER_DIR%\ChatServer.exe"
timeout /t 2 /nobreak >nul
start "GameServer" /D "%SERVER_DIR%" "%SERVER_DIR%\GameServer.exe" ".\config\GameServer.ini"

echo [3/3] Todo iniciado correctamente.
pause
