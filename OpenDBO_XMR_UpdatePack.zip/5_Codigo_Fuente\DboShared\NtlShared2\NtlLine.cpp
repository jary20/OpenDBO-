#include "stdafx.h"
//***********************************************************************************
//
//	File		:	NtlLine.h
//
//	Begin		:	2008-01-08
//
//	Copyright	:	 NTL-Inc Co., Ltd
//
//	Author		:	Jeong Ho, Rho   ( lleo52@ntl-inc.com )
//
//	Desc		:	Line Class
//
//***********************************************************************************

#include "NtlLine.h"


CNtlLine::CNtlLine()
{
	// ʱȭ  ʴ´
}


CNtlLine::CNtlLine(const CNtlVector& rBegin, const CNtlVector& rEnd)
{
	m_rBegin = rBegin;
	m_rEnd = rEnd;
}
