#include "precomp_dboclient.h"
#include "LoginGuiGroup.h"
#include "NtlDebug.h"
#include "NtlPLGuiManager.h"

#include "LogoGui.h"
#include "ContractGui.h"
#include "LoginGui.h"
#include "MsgBoxManager.h"


CLogInGuiGroup::CLogInGuiGroup()
: m_pLogoGui(NULL)
, m_pContractGui(NULL)
, m_pLogin(NULL)
{	
}

CLogInGuiGroup::~CLogInGuiGroup()
{
}


static void GuiBootTrace(const char* msg)
{
	FILE* f = NULL;
	if (fopen_s(&f, "boot_trace.txt", "a") == 0 && f) { fprintf(f, "%s\n", msg); fclose(f); }
}

RwBool CLogInGuiGroup::Create(void)
{
	NTL_FUNCTION("CLogInGuiGroup::Create");
	GuiBootTrace("CLogInGuiGroup::Create start");

	// logo gui
	m_pLogoGui = NTL_NEW CLogoGui("LogoGui");
	if(!m_pLogoGui->Create())
	{
		GuiBootTrace("FAIL: LogoGui->Create()");
		m_pLogoGui->Destroy(); 
		NTL_DELETE(m_pLogoGui);
		NTL_RETURN(FALSE);
	}
	CNtlPLGuiManager::GetInstance()->AddGui(m_pLogoGui); 
	GuiBootTrace("LogoGui->Create() ok");

	// contract gui
	m_pContractGui = NTL_NEW CContractGui("ContractGui");
	if (!m_pContractGui->Create())
	{
		GuiBootTrace("FAIL: ContractGui->Create()");
		m_pContractGui->Destroy();
		NTL_DELETE(m_pContractGui);
		NTL_RETURN(FALSE);
	}
	CNtlPLGuiManager::GetInstance()->AddGui(m_pContractGui);
	GuiBootTrace("ContractGui->Create() ok");

	// login gui
	m_pLogin = NTL_NEW CLogInGui("LogInGui");
	if(!m_pLogin->Create())
	{
		GuiBootTrace("FAIL: LogInGui->Create()");
		m_pLogin->Destroy(); 
		NTL_DELETE(m_pLogin);
		NTL_RETURN(FALSE);
	}
	CNtlPLGuiManager::GetInstance()->AddGui(m_pLogin); 
	GuiBootTrace("LogInGui->Create() ok");

	NTL_RETURN(TRUE);
}

void CLogInGuiGroup::Destroy(void)
{
	NTL_FUNCTION("CLogInGuiGroup::Destroy");

	if(m_pLogoGui)
	{
		CNtlPLGuiManager::GetInstance()->RemoveGui(m_pLogoGui);
		m_pLogoGui->Destroy();
		NTL_DELETE(m_pLogoGui);
	}

	if (m_pContractGui)
	{
		CNtlPLGuiManager::GetInstance()->RemoveGui(m_pContractGui);
		m_pContractGui->Destroy();
		NTL_DELETE(m_pContractGui);
	}

	if(m_pLogin)
	{
		CNtlPLGuiManager::GetInstance()->RemoveGui(m_pLogin);
		m_pLogin->Destroy();
		NTL_DELETE(m_pLogin);
	}



	NTL_RETURNVOID();
}