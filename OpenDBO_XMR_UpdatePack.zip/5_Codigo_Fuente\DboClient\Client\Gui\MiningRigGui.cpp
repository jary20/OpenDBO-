#include "precomp_dboclient.h"
#include "MiningRigGui.h"

// core
#include "NtlDebug.h"

// shared
#include "NtlItem.h"
#include "ItemTable.h"
#include "TextAllTable.h"
#include "TableContainer.h"
#include "NtlPacketGU.h"

// presentation
#include "NtlPLGuiManager.h"
#include "NtlPLEvent.h"

// simulation
#include "NtlSLGlobal.h"
#include "NtlSLEvent.h"
#include "NtlSobAvatar.h"
#include "NtlSobManager.h"
#include "NtlSobItem.h"
#include "NtlSobItemAttr.h"
#include "NtlSLLogic.h"
#include "NtlSLApi.h"

// dbo
#include "DboGlobal.h"
#include "DboDef.h"
#include "DboLogic.h"
#include "DboEvent.h"
#include "DboPacketGenerator.h"
#include "BagGui.h"
#include "DialogManager.h"
#include "DialogDefine.h"
#include "DialogPriority.h"
#include "DialogManager.h"
#include "IconMoveManager.h"
#include "AlarmManager.h"
#include "gui_texture.h"
#include "gui_texturemanager.h"

namespace
{
	const char*		MINING_PIPE_NAME				= "\\\\.\\pipe\\DBO_RandomX_Miner";
	const RwReal	MINING_STATUS_INTERVAL			= 0.5f;
	const RwReal	MINING_DURABILITY_WEAR_INTERVAL	= 3456.0f; // 25% cada 24h (100 dur = 96h)
	const RwInt32	MINING_DLG_WIDTH				= 480;
	const RwInt32	MINING_DLG_HEIGHT				= 516;

	gui::CSurface MakeSolidSurface(gui::CTexture* pTex, RwInt32 x, RwInt32 y, RwInt32 w, RwInt32 h, RwUInt8 r, RwUInt8 g, RwUInt8 b, RwUInt8 a)
	{
		gui::CSurface srf;
		srf.m_pTexture = pTex;
		srf.m_SnapShot.rtRect.SetRectWH(x, y, w, h);
		srf.m_SnapShot.uRed = r;
		srf.m_SnapShot.uGreen = g;
		srf.m_SnapShot.uBlue = b;
		srf.m_SnapShot.uAlpha = a;
		srf.m_SnapShot.UVs[0] = 0.0f;
		srf.m_SnapShot.UVs[1] = 0.0f;
		srf.m_SnapShot.UVs[2] = 1.0f;
		srf.m_SnapShot.UVs[3] = 1.0f;
		srf.m_SnapShot.uBlend = 0;
		srf.m_Original = srf.m_SnapShot;
		return srf;
	}

	VOID StyleSolidButton(gui::CButton* pBtn, gui::CTexture* pTex, RwInt32 w, RwInt32 h,
						  RwUInt8 upR, RwUInt8 upG, RwUInt8 upB,
						  RwUInt8 focR, RwUInt8 focG, RwUInt8 focB,
						  RwUInt8 dwnR, RwUInt8 dwnG, RwUInt8 dwnB)
	{
		if (!pBtn || !pTex)
			return;
		pBtn->AddSurfaceUp(MakeSolidSurface(pTex, 0, 0, w, h, upR, upG, upB, 240));
		pBtn->AddSurfaceFocus(MakeSolidSurface(pTex, 0, 0, w, h, focR, focG, focB, 255));
		pBtn->AddSurfaceDown(MakeSolidSurface(pTex, 0, 0, w, h, dwnR, dwnG, dwnB, 255));
		pBtn->AddSurfaceDisabled(MakeSolidSurface(pTex, 0, 0, w, h, 50, 50, 60, 180));
	}
}

CMiningRigGui::CMiningRigGui(const RwChar* pName)
	: CNtlPLGui(pName)
	, m_pstbTitle(NULL)
	, m_pstbRigHeader(NULL)
	, m_pstbThreadLabel(NULL)
	, m_pstbStatusLabel(NULL)
	, m_pstbHashrateLabel(NULL)
	, m_pstbSharesLabel(NULL)
	, m_pstbMinedZncLabel(NULL)
	, m_pstbRuleNotice(NULL)
	, m_pbtnClose(NULL)
	, m_pbtnThreadDown(NULL)
	, m_pbtnThreadUp(NULL)
	, m_pbtnToggleMining(NULL)
	, m_pbtnRepair(NULL)
	, m_pSolidTex(NULL)
	, m_nMaxAllowedThreads(DEFAULT_MIN_THREADS)
	, m_nSelectedThreads(DEFAULT_MIN_THREADS)
	, m_nTotalBonusPercent(0)
	, m_bMiningActive(FALSE)
	, m_fHashrate(0.0f)
	, m_dwAcceptedShares(0)
	, m_dwMinedZNC(0)
	, m_dwLastRepairMinedZNC(0)
	, m_hPipe(INVALID_HANDLE_VALUE)
	, m_fStatusPollTimer(0.0f)
	, m_fDurabilityWearTimer(0.0f)
	, m_bRestoredSavedSlots(FALSE)
	, m_bSuppressSave(FALSE)
	, m_pbtnNiceHash(NULL)
	, m_pbtnNiceHashConfig(NULL)
	, m_pstbNiceHashStatus(NULL)
	, m_pbtnNiceHashWeb(NULL)
	, m_pstbNiceHashWebLine1(NULL)
	, m_pstbNiceHashWebLine2(NULL)
	, m_ppnlNiceHashConfig(NULL)
	, m_pstbNhCfgTitle(NULL)
	, m_pstbNhCfgNotice(NULL)
	, m_pinpNhApiKey(NULL)
	, m_pinpNhApiSecret(NULL)
	, m_pinpNhOrgId(NULL)
	, m_pinpNhPoolId(NULL)
	, m_pbtnNhSave(NULL)
	, m_pbtnNhCancel(NULL)
	, m_pbtnXmrClaim(NULL)
	, m_ppnlXmrClaim(NULL)
	, m_pstbXmrTitle(NULL)
	, m_pstbXmrBalance(NULL)
	, m_pstbXmrMaxClaim(NULL)
	, m_pstbXmrCooldown(NULL)
	, m_pstbXmrNotice(NULL)
	, m_pinpXmrWallet(NULL)
	, m_pinpXmrAmount(NULL)
	, m_pbtnXmrMax50(NULL)
	, m_pbtnXmrSubmit(NULL)
	, m_pbtnXmrClose(NULL)
	, m_bNiceHashUnlocked(FALSE)
	, m_bNiceHashActive(FALSE)
	, m_bNiceHashConfigured(FALSE)
	, m_strNiceHashStatus("IDLE")
	, m_strNiceHashSpeed("0")
	, m_dwXmrBalanceUnits(0)
	, m_dwXmrMaxClaimUnits(0)
	, m_dwXmrCooldownRemainingSec(0)
	, m_byXmrCanClaim(0)
	, m_bXmrClaimPending(FALSE)
{
}

CMiningRigGui::~CMiningRigGui(VOID)
{
}

RwBool CMiningRigGui::Create(VOID)
{
	NTL_FUNCTION("CMiningRigGui::Create");

	CRectangle rtDlg(0, 0, MINING_DLG_WIDTH, MINING_DLG_HEIGHT);
	m_pThis = NTL_NEW gui::CDialog(&rtDlg, CNtlPLGuiManager::GetInstance()->GetGuiManager(), GetNtlGuiManager()->GetSurfaceManager());
	if (!m_pThis)
		NTL_RETURN(FALSE);

	m_pThis->SetPriority(dDIALOGPRIORITY_DEFAULT);
	m_pThis->SetMovable(TRUE);
	m_pThis->SetFrameSize(CRectangle(0, 0, MINING_DLG_WIDTH, 32));

	m_pSolidTex = g_TextureMgr.CreateTexture(4, 4);
	if (m_pSolidTex)
	{
		unsigned char* pBits = m_pSolidTex->LockWrite();
		if (pBits)
		{
			RwInt32 nStride = m_pSolidTex->GetStride();
			RwInt32 nHeight = m_pSolidTex->GetHeight();
			if (nStride > 0 && nHeight > 0)
			{
				memset(pBits, 0xFF, static_cast<size_t>(nStride * nHeight));
			}
			m_pSolidTex->UnLock();
		}

		// Outer border, dark body, title header bar, rig slots box, telemetry box, NiceHash web box
		m_pThis->AddSurface(MakeSolidSurface(m_pSolidTex, 0, 0, MINING_DLG_WIDTH, MINING_DLG_HEIGHT, 210, 175, 55, 245));
		m_pThis->AddSurface(MakeSolidSurface(m_pSolidTex, 2, 2, MINING_DLG_WIDTH - 4, MINING_DLG_HEIGHT - 4, 16, 20, 30, 238));
		m_pThis->AddSurface(MakeSolidSurface(m_pSolidTex, 2, 2, MINING_DLG_WIDTH - 4, 30, 32, 46, 78, 250));
		m_pThis->AddSurface(MakeSolidSurface(m_pSolidTex, 10, 60, MINING_DLG_WIDTH - 20, 134, 24, 30, 44, 230));
		m_pThis->AddSurface(MakeSolidSurface(m_pSolidTex, 10, 236, MINING_DLG_WIDTH - 20, 96, 12, 16, 24, 235));
		m_pThis->AddSurface(MakeSolidSurface(m_pSolidTex, 10, 404, MINING_DLG_WIDTH - 20, 74, 14, 20, 32, 235));
	}

	CreateControls();
	PositionAlign(GetDboGlobal()->GetScreenWidth(), GetDboGlobal()->GetScreenHeight());
	RecalculateRigStats();
	RefreshUI();

	Show(false);

	LinkMsg(g_EventIconMoveClick, 0);
	LinkMsg(g_EventSobInfoUpdate, 0);
	LinkMsg(g_EventResize, 0);
	LinkMsg(g_EventXmrClaimInfoRes, 0);
	LinkMsg(g_EventXmrClaimRes, 0);

	NTL_RETURN(TRUE);
}

VOID CMiningRigGui::Destroy(VOID)
{
	NTL_FUNCTION("CMiningRigGui::Destroy");

	if (m_bMiningActive)
	{
		SendPipeCommand("STOP\n");
		m_bMiningActive = FALSE;
	}

	ClosePipe();

	GetNtlGuiManager()->RemoveUpdateFuncWithoutRefCheck(this);

	UnLinkMsg(g_EventIconMoveClick);
	UnLinkMsg(g_EventSobInfoUpdate);
	UnLinkMsg(g_EventResize);
	UnLinkMsg(g_EventXmrClaimInfoRes);
	UnLinkMsg(g_EventXmrClaimRes);

	// CComponent::~CComponent() deletes all child controls automatically
	if (m_pThis)
	{
		NTL_DELETE(m_pThis);
		m_pThis = NULL;
	}

	if (m_pSolidTex)
	{
		g_TextureMgr.DeleteTexture(m_pSolidTex);
		m_pSolidTex = NULL;
	}

	m_pstbTitle = NULL;
	m_pstbRigHeader = NULL;
	m_pstbThreadLabel = NULL;
	m_pstbStatusLabel = NULL;
	m_pstbHashrateLabel = NULL;
	m_pstbSharesLabel = NULL;
	m_pstbMinedZncLabel = NULL;
	m_pstbRuleNotice = NULL;
	m_pbtnClose = NULL;
	m_pbtnThreadDown = NULL;
	m_pbtnThreadUp = NULL;
	m_pbtnToggleMining = NULL;
	m_pbtnRepair = NULL;
	m_pbtnNiceHashWeb = NULL;
	m_pstbNiceHashWebLine1 = NULL;
	m_pstbNiceHashWebLine2 = NULL;
	m_pbtnXmrClaim = NULL;
	m_ppnlXmrClaim = NULL;
	m_pstbXmrTitle = NULL;
	m_pstbXmrBalance = NULL;
	m_pstbXmrMaxClaim = NULL;
	m_pstbXmrCooldown = NULL;
	m_pstbXmrNotice = NULL;
	m_pinpXmrWallet = NULL;
	m_pinpXmrAmount = NULL;
	m_pbtnXmrMax50 = NULL;
	m_pbtnXmrSubmit = NULL;
	m_pbtnXmrClose = NULL;

	for (RwInt32 i = 0; i < MAX_RIG_SLOTS; ++i)
	{
		m_aRigSlots[i].pbtnSlot = NULL;
		m_aRigSlots[i].pstbSlotInfo = NULL;
	}

	NTL_RETURNVOID();
}

VOID CMiningRigGui::CreateControls(VOID)
{
	gui::CSurfaceManager* pSurMgr = GetNtlGuiManager()->GetSurfaceManager();

	m_pstbTitle = NTL_NEW gui::CStaticBox(CRectangle(16, 10, 360, 30), m_pThis, pSurMgr, COMP_TEXT_LEFT);
	m_pstbTitle->CreateFontStd(DEFAULT_FONT, DEFAULT_FONT_SIZE, DEFAULT_FONT_ATTR);
	m_pstbTitle->SetTextColor(INFOCOLOR_7);
	m_pstbTitle->SetText(L"Monero (XMR) CPU Mining Rig");
	m_pstbTitle->Enable(false);

	m_pbtnClose = NTL_NEW gui::CButton(CRectangle(MINING_DLG_WIDTH - 26, 8, MINING_DLG_WIDTH - 10, 24), m_pThis, pSurMgr);
	StyleSolidButton(m_pbtnClose, m_pSolidTex, 16, 16, 140, 35, 35, 190, 50, 50, 100, 20, 20);
	m_pbtnClose->SetText(L"X");
	m_slotClose = m_pbtnClose->SigClicked().Connect(this, &CMiningRigGui::OnClickedClose);

	m_pstbRigHeader = NTL_NEW gui::CStaticBox(CRectangle(16, 38, MINING_DLG_WIDTH - 16, 58), m_pThis, pSurMgr, COMP_TEXT_LEFT);
	m_pstbRigHeader->CreateFontStd(DEFAULT_FONT, DEFAULT_FONT_SIZE, DEFAULT_FONT_ATTR);
	m_pstbRigHeader->SetTextColor(INFOCOLOR_0);
	m_pstbRigHeader->SetText(L"Rig Slots (Equip up to 4 Charm/Card items):");
	m_pstbRigHeader->Enable(false);

	for (RwInt32 i = 0; i < MAX_RIG_SLOTS; ++i)
	{
		RwInt32 nTop = 64 + i * 32;

		m_aRigSlots[i].pbtnSlot = NTL_NEW gui::CButton(CRectangle(16, nTop, 96, nTop + 26), m_pThis, pSurMgr);
		StyleSolidButton(m_aRigSlots[i].pbtnSlot, m_pSolidTex, 80, 26, 42, 58, 90, 64, 90, 138, 30, 42, 66);
		WCHAR awcSlotBtn[32];
		swprintf_s(awcSlotBtn, 32, L"Slot %d", i + 1);
		m_aRigSlots[i].pbtnSlot->SetText(awcSlotBtn);
		m_aRigSlots[i].slotClicked = m_aRigSlots[i].pbtnSlot->SigClicked().Connect(this, &CMiningRigGui::OnClickedRigSlot);

		m_aRigSlots[i].pstbSlotInfo = NTL_NEW gui::CStaticBox(CRectangle(106, nTop + 3, MINING_DLG_WIDTH - 16, nTop + 25), m_pThis, pSurMgr, COMP_TEXT_LEFT);
		m_aRigSlots[i].pstbSlotInfo->CreateFontStd(DEFAULT_FONT, DEFAULT_FONT_SIZE, DEFAULT_FONT_ATTR);
		m_aRigSlots[i].pstbSlotInfo->SetTextColor(INFOCOLOR_9);
		m_aRigSlots[i].pstbSlotInfo->Enable(false);
	}

	m_pbtnThreadDown = NTL_NEW gui::CButton(CRectangle(16, 202, 44, 228), m_pThis, pSurMgr);
	StyleSolidButton(m_pbtnThreadDown, m_pSolidTex, 28, 26, 45, 65, 100, 70, 100, 150, 30, 45, 70);
	m_pbtnThreadDown->SetText(L"-");
	m_slotThreadDown = m_pbtnThreadDown->SigClicked().Connect(this, &CMiningRigGui::OnClickedThreadDown);

	m_pbtnThreadUp = NTL_NEW gui::CButton(CRectangle(50, 202, 78, 228), m_pThis, pSurMgr);
	StyleSolidButton(m_pbtnThreadUp, m_pSolidTex, 28, 26, 45, 65, 100, 70, 100, 150, 30, 45, 70);
	m_pbtnThreadUp->SetText(L"+");
	m_slotThreadUp = m_pbtnThreadUp->SigClicked().Connect(this, &CMiningRigGui::OnClickedThreadUp);

	m_pstbThreadLabel = NTL_NEW gui::CStaticBox(CRectangle(88, 205, MINING_DLG_WIDTH - 16, 227), m_pThis, pSurMgr, COMP_TEXT_LEFT);
	m_pstbThreadLabel->CreateFontStd(DEFAULT_FONT, DEFAULT_FONT_SIZE, DEFAULT_FONT_ATTR);
	m_pstbThreadLabel->SetTextColor(INFOCOLOR_0);
	m_pstbThreadLabel->Enable(false);

	m_pstbStatusLabel = NTL_NEW gui::CStaticBox(CRectangle(16, 240, MINING_DLG_WIDTH - 16, 260), m_pThis, pSurMgr, COMP_TEXT_LEFT);
	m_pstbStatusLabel->CreateFontStd(DEFAULT_FONT, DEFAULT_FONT_SIZE, DEFAULT_FONT_ATTR);
	m_pstbStatusLabel->SetTextColor(INFOCOLOR_13);
	m_pstbStatusLabel->Enable(false);

	m_pstbHashrateLabel = NTL_NEW gui::CStaticBox(CRectangle(16, 264, MINING_DLG_WIDTH - 16, 284), m_pThis, pSurMgr, COMP_TEXT_LEFT);
	m_pstbHashrateLabel->CreateFontStd(DEFAULT_FONT, DEFAULT_FONT_SIZE, DEFAULT_FONT_ATTR);
	m_pstbHashrateLabel->SetTextColor(INFOCOLOR_14);
	m_pstbHashrateLabel->Enable(false);

	m_pstbSharesLabel = NTL_NEW gui::CStaticBox(CRectangle(16, 288, MINING_DLG_WIDTH - 16, 308), m_pThis, pSurMgr, COMP_TEXT_LEFT);
	m_pstbSharesLabel->CreateFontStd(DEFAULT_FONT, DEFAULT_FONT_SIZE, DEFAULT_FONT_ATTR);
	m_pstbSharesLabel->SetTextColor(INFOCOLOR_0);
	m_pstbSharesLabel->Enable(false);

	m_pstbMinedZncLabel = NTL_NEW gui::CStaticBox(CRectangle(16, 312, MINING_DLG_WIDTH - 16, 332), m_pThis, pSurMgr, COMP_TEXT_LEFT);
	m_pstbMinedZncLabel->CreateFontStd(DEFAULT_FONT, DEFAULT_FONT_SIZE, DEFAULT_FONT_ATTR);
	m_pstbMinedZncLabel->SetTextColor(INFOCOLOR_7);
	m_pstbMinedZncLabel->Enable(false);

	m_pbtnToggleMining = NTL_NEW gui::CButton(CRectangle(16, 336, 232, 362), m_pThis, pSurMgr);
	StyleSolidButton(m_pbtnToggleMining, m_pSolidTex, 216, 26, 30, 110, 65, 45, 145, 85, 20, 80, 45);
	m_slotToggleMining = m_pbtnToggleMining->SigClicked().Connect(this, &CMiningRigGui::OnClickedToggleMining);

	m_pbtnRepair = NTL_NEW gui::CButton(CRectangle(248, 336, MINING_DLG_WIDTH - 16, 362), m_pThis, pSurMgr);
	StyleSolidButton(m_pbtnRepair, m_pSolidTex, 216, 26, 130, 85, 25, 165, 110, 35, 95, 60, 15);
	m_pbtnRepair->SetText(L"Repair Cards (-50% Stat)");
	m_slotRepair = m_pbtnRepair->SigClicked().Connect(this, &CMiningRigGui::OnClickedRepairCards);

	m_pbtnNiceHash = NTL_NEW gui::CButton(CRectangle(16, 370, 176, 396), m_pThis, pSurMgr);
	StyleSolidButton(m_pbtnNiceHash, m_pSolidTex, 160, 26, 170, 115, 20, 210, 145, 35, 130, 85, 15);
	m_pbtnNiceHash->SetText(L"NiceHash: Locked (0.25 XMR)");
	m_slotNiceHash = m_pbtnNiceHash->SigClicked().Connect(this, &CMiningRigGui::OnClickedNiceHash);

	m_pbtnNiceHashConfig = NTL_NEW gui::CButton(CRectangle(182, 370, 246, 396), m_pThis, pSurMgr);
	StyleSolidButton(m_pbtnNiceHashConfig, m_pSolidTex, 64, 26, 45, 70, 110, 70, 105, 155, 30, 48, 76);
	m_pbtnNiceHashConfig->SetText(L"Config");
	m_slotNiceHashConfig = m_pbtnNiceHashConfig->SigClicked().Connect(this, &CMiningRigGui::OnClickedNiceHashConfig);

	m_pstbNiceHashStatus = NTL_NEW gui::CStaticBox(CRectangle(254, 373, MINING_DLG_WIDTH - 16, 395), m_pThis, pSurMgr, COMP_TEXT_LEFT);
	m_pstbNiceHashStatus->CreateFontStd(DEFAULT_FONT, DEFAULT_FONT_SIZE, DEFAULT_FONT_ATTR);
	m_pstbNiceHashStatus->SetTextColor(INFOCOLOR_9);
	m_pstbNiceHashStatus->SetText(L"NiceHash: Requiere item 0.25 XMR");
	m_pstbNiceHashStatus->Enable(false);

	m_pbtnNiceHashWeb = NTL_NEW gui::CButton(CRectangle(16, 410, 246, 432), m_pThis, pSurMgr);
	StyleSolidButton(m_pbtnNiceHashWeb, m_pSolidTex, 230, 22, 32, 60, 102, 50, 90, 148, 22, 40, 70);
	m_pbtnNiceHashWeb->SetText(L"Web: https://www.nicehash.com");
	m_slotNiceHashWeb = m_pbtnNiceHashWeb->SigClicked().Connect(this, &CMiningRigGui::OnClickedNiceHashWeb);

	m_pbtnXmrClaim = NTL_NEW gui::CButton(CRectangle(254, 410, 464, 432), m_pThis, pSurMgr);
	StyleSolidButton(m_pbtnXmrClaim, m_pSolidTex, 210, 22, 34, 118, 68, 52, 158, 92, 24, 84, 48);
	m_pbtnXmrClaim->SetText(L"Reclamar XMR");
	m_slotXmrClaim = m_pbtnXmrClaim->SigClicked().Connect(this, &CMiningRigGui::OnClickedXmrClaim);

	m_pstbNiceHashWebLine1 = NTL_NEW gui::CStaticBox(CRectangle(16, 436, MINING_DLG_WIDTH - 16, 454), m_pThis, pSurMgr, COMP_TEXT_LEFT);
	m_pstbNiceHashWebLine1->CreateFontStd(DEFAULT_FONT, DEFAULT_FONT_SIZE, DEFAULT_FONT_ATTR);
	m_pstbNiceHashWebLine1->SetTextColor(INFOCOLOR_0);
	m_pstbNiceHashWebLine1->SetText(L"Compra aqui potencia de minado (Hashpower) para minar mas rapido.");
	m_pstbNiceHashWebLine1->Enable(false);

	m_pstbNiceHashWebLine2 = NTL_NEW gui::CStaticBox(CRectangle(16, 454, MINING_DLG_WIDTH - 16, 472), m_pThis, pSurMgr, COMP_TEXT_LEFT);
	m_pstbNiceHashWebLine2->CreateFontStd(DEFAULT_FONT, DEFAULT_FONT_SIZE, DEFAULT_FONT_ATTR);
	m_pstbNiceHashWebLine2->SetTextColor(INFOCOLOR_9);
	m_pstbNiceHashWebLine2->SetText(L"Crea tu API Key en NiceHash y pulsa Config para guardar tus credenciales.");
	m_pstbNiceHashWebLine2->Enable(false);

	m_pstbRuleNotice = NTL_NEW gui::CStaticBox(CRectangle(16, 484, MINING_DLG_WIDTH - 16, 506), m_pThis, pSurMgr, COMP_TEXT_CENTER);
	m_pstbRuleNotice->CreateFontStd(DEFAULT_FONT, DEFAULT_FONT_SIZE, DEFAULT_FONT_ATTR);
	m_pstbRuleNotice->SetTextColor(INFOCOLOR_9);
	m_pstbRuleNotice->SetText(L"Drop: CCBD 55+ (x5) | Trade: Auction House (Repaired) | Repair: -50% Stat");
	m_pstbRuleNotice->Enable(false);

	CreateNiceHashConfigPanel();
	CreateXmrClaimPanel();
}

RwInt32 CMiningRigGui::SwitchDialog(bool bOpen)
{
	if (bOpen)
	{
		RestoreSavedRigSlots();
		RecalculateRigStats();
		RaiseTop();
		PositionAlign(GetDboGlobal()->GetScreenWidth(), GetDboGlobal()->GetScreenHeight());
		Show(true);
		GetNtlGuiManager()->AddUpdateFunc(this);
		RefreshUI();
	}
	else
	{
		if (m_ppnlNiceHashConfig)
			m_ppnlNiceHashConfig->Show(false);
		if (m_ppnlXmrClaim)
			m_ppnlXmrClaim->Show(false);
		Show(false);
		if (!m_bMiningActive)
		{
			GetNtlGuiManager()->RemoveUpdateFunc(this);
		}
	}

	return 1;
}

VOID CMiningRigGui::Update(RwReal fElapsed)
{
	if (!IsShow() && !m_bMiningActive)
		return;

	PollPipeResponses();

	if (m_bMiningActive)
	{
		m_fDurabilityWearTimer += fElapsed;
		if (m_fDurabilityWearTimer >= MINING_DURABILITY_WEAR_INTERVAL)
		{
			m_fDurabilityWearTimer -= MINING_DURABILITY_WEAR_INTERVAL;

			RwBool bHasEquippedSlot = FALSE;
			RwBool bHasUsableSlot = FALSE;
			RwBool bDurabilityChanged = FALSE;

			for (RwInt32 i = 0; i < MAX_RIG_SLOTS; ++i)
			{
				if (m_aRigSlots[i].hItemSerial != INVALID_SERIAL_ID)
				{
					bHasEquippedSlot = TRUE;
					if (m_aRigSlots[i].tblidx == NICEHASH_LICENSE_ITEM_TBLIDX)
					{
						bHasUsableSlot = TRUE;
					}
					else if (m_aRigSlots[i].nDurability > 0)
					{
						--m_aRigSlots[i].nDurability;
						bDurabilityChanged = TRUE;
						if (m_aRigSlots[i].nDurability > 0)
						{
							bHasUsableSlot = TRUE;
						}
					}
				}
			}

			if (bHasEquippedSlot && !bHasUsableSlot)
			{
				SendPipeCommand("STOP\n");
				m_bMiningActive = FALSE;
				m_fHashrate = 0.0f;
				m_fDurabilityWearTimer = 0.0f;
				if (!IsShow())
				{
					GetNtlGuiManager()->RemoveUpdateFunc(this);
				}
			}

			if (bDurabilityChanged && IsShow())
			{
				RefreshUI();
			}
		}
	}

	m_fStatusPollTimer += fElapsed;
	if (m_fStatusPollTimer >= MINING_STATUS_INTERVAL)
	{
		m_fStatusPollTimer = 0.0f;

		if (m_bMiningActive || IsShow())
		{
			if (m_hPipe != INVALID_HANDLE_VALUE || ConnectPipeNonBlocking())
			{
				SendPipeCommand("STATUS\n");
				if (m_bNiceHashUnlocked)
					SendPipeCommand("NH_STATUS\n");
			}
		}

		if (IsShow())
		{
			RefreshUI();
		}
	}
}

VOID CMiningRigGui::HandleEvents(RWS::CMsg& msg)
{
	if (msg.Id == g_EventIconMoveClick)
	{
		if (!IsShow())
			return;

		// Check if user dropped an item from inventory onto one of our rig slot buttons
		RwBool bActive = (msg.pData != NULL) ? TRUE : FALSE;
		if (!bActive && GetIconMoveManager()->GetSrcPlace() == PLACE_BAG)
		{
			// Actual drop onto slot button is handled in OnClickedRigSlot when IconMoveManager is active
		}
	}
	else if (msg.Id == g_EventSobInfoUpdate)
	{
		RestoreSavedRigSlots();

		// Verify equipped rig items still exist in avatar inventory
		RwBool bChanged = FALSE;
		for (RwInt32 i = 0; i < MAX_RIG_SLOTS; ++i)
		{
			if (m_aRigSlots[i].hItemSerial != INVALID_SERIAL_ID)
			{
				if (GetNtlSobManager()->GetSobObject(m_aRigSlots[i].hItemSerial) == NULL)
				{
					UnequipRigSlot(i);
					bChanged = TRUE;
				}
			}
		}

		if (bChanged)
		{
			RecalculateRigStats();
			RefreshUI();
		}
	}
	else if (msg.Id == g_EventResize)
	{
		SNtlPLEventResize* pPacket = reinterpret_cast<SNtlPLEventResize*>(msg.pData);
		PositionAlign(pPacket->iWidht, pPacket->iHeight);
	}
	else if (msg.Id == g_EventXmrClaimInfoRes)
	{
		SDboEventXmrClaimInfoRes* pInfo = reinterpret_cast<SDboEventXmrClaimInfoRes*>(msg.pData);
		if (pInfo)
		{
			m_dwXmrBalanceUnits = pInfo->dwBalanceUnits;
			m_dwXmrMaxClaimUnits = pInfo->dwMaxClaimUnits;
			m_dwXmrCooldownRemainingSec = pInfo->dwCooldownRemainingSec;
			m_byXmrCanClaim = pInfo->byCanClaim;
			m_bXmrClaimPending = FALSE;
			RefreshXmrClaimPanel();

			if (m_pstbXmrNotice)
			{
				if (m_dwXmrBalanceUnits == 0)
					m_pstbXmrNotice->SetText(L"No tienes saldo XMR disponible para reclamar.");
				else if (!m_byXmrCanClaim)
					m_pstbXmrNotice->SetText(L"Debes esperar 7 dias entre reclamos.");
				else
					m_pstbXmrNotice->SetText(L"Ingresa tu wallet Monero y la cantidad (max 50%).");
			}
		}
	}
	else if (msg.Id == g_EventXmrClaimRes)
	{
		SDboEventXmrClaimRes* pRes = reinterpret_cast<SDboEventXmrClaimRes*>(msg.pData);
		if (pRes)
		{
			m_bXmrClaimPending = FALSE;
			m_dwXmrBalanceUnits = pRes->dwNewBalanceUnits;
			m_dwXmrMaxClaimUnits = m_dwXmrBalanceUnits / 2;
			m_dwXmrCooldownRemainingSec = pRes->dwCooldownRemainingSec;
			m_byXmrCanClaim = (m_dwXmrBalanceUnits > 0 && m_dwXmrCooldownRemainingSec == 0) ? 1 : 0;
			RefreshXmrClaimPanel();

			if (m_pstbXmrNotice)
			{
				WCHAR awcMsg[256] = { 0 };
				switch (pRes->wResultCode)
				{
				case XMR_CLAIM_RESULT_OK:
					swprintf_s(awcMsg, 256, L"Reclamo exitoso: %s XMR enviados.", Logic_FormatZeni(pRes->dwClaimedUnits, FALSE));
					break;
				case XMR_CLAIM_RESULT_NO_BALANCE:
					swprintf_s(awcMsg, 256, L"Error: No tienes saldo XMR disponible.");
					break;
				case XMR_CLAIM_RESULT_EXCEEDS_50_PCT:
					swprintf_s(awcMsg, 256, L"Error: El monto excede el maximo permitido (50%%).");
					break;
				case XMR_CLAIM_RESULT_COOLDOWN_7_DAYS:
					swprintf_s(awcMsg, 256, L"Error: Debes esperar el periodo de 7 dias.");
					break;
				case XMR_CLAIM_RESULT_INVALID_WALLET:
					swprintf_s(awcMsg, 256, L"Error: Direccion de wallet XMR invalida.");
					break;
				case XMR_CLAIM_RESULT_BELOW_MIN:
					swprintf_s(awcMsg, 256, L"Error: El minimo de reclamo es %s XMR.", Logic_FormatZeni(XMR_CLAIM_MIN_UNITS, FALSE));
					break;
				case XMR_CLAIM_RESULT_DB_ERROR:
				default:
					swprintf_s(awcMsg, 256, L"Error del servidor al procesar el reclamo (%u).", pRes->wResultCode);
					break;
				}
				m_pstbXmrNotice->SetText(awcMsg);
			}
		}
	}
}

static RwBool GetMiningMetalStats(TBLIDX tblidx, RwInt32& outMaxThreads, RwInt32& outBonusPercent)
{
	switch (tblidx)
	{
		case 2992004: // Frieza Metal
			outMaxThreads = 1;
			outBonusPercent = 0;
			return TRUE;
		case 2992001: // Darby Aluminum
			outMaxThreads = 2;
			outBonusPercent = 0;
			return TRUE;
		case 2992002: // Total Gold
			outMaxThreads = 4;
			outBonusPercent = 0;
			return TRUE;
		case 2992003: // Yadrat Metal -> Licencia NiceHash
			outMaxThreads = 0;
			outBonusPercent = 0;
			return TRUE;
		case 2992007: // Perak Steel
			outMaxThreads = 1;
			outBonusPercent = 30;
			return TRUE;
		default:
			return FALSE;
	}
}

RwBool CMiningRigGui::IsValidRigItem(CNtlSobItemAttr* pItemAttr) const
{
	if (!pItemAttr)
		return FALSE;

	sITEM_TBLDAT* pTbl = pItemAttr->GetItemTbl();
	if (!pTbl)
		return FALSE;

	RwInt32 nDummyThreads = 0;
	RwInt32 nDummyBonus = 0;
	return GetMiningMetalStats(pTbl->tblidx, nDummyThreads, nDummyBonus);
}

VOID CMiningRigGui::GetTierStatsForRank(RwUInt8 byRank, RwInt32& outMaxThreads, RwInt32& outBonusPercent) const
{
	switch (byRank)
	{
		case ITEM_RANK_NORMAL:
			outMaxThreads = 1;
			outBonusPercent = 5;
			break;
		case ITEM_RANK_SUPERIOR:
			outMaxThreads = 2;
			outBonusPercent = 15;
			break;
		case ITEM_RANK_EXCELLENT:
			outMaxThreads = 4;
			outBonusPercent = 30;
			break;
		case ITEM_RANK_RARE:
			outMaxThreads = 6;
			outBonusPercent = 50;
			break;
		case ITEM_RANK_LEGENDARY:
			outMaxThreads = MAX_HARDWARE_THREADS;
			outBonusPercent = 100;
			break;
		default:
			outMaxThreads = DEFAULT_MIN_THREADS;
			outBonusPercent = 0;
			break;
	}
}

static VOID RefreshOpenBags(VOID)
{
	for (RwInt32 dlgId = DIALOG_CAPSULE_1; dlgId <= DIALOG_CAPSULE_5; ++dlgId)
	{
		CBagBaseGui* pBagGui = dynamic_cast<CBagBaseGui*>(GetDialogManager()->GetDialog(dlgId));
		if (pBagGui)
		{
			pBagGui->UpdateData();
		}
	}
}

RwBool CMiningRigGui::IsItemEquipped(SERIAL_HANDLE hItemSerial) const
{
	if (hItemSerial == INVALID_SERIAL_ID)
		return FALSE;

	for (RwInt32 i = 0; i < MAX_RIG_SLOTS; ++i)
	{
		if (m_aRigSlots[i].hItemSerial == hItemSerial)
			return TRUE;
	}
	return FALSE;
}

static VOID GetMiningSlotsIniPath(char* pszOut, size_t nSize)
{
	GetModuleFileNameA(NULL, pszOut, static_cast<DWORD>(nSize));
	char* pSlash = strrchr(pszOut, '\\');
	if (pSlash)
	{
		*(pSlash + 1) = '\0';
		strcat_s(pszOut, nSize, "mining_rig_slots.ini");
	}
	else
	{
		strcpy_s(pszOut, nSize, "mining_rig_slots.ini");
	}
}

static VOID GetAvatarSectionName(char* pszOut, size_t nSize)
{
	const WCHAR* pwszName = Logic_GetAvatarName();
	if (pwszName && pwszName[0] != L'\0')
	{
		int nWritten = WideCharToMultiByte(CP_UTF8, 0, pwszName, -1, pszOut, static_cast<int>(nSize), NULL, NULL);
		if (nWritten > 0)
			return;
	}
	strcpy_s(pszOut, nSize, "Default");
}

VOID CMiningRigGui::SaveRigSlots(VOID) const
{
	if (m_bSuppressSave)
		return;

	char szIniPath[MAX_PATH] = { 0 };
	char szSection[128] = { 0 };
	GetMiningSlotsIniPath(szIniPath, sizeof(szIniPath));
	GetAvatarSectionName(szSection, sizeof(szSection));

	for (RwInt32 i = 0; i < MAX_RIG_SLOTS; ++i)
	{
		char szKeyBag[32], szKeyPos[32], szKeyTbl[32];
		sprintf_s(szKeyBag, sizeof(szKeyBag), "Slot%d_Bag", i);
		sprintf_s(szKeyPos, sizeof(szKeyPos), "Slot%d_Pos", i);
		sprintf_s(szKeyTbl, sizeof(szKeyTbl), "Slot%d_Tbl", i);

		int nBag = -1;
		int nPos = -1;
		unsigned int uTbl = 0;

		if (m_aRigSlots[i].hItemSerial != INVALID_SERIAL_ID)
		{
			CNtlSobItem* pItem = reinterpret_cast<CNtlSobItem*>(GetNtlSobManager()->GetSobObject(m_aRigSlots[i].hItemSerial));
			if (pItem)
			{
				CNtlSobItemAttr* pAttr = reinterpret_cast<CNtlSobItemAttr*>(pItem->GetSobAttr());
				sITEM_TBLDAT* pTbl = pAttr ? pAttr->GetItemTbl() : NULL;
				if (pTbl)
				{
					nBag = static_cast<int>(pItem->GetParentItemSlotIdx());
					nPos = static_cast<int>(pItem->GetItemSlotIdx());
					uTbl = static_cast<unsigned int>(pTbl->tblidx);
				}
			}
		}

		char szVal[32];
		sprintf_s(szVal, sizeof(szVal), "%d", nBag);
		WritePrivateProfileStringA(szSection, szKeyBag, szVal, szIniPath);
		sprintf_s(szVal, sizeof(szVal), "%d", nPos);
		WritePrivateProfileStringA(szSection, szKeyPos, szVal, szIniPath);
		sprintf_s(szVal, sizeof(szVal), "%u", uTbl);
		WritePrivateProfileStringA(szSection, szKeyTbl, szVal, szIniPath);
	}
}

VOID CMiningRigGui::RestoreSavedRigSlots(VOID)
{
	if (m_bRestoredSavedSlots)
		return;

	CNtlSobAvatar* pAvatar = GetNtlSLGlobal()->GetSobAvatar();
	if (!pAvatar)
		return;

	CNtlInventory* pInventory = pAvatar->GetInventory();
	if (!pInventory || pInventory->GetBagItem(0) == INVALID_SERIAL_ID)
		return;

	char szIniPath[MAX_PATH] = { 0 };
	char szSection[128] = { 0 };
	GetMiningSlotsIniPath(szIniPath, sizeof(szIniPath));
	GetAvatarSectionName(szSection, sizeof(szSection));

	m_bRestoredSavedSlots = TRUE;
	m_bSuppressSave = TRUE;

	for (RwInt32 i = 0; i < MAX_RIG_SLOTS; ++i)
	{
		if (m_aRigSlots[i].hItemSerial != INVALID_SERIAL_ID)
			continue;

		char szKeyBag[32], szKeyPos[32], szKeyTbl[32];
		sprintf_s(szKeyBag, sizeof(szKeyBag), "Slot%d_Bag", i);
		sprintf_s(szKeyPos, sizeof(szKeyPos), "Slot%d_Pos", i);
		sprintf_s(szKeyTbl, sizeof(szKeyTbl), "Slot%d_Tbl", i);

		int nBag = GetPrivateProfileIntA(szSection, szKeyBag, -1, szIniPath);
		int nPos = GetPrivateProfileIntA(szSection, szKeyPos, -1, szIniPath);
		unsigned int uTbl = GetPrivateProfileIntA(szSection, szKeyTbl, 0, szIniPath);

		if (nBag < 0 || nPos < 0 || uTbl == 0)
			continue;

		SERIAL_HANDLE hBagSerial = pInventory->GetBagItem(nBag);
		if (hBagSerial == INVALID_SERIAL_ID)
			continue;

		CNtlSobItem* pBag = reinterpret_cast<CNtlSobItem*>(GetNtlSobManager()->GetSobObject(hBagSerial));
		CNtlSobItem* pItem = pBag ? pBag->GetChildItem(nPos) : NULL;
		if (!pItem)
			continue;

		CNtlSobItemAttr* pAttr = reinterpret_cast<CNtlSobItemAttr*>(pItem->GetSobAttr());
		sITEM_TBLDAT* pTbl = pAttr ? pAttr->GetItemTbl() : NULL;
		if (pTbl && static_cast<unsigned int>(pTbl->tblidx) == uTbl)
		{
			EquipRigSlot(i, pItem->GetSerialID());
		}
	}

	m_bSuppressSave = FALSE;
	RefreshOpenBags();
}

RwBool CMiningRigGui::IsItemEquippedInAnyRig(SERIAL_HANDLE hItemSerial)
{
	if (hItemSerial == INVALID_SERIAL_ID)
		return FALSE;

	CMiningRigGui* pRigGui = dynamic_cast<CMiningRigGui*>(GetDialogManager()->GetDialog(DIALOG_MINING_RIG));
	if (!pRigGui)
		return FALSE;

	if (!pRigGui->m_bRestoredSavedSlots)
		pRigGui->RestoreSavedRigSlots();

	return pRigGui->IsItemEquipped(hItemSerial);
}

RwBool CMiningRigGui::EquipRigSlot(RwInt32 nSlotIdx, SERIAL_HANDLE hItemSerial)
{
	if (nSlotIdx < 0 || nSlotIdx >= MAX_RIG_SLOTS || hItemSerial == INVALID_SERIAL_ID)
		return FALSE;

	// Prevent equipping the same item in multiple slots
	for (RwInt32 i = 0; i < MAX_RIG_SLOTS; ++i)
	{
		if (m_aRigSlots[i].hItemSerial == hItemSerial)
			return FALSE;
	}

	CNtlSobItem* pItem = reinterpret_cast<CNtlSobItem*>(GetNtlSobManager()->GetSobObject(hItemSerial));
	if (!pItem)
		return FALSE;

	CNtlSobItemAttr* pItemAttr = reinterpret_cast<CNtlSobItemAttr*>(pItem->GetSobAttr());
	if (!IsValidRigItem(pItemAttr))
		return FALSE;

	sITEM_TBLDAT* pTbl = pItemAttr->GetItemTbl();
	RwUInt8 byRank = pItemAttr->GetRank();
	RwUInt8 byRepairCount = pItemAttr->GetGrade();
	RwInt32 nThreads = DEFAULT_MIN_THREADS;
	RwInt32 nBonus = 0;
	if (!pTbl || !GetMiningMetalStats(pTbl->tblidx, nThreads, nBonus))
		return FALSE;

	if (!pTbl || pTbl->tblidx != NICEHASH_LICENSE_ITEM_TBLIDX)
	{
		for (RwUInt8 r = 0; r < byRepairCount; ++r)
		{
			nThreads = (nThreads > 1) ? (nThreads / 2) : 1;
			nBonus /= 2;
		}
	}

	RwBool bIsNiceHashLicense = (pTbl && pTbl->tblidx == NICEHASH_LICENSE_ITEM_TBLIDX);
	RwInt32 nMaxDur = bIsNiceHashLicense ? 0 : ((pTbl && pTbl->byDurability != INVALID_BYTE && pTbl->byDurability > 0) ? pTbl->byDurability : 100);
	RwInt32 nCurDur = bIsNiceHashLicense ? 0 : ((pTbl && pTbl->byDurability != INVALID_BYTE && pTbl->byDurability > 0) ? pItemAttr->GetDur() : nMaxDur);
	std::wstring wstrName = L"Rig Card";
	if (pTbl)
	{
		if (pTbl->tblidx == NICEHASH_LICENSE_ITEM_TBLIDX)
		{
			wstrName = L"Licencia NiceHash";
		}
		else
		{
			CTextTable* pItemTextTbl = API_GetTableContainer()->GetTextAllTable()->GetItemTbl();
			if (pItemTextTbl)
			{
				wstrName = pItemTextTbl->GetText(pTbl->Name);
			}
		}
	}

	m_aRigSlots[nSlotIdx].hItemSerial = hItemSerial;
	m_aRigSlots[nSlotIdx].tblidx = pTbl ? pTbl->tblidx : INVALID_TBLIDX;
	m_aRigSlots[nSlotIdx].byRank = byRank;
	m_aRigSlots[nSlotIdx].byRepairCount = byRepairCount;
	m_aRigSlots[nSlotIdx].nDurability = nCurDur;
	m_aRigSlots[nSlotIdx].nMaxDurability = nMaxDur;
	m_aRigSlots[nSlotIdx].nMaxThreads = nThreads;
	m_aRigSlots[nSlotIdx].nBonusPercent = nBonus;
	m_aRigSlots[nSlotIdx].wstrItemName = wstrName;

	RecalculateRigStats();
	RefreshUI();
	SaveRigSlots();
	RefreshOpenBags();
	return TRUE;
}

VOID CMiningRigGui::UnequipRigSlot(RwInt32 nSlotIdx)
{
	if (nSlotIdx < 0 || nSlotIdx >= MAX_RIG_SLOTS)
		return;

	m_aRigSlots[nSlotIdx].hItemSerial = INVALID_SERIAL_ID;
	m_aRigSlots[nSlotIdx].tblidx = INVALID_TBLIDX;
	m_aRigSlots[nSlotIdx].byRank = 0;
	m_aRigSlots[nSlotIdx].nMaxThreads = 0;
	m_aRigSlots[nSlotIdx].nBonusPercent = 0;
	m_aRigSlots[nSlotIdx].wstrItemName.clear();
	SaveRigSlots();
	RefreshOpenBags();
}

VOID CMiningRigGui::ClearAllRigSlots(VOID)
{
	for (RwInt32 i = 0; i < MAX_RIG_SLOTS; ++i)
	{
		UnequipRigSlot(i);
	}
	RecalculateRigStats();
	RefreshOpenBags();
}

VOID CMiningRigGui::RecalculateRigStats(VOID)
{
	RwInt32 nTotalThreads = 0;
	RwInt32 nTotalBonus = 0;
	RwBool bNiceHashUnlocked = FALSE;

	for (RwInt32 i = 0; i < MAX_RIG_SLOTS; ++i)
	{
		if (m_aRigSlots[i].hItemSerial != INVALID_SERIAL_ID)
		{
			nTotalThreads += m_aRigSlots[i].nMaxThreads;
			nTotalBonus += m_aRigSlots[i].nBonusPercent;
			if (m_aRigSlots[i].tblidx == NICEHASH_LICENSE_ITEM_TBLIDX)
			{
				bNiceHashUnlocked = TRUE;
			}
		}
	}
	m_bNiceHashUnlocked = bNiceHashUnlocked;

	if (nTotalThreads < DEFAULT_MIN_THREADS)
		nTotalThreads = DEFAULT_MIN_THREADS;
	if (nTotalThreads > MAX_HARDWARE_THREADS)
		nTotalThreads = MAX_HARDWARE_THREADS;

	m_nMaxAllowedThreads = nTotalThreads;
	m_nTotalBonusPercent = nTotalBonus;

	if (m_nSelectedThreads < DEFAULT_MIN_THREADS)
		m_nSelectedThreads = DEFAULT_MIN_THREADS;
	if (m_nSelectedThreads > m_nMaxAllowedThreads)
		m_nSelectedThreads = m_nMaxAllowedThreads;
}

VOID CMiningRigGui::RefreshUI(VOID)
{
	WCHAR awcBuf[256];

	for (RwInt32 i = 0; i < MAX_RIG_SLOTS; ++i)
	{
		if (!m_aRigSlots[i].pstbSlotInfo)
			continue;

		if (m_aRigSlots[i].hItemSerial == INVALID_SERIAL_ID)
		{
			m_aRigSlots[i].pstbSlotInfo->SetTextColor(INFOCOLOR_9);
			m_aRigSlots[i].pstbSlotInfo->SetText(L"[Vacio] Click con Metal de Mineria para equipar");
		}
		else
		{
			m_aRigSlots[i].pstbSlotInfo->SetTextColor(INFOCOLOR_4);
			if (m_aRigSlots[i].tblidx == NICEHASH_LICENSE_ITEM_TBLIDX)
			{
				swprintf_s(awcBuf, 256, L"%s (Activa NiceHash | Sin durabilidad)",
					m_aRigSlots[i].wstrItemName.c_str());
			}
			else
			{
				swprintf_s(awcBuf, 256, L"%s (%dT, +%d%%, Dur:%d/%d, Rep:%u)",
					m_aRigSlots[i].wstrItemName.c_str(),
					m_aRigSlots[i].nMaxThreads,
					m_aRigSlots[i].nBonusPercent,
					m_aRigSlots[i].nDurability,
					m_aRigSlots[i].nMaxDurability,
					m_aRigSlots[i].byRepairCount);
			}
			m_aRigSlots[i].pstbSlotInfo->SetText(awcBuf);
		}
	}

	if (m_pstbThreadLabel)
	{
		swprintf_s(awcBuf, 256, L"CPU Threads: %d / %d  (Rig Bonus: +%d%%)",
			m_nSelectedThreads, m_nMaxAllowedThreads, m_nTotalBonusPercent);
		m_pstbThreadLabel->SetText(awcBuf);
	}

	if (m_pstbStatusLabel)
	{
		const WCHAR* pwszState = L"Idle (Miner Disconnected)";
		if (m_bMiningActive && m_hPipe != INVALID_HANDLE_VALUE)
			pwszState = L"Mining Active (RandomX)";
		else if (m_bMiningActive)
			pwszState = L"Mining Active (Reconnecting Pipe...)";
		else if (m_hPipe != INVALID_HANDLE_VALUE)
			pwszState = L"Idle (Pipe Connected)";

		swprintf_s(awcBuf, 256, L"Status: %s", pwszState);
		m_pstbStatusLabel->SetText(awcBuf);
	}

	if (m_pstbHashrateLabel)
	{
		swprintf_s(awcBuf, 256, L"Hashrate: %.2f H/s", m_fHashrate);
		m_pstbHashrateLabel->SetText(awcBuf);
	}

	if (m_pstbSharesLabel)
	{
		swprintf_s(awcBuf, 256, L"Accepted Shares: %u", m_dwAcceptedShares);
		m_pstbSharesLabel->SetText(awcBuf);
	}

	if (m_pstbMinedZncLabel)
	{
		swprintf_s(awcBuf, 256, L"Mined XMR: %s", Logic_FormatZeni(m_dwMinedZNC, TRUE));
		m_pstbMinedZncLabel->SetText(awcBuf);
	}

	if (m_pbtnToggleMining)
	{
		m_pbtnToggleMining->SetText(m_bMiningActive ? L"Stop CPU Mining" : L"Start CPU Mining");
	}

	if (m_pbtnRepair)
	{
		RwUInt32 dwRepairCost = GetRepairCostZNC();
		swprintf_s(awcBuf, 256, L"Repair (-50%% Stat | %s XMR)", Logic_FormatZeni(dwRepairCost, FALSE));
		m_pbtnRepair->SetText(awcBuf);
	}

	if (m_pbtnNiceHash)
	{
		if (!m_bNiceHashUnlocked)
			m_pbtnNiceHash->SetText(L"NiceHash: Locked (0.25 XMR)");
		else if (m_bNiceHashActive)
			m_pbtnNiceHash->SetText(L"Stop NiceHash Order");
		else
			m_pbtnNiceHash->SetText(L"Start NiceHash Order");
	}

	if (m_pstbNiceHashStatus)
	{
		if (!m_bNiceHashUnlocked)
		{
			m_pstbNiceHashStatus->SetTextColor(INFOCOLOR_9);
			m_pstbNiceHashStatus->SetText(L"Equipa Licencia NiceHash (0.25 XMR)");
		}
		else if (!m_bNiceHashConfigured)
		{
			m_pstbNiceHashStatus->SetTextColor(INFOCOLOR_7);
			m_pstbNiceHashStatus->SetText(L"Pulsa 'Config' para credenciales");
		}
		else
		{
			WCHAR awcNhStatus[64] = { 0 };
			WCHAR awcNhSpeed[32] = { 0 };
			MultiByteToWideChar(CP_UTF8, 0, m_strNiceHashStatus.c_str(), -1, awcNhStatus, 64);
			MultiByteToWideChar(CP_UTF8, 0, m_strNiceHashSpeed.c_str(), -1, awcNhSpeed, 32);
			m_pstbNiceHashStatus->SetTextColor(m_bNiceHashActive ? INFOCOLOR_4 : INFOCOLOR_0);
			swprintf_s(awcBuf, 256, L"NH: %s | %s", awcNhStatus, awcNhSpeed);
			m_pstbNiceHashStatus->SetText(awcBuf);
		}
	}
}

VOID CMiningRigGui::PositionAlign(RwInt32 nScreenWidth, RwInt32 nScreenHeight)
{
	if (!m_pThis)
		return;

	RwInt32 nX = (nScreenWidth - MINING_DLG_WIDTH) / 2;
	RwInt32 nY = (nScreenHeight - MINING_DLG_HEIGHT) / 2;
	m_pThis->SetPosition(nX, nY);
}

RwBool CMiningRigGui::ConnectPipeNonBlocking(VOID)
{
	if (m_hPipe != INVALID_HANDLE_VALUE)
		return TRUE;

	// CreateFileA on a named pipe returns immediately if the pipe does not exist.
	HANDLE hPipe = ::CreateFileA(
		MINING_PIPE_NAME,
		GENERIC_READ | GENERIC_WRITE,
		0,
		NULL,
		OPEN_EXISTING,
		0,
		NULL);

	if (hPipe == INVALID_HANDLE_VALUE)
		return FALSE;

	// Switch to PIPE_NOWAIT so ReadFile / WriteFile never block the DX9 thread.
	DWORD dwMode = PIPE_READMODE_BYTE | PIPE_NOWAIT;
	if (!::SetNamedPipeHandleState(hPipe, &dwMode, NULL, NULL))
	{
		::CloseHandle(hPipe);
		return FALSE;
	}

	m_hPipe = hPipe;
	m_strPipeRecvBuffer.clear();
	return TRUE;
}

VOID CMiningRigGui::ClosePipe(VOID)
{
	if (m_hPipe != INVALID_HANDLE_VALUE)
	{
		::CloseHandle(m_hPipe);
		m_hPipe = INVALID_HANDLE_VALUE;
	}
	m_strPipeRecvBuffer.clear();
}

RwBool CMiningRigGui::SendPipeCommand(const std::string& strCmd)
{
	if (m_hPipe == INVALID_HANDLE_VALUE && !ConnectPipeNonBlocking())
		return FALSE;

	DWORD dwWritten = 0;
	BOOL bOk = ::WriteFile(
		m_hPipe,
		strCmd.c_str(),
		static_cast<DWORD>(strCmd.size()),
		&dwWritten,
		NULL);

	if (!bOk)
	{
		DWORD dwErr = ::GetLastError();
		if (dwErr != ERROR_NO_DATA && dwErr != ERROR_IO_PENDING)
		{
			ClosePipe();
		}
		return FALSE;
	}

	return (dwWritten == static_cast<DWORD>(strCmd.size()));
}

VOID CMiningRigGui::PollPipeResponses(VOID)
{
	if (m_hPipe == INVALID_HANDLE_VALUE)
		return;

	char szBuf[512];
	for (RwInt32 nIter = 0; nIter < 8; ++nIter)
	{
		DWORD dwRead = 0;
		BOOL bOk = ::ReadFile(m_hPipe, szBuf, sizeof(szBuf) - 1, &dwRead, NULL);
		if (!bOk)
		{
			DWORD dwErr = ::GetLastError();
			if (dwErr == ERROR_NO_DATA || dwErr == ERROR_IO_PENDING)
				break;

			if (dwErr == ERROR_BROKEN_PIPE || dwErr == ERROR_PIPE_NOT_CONNECTED)
			{
				ClosePipe();
			}
			break;
		}

		if (dwRead == 0)
			break;

		szBuf[dwRead] = '\0';
		m_strPipeRecvBuffer.append(szBuf, dwRead);

		size_t nPos = std::string::npos;
		while ((nPos = m_strPipeRecvBuffer.find('\n')) != std::string::npos)
		{
			std::string strLine = m_strPipeRecvBuffer.substr(0, nPos);
			m_strPipeRecvBuffer.erase(0, nPos + 1);
			if (!strLine.empty() && strLine[strLine.size() - 1] == '\r')
				strLine.erase(strLine.size() - 1);

			if (!strLine.empty())
				ParsePipeLine(strLine);
		}
	}
}

VOID CMiningRigGui::ParsePipeLine(const std::string& strLine)
{
	// Expected format: "STATUS <hashrate> <shares> <mined_znc>"
	float fHashrate = 0.0f;
	unsigned int uShares = 0;
	unsigned int uZnc = 0;

	if (sscanf_s(strLine.c_str(), "STATUS %f %u %u", &fHashrate, &uShares, &uZnc) == 3)
	{
		m_fHashrate = fHashrate;
		m_dwAcceptedShares = uShares;
		m_dwMinedZNC = uZnc;
		return;
	}

	int nConfigured = 0;
	int nActive = 0;
	char szOrderId[64] = { 0 };
	char szSpeed[32] = { 0 };
	char szStatus[64] = { 0 };
	if (sscanf_s(strLine.c_str(), "NH_STATUS %d %d %63s %31s %63s",
		&nConfigured, &nActive,
		szOrderId, static_cast<unsigned>(_countof(szOrderId)),
		szSpeed, static_cast<unsigned>(_countof(szSpeed)),
		szStatus, static_cast<unsigned>(_countof(szStatus))) == 5)
	{
		m_bNiceHashConfigured = (nConfigured != 0);
		m_bNiceHashActive = (nActive != 0);
		m_strNiceHashSpeed = szSpeed;
		m_strNiceHashStatus = szStatus;
		return;
	}

	if (strncmp(strLine.c_str(), "OK NH_STARTED", 13) == 0)
	{
		m_bNiceHashActive = TRUE;
		m_strNiceHashStatus = "ACTIVE";
		RefreshUI();
		return;
	}

	if (strncmp(strLine.c_str(), "OK NH_STOPPED", 13) == 0)
	{
		m_bNiceHashActive = FALSE;
		m_strNiceHashStatus = "IDLE";
		m_strNiceHashSpeed = "0";
		RefreshUI();
		return;
	}

	if (strncmp(strLine.c_str(), "ERR NH_NOT_CONFIGURED", 21) == 0)
	{
		m_bNiceHashConfigured = FALSE;
		m_strNiceHashStatus = "CONFIG_NEEDED";
		RefreshUI();
		return;
	}

	char szApiKey[160] = { 0 };
	char szOrgId[160] = { 0 };
	char szPoolId[160] = { 0 };
	int nHasSecret = 0;
	if (sscanf_s(strLine.c_str(), "NH_CONFIG %159s %159s %159s %d",
		szApiKey, static_cast<unsigned>(_countof(szApiKey)),
		szOrgId, static_cast<unsigned>(_countof(szOrgId)),
		szPoolId, static_cast<unsigned>(_countof(szPoolId)),
		&nHasSecret) == 4)
	{
		if (m_pinpNhApiKey && strcmp(szApiKey, "NONE") != 0)
			m_pinpNhApiKey->SetText(szApiKey);
		if (m_pinpNhOrgId && strcmp(szOrgId, "NONE") != 0)
			m_pinpNhOrgId->SetText(szOrgId);
		if (m_pinpNhPoolId && strcmp(szPoolId, "NONE") != 0)
			m_pinpNhPoolId->SetText(szPoolId);
		if (m_pstbNhCfgNotice)
		{
			m_pstbNhCfgNotice->SetTextColor(INFOCOLOR_0);
			m_pstbNhCfgNotice->SetText(nHasSecret ? L"Introduce tu API Secret para actualizar y guardar" : L"Introduce tus 4 credenciales API v2 de NiceHash");
		}
		return;
	}

	if (strncmp(strLine.c_str(), "OK NH_CONFIG_SAVED", 18) == 0)
	{
		int nCfg = 0;
		sscanf_s(strLine.c_str(), "OK NH_CONFIG_SAVED %d", &nCfg);
		m_bNiceHashConfigured = (nCfg != 0);
		if (m_ppnlNiceHashConfig)
			m_ppnlNiceHashConfig->Show(false);
		RefreshUI();
		GetAlarmManager()->AlarmMessage(L"Credenciales de NiceHash guardadas correctamente.", CAlarmManager::ALARM_TYPE_CHAT_WARN);
		return;
	}

	if (strncmp(strLine.c_str(), "ERR NH_CONFIG_FIELDS_REQUIRED", 29) == 0)
	{
		if (m_pstbNhCfgNotice)
		{
			m_pstbNhCfgNotice->SetTextColor(INFOCOLOR_5);
			m_pstbNhCfgNotice->SetText(L"Rellena los 4 campos antes de guardar!");
		}
		return;
	}
}

std::string CMiningRigGui::GetWorkerId(VOID) const
{
	const WCHAR* pwszName = Logic_GetAvatarName();
	if (pwszName && pwszName[0] != L'\0')
	{
		char szName[96] = { 0 };
		int nWritten = WideCharToMultiByte(CP_UTF8, 0, pwszName, -1, szName, sizeof(szName), NULL, NULL);
		if (nWritten > 0)
		{
			for (int i = 0; szName[i] != '\0'; ++i)
			{
				if (szName[i] == ' ' || szName[i] == '\t' || szName[i] == '\r' || szName[i] == '\n')
					szName[i] = '_';
			}
			return std::string("name_") + szName;
		}
	}

	CNtlSobAvatar* pAvatar = GetNtlSLGlobal()->GetSobAvatar();
	if (!pAvatar)
		return "dbo_worker";

	char szWorker[64];
	sprintf_s(szWorker, 64, "dbo_%u", static_cast<unsigned int>(pAvatar->GetSerialID()));
	return std::string(szWorker);
}

VOID CMiningRigGui::OnClickedClose(gui::CComponent* pComponent)
{
	GetDialogManager()->CloseDialog(DIALOG_MINING_RIG);
}

VOID CMiningRigGui::OnClickedNiceHash(gui::CComponent* pComponent)
{
	if (!m_bNiceHashUnlocked)
	{
		GetAlarmManager()->AlarmMessage(L"Compra la Licencia NiceHash (0.25 XMR) en la tienda y equipala en un slot para usar NiceHash.", CAlarmManager::ALARM_TYPE_CHAT_WARN);
		return;
	}

	if (!ConnectPipeNonBlocking())
	{
		GetAlarmManager()->AlarmMessage(L"No se pudo conectar con CryptoPoolBridge (cpu_worker_ipc.js).", CAlarmManager::ALARM_TYPE_CHAT_WARN);
		return;
	}

	if (m_bNiceHashActive)
	{
		SendPipeCommand("NH_STOP\n");
	}
	else
	{
		if (!m_bNiceHashConfigured)
		{
			OpenNiceHashConfigPanel();
			return;
		}
		SendPipeCommand("NH_START\n");
	}
	SendPipeCommand("NH_STATUS\n");
}

static gui::CInputBox* CreateNhInputBox(gui::CPanel* pParent, gui::CSurfaceManager* pSurMgr, RwInt32 nX, RwInt32 nY, RwInt32 nW, RwInt32 nH, RwBool bPassword)
{
	gui::CInputBox* pInput = NTL_NEW gui::CInputBox(CRectangle(nX, nY, nX + nW, nY + nH), pParent, pSurMgr);
	pInput->SetMaxLength(128);
	pInput->SetWidth(nW - 8);
	pInput->SetHeight(nH - 4);
	pInput->SetTextColor(RGB(240, 248, 255));
	pInput->SetCaretSize(2, 14);
	pInput->SetReadOnly(FALSE);
	pInput->Enable(true);
	if (bPassword)
		pInput->SetPasswordMode(TRUE);
	pInput->SetText(L"");
	return pInput;
}

VOID CMiningRigGui::CreateNiceHashConfigPanel(VOID)
{
	gui::CSurfaceManager* pSurMgr = GetNtlGuiManager()->GetSurfaceManager();

	m_ppnlNiceHashConfig = NTL_NEW gui::CPanel(CRectangle(48, 72, 432, 424), m_pThis, pSurMgr);
	if (m_pSolidTex)
	{
		m_ppnlNiceHashConfig->AddSurface(MakeSolidSurface(m_pSolidTex, 0, 0, 384, 352, 14, 18, 28, 248));
		m_ppnlNiceHashConfig->AddSurface(MakeSolidSurface(m_pSolidTex, 2, 2, 380, 28, 36, 52, 88, 255));
		// Dark backgrounds for the 4 input boxes
		m_ppnlNiceHashConfig->AddSurface(MakeSolidSurface(m_pSolidTex, 16, 62, 352, 24, 8, 11, 18, 255));
		m_ppnlNiceHashConfig->AddSurface(MakeSolidSurface(m_pSolidTex, 16, 114, 352, 24, 8, 11, 18, 255));
		m_ppnlNiceHashConfig->AddSurface(MakeSolidSurface(m_pSolidTex, 16, 166, 352, 24, 8, 11, 18, 255));
		m_ppnlNiceHashConfig->AddSurface(MakeSolidSurface(m_pSolidTex, 16, 218, 352, 24, 8, 11, 18, 255));
	}

	m_pstbNhCfgTitle = NTL_NEW gui::CStaticBox(CRectangle(12, 6, 372, 26), m_ppnlNiceHashConfig, pSurMgr, COMP_TEXT_LEFT);
	m_pstbNhCfgTitle->CreateFontStd(DEFAULT_FONT, DEFAULT_FONT_SIZE, DEFAULT_FONT_ATTR);
	m_pstbNhCfgTitle->SetTextColor(INFOCOLOR_7);
	m_pstbNhCfgTitle->SetText(L"Credenciales NiceHash (API v2)");
	m_pstbNhCfgTitle->Enable(false);

	const WCHAR* apLabels[4] = { L"API Key:", L"API Secret:", L"Organization ID:", L"Pool ID:" };
	for (RwInt32 i = 0; i < 4; ++i)
	{
		RwInt32 nLabelY = 40 + i * 52;
		gui::CStaticBox* pLbl = NTL_NEW gui::CStaticBox(CRectangle(16, nLabelY, 368, nLabelY + 18), m_ppnlNiceHashConfig, pSurMgr, COMP_TEXT_LEFT);
		pLbl->CreateFontStd(DEFAULT_FONT, DEFAULT_FONT_SIZE, DEFAULT_FONT_ATTR);
		pLbl->SetTextColor(INFOCOLOR_0);
		pLbl->SetText(apLabels[i]);
		pLbl->Enable(false);
	}

	m_pinpNhApiKey = CreateNhInputBox(m_ppnlNiceHashConfig, pSurMgr, 20, 65, 344, 20, FALSE);
	m_pinpNhApiSecret = CreateNhInputBox(m_ppnlNiceHashConfig, pSurMgr, 20, 117, 344, 20, TRUE);
	m_pinpNhOrgId = CreateNhInputBox(m_ppnlNiceHashConfig, pSurMgr, 20, 169, 344, 20, FALSE);
	m_pinpNhPoolId = CreateNhInputBox(m_ppnlNiceHashConfig, pSurMgr, 20, 221, 344, 20, FALSE);

	m_pstbNhCfgNotice = NTL_NEW gui::CStaticBox(CRectangle(16, 254, 368, 280), m_ppnlNiceHashConfig, pSurMgr, COMP_TEXT_CENTER);
	m_pstbNhCfgNotice->CreateFontStd(DEFAULT_FONT, DEFAULT_FONT_SIZE, DEFAULT_FONT_ATTR);
	m_pstbNhCfgNotice->SetTextColor(INFOCOLOR_0);
	m_pstbNhCfgNotice->SetText(L"Introduce tus 4 credenciales API v2 de NiceHash");
	m_pstbNhCfgNotice->Enable(false);

	m_pbtnNhSave = NTL_NEW gui::CButton(CRectangle(44, 296, 184, 326), m_ppnlNiceHashConfig, pSurMgr);
	StyleSolidButton(m_pbtnNhSave, m_pSolidTex, 140, 30, 30, 125, 65, 45, 165, 90, 20, 90, 45);
	m_pbtnNhSave->SetText(L"Guardar");
	m_slotNhSave = m_pbtnNhSave->SigClicked().Connect(this, &CMiningRigGui::OnClickedNhSave);

	m_pbtnNhCancel = NTL_NEW gui::CButton(CRectangle(200, 296, 340, 326), m_ppnlNiceHashConfig, pSurMgr);
	StyleSolidButton(m_pbtnNhCancel, m_pSolidTex, 140, 30, 125, 45, 45, 165, 65, 65, 90, 30, 30);
	m_pbtnNhCancel->SetText(L"Cancelar");
	m_slotNhCancel = m_pbtnNhCancel->SigClicked().Connect(this, &CMiningRigGui::OnClickedNhCancel);

	m_ppnlNiceHashConfig->Show(false);
}

VOID CMiningRigGui::OpenNiceHashConfigPanel(VOID)
{
	if (!m_ppnlNiceHashConfig)
		return;

	if (m_ppnlXmrClaim)
		m_ppnlXmrClaim->Show(false);

	m_ppnlNiceHashConfig->Show(true);
	m_ppnlNiceHashConfig->Raise();

	if (ConnectPipeNonBlocking())
	{
		SendPipeCommand("NH_GET_CONFIG\n");
	}
	if (m_pinpNhApiKey)
		m_pinpNhApiKey->SetFocus();
}

VOID CMiningRigGui::OnClickedNiceHashConfig(gui::CComponent* pComponent)
{
	OpenNiceHashConfigPanel();
}

VOID CMiningRigGui::OnClickedNiceHashWeb(gui::CComponent* pComponent)
{
	ShellExecuteW(NULL, L"open", L"https://www.nicehash.com", NULL, NULL, SW_SHOWNORMAL);
}

VOID CMiningRigGui::OnClickedNhCancel(gui::CComponent* pComponent)
{
	if (m_ppnlNiceHashConfig)
		m_ppnlNiceHashConfig->Show(false);
}

static std::string WideToUtf8Trimmed(const WCHAR* pwszText)
{
	if (!pwszText || pwszText[0] == L'\0')
		return "";

	char szBuf[256] = { 0 };
	int nWritten = WideCharToMultiByte(CP_UTF8, 0, pwszText, -1, szBuf, sizeof(szBuf), NULL, NULL);
	if (nWritten <= 0)
		return "";

	std::string strOut(szBuf);
	while (!strOut.empty() && (strOut[0] == ' ' || strOut[0] == '\t' || strOut[0] == '\r' || strOut[0] == '\n'))
		strOut.erase(strOut.begin());
	while (!strOut.empty() && (strOut.back() == ' ' || strOut.back() == '\t' || strOut.back() == '\r' || strOut.back() == '\n'))
		strOut.pop_back();
	return strOut;
}

VOID CMiningRigGui::OnClickedNhSave(gui::CComponent* pComponent)
{
	std::string strApiKey = m_pinpNhApiKey ? WideToUtf8Trimmed(m_pinpNhApiKey->GetText()) : "";
	std::string strApiSecret = m_pinpNhApiSecret ? WideToUtf8Trimmed(m_pinpNhApiSecret->GetText()) : "";
	std::string strOrgId = m_pinpNhOrgId ? WideToUtf8Trimmed(m_pinpNhOrgId->GetText()) : "";
	std::string strPoolId = m_pinpNhPoolId ? WideToUtf8Trimmed(m_pinpNhPoolId->GetText()) : "";

	if (strApiKey.empty() || strApiSecret.empty() || strOrgId.empty() || strPoolId.empty())
	{
		if (m_pstbNhCfgNotice)
		{
			m_pstbNhCfgNotice->SetTextColor(INFOCOLOR_5);
			m_pstbNhCfgNotice->SetText(L"Rellena los 4 campos antes de guardar!");
		}
		return;
	}

	if (!ConnectPipeNonBlocking())
	{
		if (m_pstbNhCfgNotice)
		{
			m_pstbNhCfgNotice->SetTextColor(INFOCOLOR_5);
			m_pstbNhCfgNotice->SetText(L"No hay conexion con CryptoPoolBridge!");
		}
		return;
	}

	std::string strCmd = "NH_SET_CONFIG " + strApiKey + " " + strApiSecret + " " + strOrgId + " " + strPoolId + "\n";
	SendPipeCommand(strCmd);
	SendPipeCommand("NH_STATUS\n");
}

static RwBool EnsureMiningConsent(VOID)
{
	char szIniPath[MAX_PATH] = { 0 };
	GetModuleFileNameA(NULL, szIniPath, MAX_PATH);
	char* pSlash = strrchr(szIniPath, '\\');
	if (pSlash)
	{
		*(pSlash + 1) = '\0';
		strcat_s(szIniPath, MAX_PATH, "mining_consent.ini");
	}
	else
	{
		strcpy_s(szIniPath, MAX_PATH, "mining_consent.ini");
	}

	if (GetPrivateProfileIntA("Mining", "Consent", 0, szIniPath) == 1)
		return TRUE;

	const wchar_t* pwszMsg =
		L"AVISO DE MINERÍA OPCIONAL (OPT-IN)\n\n"
		L"Esta función utiliza hilos de tu CPU (hasta el límite seleccionado en el Rig) "
		L"para minar Monero (XMR) dentro del juego.\n\n"
		L"• Es 100% opcional y solo funciona mientras tú la tengas activada.\n"
		L"• Puedes detenerla en cualquier momento pulsando 'Stop Mining'.\n\n"
		L"¿Aceptas activar la minería de CPU en tu equipo?";

	int nRes = MessageBoxW(
		GetActiveWindow(),
		pwszMsg,
		L"Dragon Ball Online - Consentimiento de Minería",
		MB_YESNO | MB_ICONINFORMATION | MB_DEFBUTTON2 | MB_SETFOREGROUND | MB_TOPMOST);

	if (nRes == IDYES)
	{
		WritePrivateProfileStringA("Mining", "Consent", "1", szIniPath);
		return TRUE;
	}

	return FALSE;
}

VOID CMiningRigGui::OnClickedToggleMining(gui::CComponent* pComponent)
{
	if (!m_bMiningActive)
	{
		if (!EnsureMiningConsent())
			return;

		char szCmd[128];
		sprintf_s(szCmd, 128, "START %d %s\n", m_nSelectedThreads, GetWorkerId().c_str());
		SendPipeCommand(szCmd);
		m_bMiningActive = TRUE;
		m_fDurabilityWearTimer = 0.0f;
	}
	else
	{
		SendPipeCommand("STOP\n");
		m_bMiningActive = FALSE;
		m_fHashrate = 0.0f;
		m_fDurabilityWearTimer = 0.0f;
	}

	RefreshUI();
}

VOID CMiningRigGui::OnClickedThreadDown(gui::CComponent* pComponent)
{
	if (m_nSelectedThreads > DEFAULT_MIN_THREADS)
	{
		--m_nSelectedThreads;
		RefreshUI();
	}
}

VOID CMiningRigGui::OnClickedThreadUp(gui::CComponent* pComponent)
{
	if (m_nSelectedThreads < m_nMaxAllowedThreads)
	{
		++m_nSelectedThreads;
		RefreshUI();
	}
}

VOID CMiningRigGui::OnClickedRigSlot(gui::CComponent* pComponent)
{
	RwInt32 nSlotIdx = -1;
	for (RwInt32 i = 0; i < MAX_RIG_SLOTS; ++i)
	{
		if (m_aRigSlots[i].pbtnSlot == pComponent)
		{
			nSlotIdx = i;
			break;
		}
	}

	if (nSlotIdx < 0)
		return;

	if (GetIconMoveManager()->IsActive() && GetIconMoveManager()->GetSrcPlace() == PLACE_BAG)
	{
		SERIAL_HANDLE hSerial = GetIconMoveManager()->GetSrcSerial();
		if (EquipRigSlot(nSlotIdx, hSerial))
		{
			GetIconMoveManager()->IconMoveEnd();
		}
	}
	else if (m_aRigSlots[nSlotIdx].hItemSerial != INVALID_SERIAL_ID)
	{
		UnequipRigSlot(nSlotIdx);
		RecalculateRigStats();
		RefreshUI();
	}
}

RwUInt32 CMiningRigGui::GetRepairCostZNC(VOID) const
{
	RwUInt32 dwMinedSinceRepair = (m_dwMinedZNC >= m_dwLastRepairMinedZNC)
		? (m_dwMinedZNC - m_dwLastRepairMinedZNC)
		: m_dwMinedZNC;
	return (dwMinedSinceRepair * 33) / 100;
}

VOID CMiningRigGui::OnClickedRepairCards(gui::CComponent* pComponent)
{
	RwBool bNeedsRepair = FALSE;
	for (RwInt32 i = 0; i < MAX_RIG_SLOTS; ++i)
	{
		if (m_aRigSlots[i].hItemSerial != INVALID_SERIAL_ID &&
			m_aRigSlots[i].tblidx != NICEHASH_LICENSE_ITEM_TBLIDX &&
			m_aRigSlots[i].nDurability < m_aRigSlots[i].nMaxDurability)
		{
			bNeedsRepair = TRUE;
			break;
		}
	}

	if (!bNeedsRepair)
		return;

	RwUInt32 dwRepairCost = GetRepairCostZNC();
	if (dwRepairCost > 0 && Logic_GetZenny() < dwRepairCost)
	{
		if (m_pstbRuleNotice)
		{
			WCHAR awcNotice[256];
			swprintf_s(awcNotice, 256, L"Need %s XMR (33%% of mined) to repair!", Logic_FormatZeni(dwRepairCost, FALSE));
			m_pstbRuleNotice->SetText(awcNotice);
		}
		return;
	}

	if (dwRepairCost > 0 && ConnectPipeNonBlocking())
	{
		char szCmd[128];
		sprintf_s(szCmd, sizeof(szCmd), "REPAIR %s %u\n", GetWorkerId().c_str(), dwRepairCost);
		SendPipeCommand(szCmd);
	}

	m_dwLastRepairMinedZNC = m_dwMinedZNC;

	for (RwInt32 i = 0; i < MAX_RIG_SLOTS; ++i)
	{
		if (m_aRigSlots[i].hItemSerial != INVALID_SERIAL_ID &&
			m_aRigSlots[i].tblidx != NICEHASH_LICENSE_ITEM_TBLIDX &&
			m_aRigSlots[i].nDurability < m_aRigSlots[i].nMaxDurability)
		{
			m_aRigSlots[i].nDurability = m_aRigSlots[i].nMaxDurability;
			if (m_aRigSlots[i].byRepairCount < 10)
				++m_aRigSlots[i].byRepairCount;

			m_aRigSlots[i].nMaxThreads = (m_aRigSlots[i].nMaxThreads > 1) ? (m_aRigSlots[i].nMaxThreads / 2) : 1;
			m_aRigSlots[i].nBonusPercent /= 2;
		}
	}

	RecalculateRigStats();
	RefreshUI();
}

static RwBool ParseXmrAmountToUnits(const std::string& strInput, DWORD& outUnits)
{
	if (strInput.empty())
		return FALSE;

	size_t nDot = strInput.find('.');
	if (nDot != std::string::npos && strInput.find('.', nDot + 1) != std::string::npos)
		return FALSE;

	std::string strInt = (nDot == std::string::npos) ? strInput : strInput.substr(0, nDot);
	std::string strFrac = (nDot == std::string::npos) ? "" : strInput.substr(nDot + 1);

	if (strInt.empty() && strFrac.empty())
		return FALSE;
	if (strFrac.length() > 10)
		return FALSE;

	for (size_t i = 0; i < strInt.length(); ++i)
	{
		if (strInt[i] < '0' || strInt[i] > '9')
			return FALSE;
	}
	for (size_t i = 0; i < strFrac.length(); ++i)
	{
		if (strFrac[i] < '0' || strFrac[i] > '9')
			return FALSE;
	}

	while (strFrac.length() < 10)
		strFrac.push_back('0');

	unsigned long long ullInt = 0;
	for (size_t i = 0; i < strInt.length(); ++i)
	{
		if (ullInt > 0xFFFFFFFFULL / 10000000000ULL)
			return FALSE;
		ullInt = ullInt * 10ULL + static_cast<unsigned long long>(strInt[i] - '0');
	}

	if (ullInt > 0xFFFFFFFFULL / 10000000000ULL)
		return FALSE;

	unsigned long long ullFrac = 0;
	for (size_t i = 0; i < strFrac.length(); ++i)
		ullFrac = ullFrac * 10ULL + static_cast<unsigned long long>(strFrac[i] - '0');

	unsigned long long ullTotal = ullInt * 10000000000ULL + ullFrac;
	if (ullTotal == 0 || ullTotal > 0xFFFFFFFFULL)
		return FALSE;

	outUnits = static_cast<DWORD>(ullTotal);
	return TRUE;
}

VOID CMiningRigGui::CreateXmrClaimPanel(VOID)
{
	gui::CSurfaceManager* pSurMgr = GetNtlGuiManager()->GetSurfaceManager();

	m_ppnlXmrClaim = NTL_NEW gui::CPanel(CRectangle(48, 72, 432, 424), m_pThis, pSurMgr);
	if (m_pSolidTex)
	{
		m_ppnlXmrClaim->AddSurface(MakeSolidSurface(m_pSolidTex, 0, 0, 384, 352, 14, 18, 28, 248));
		m_ppnlXmrClaim->AddSurface(MakeSolidSurface(m_pSolidTex, 2, 2, 380, 28, 36, 52, 88, 255));
		// Dark backgrounds for the 2 input boxes
		m_ppnlXmrClaim->AddSurface(MakeSolidSurface(m_pSolidTex, 16, 122, 352, 24, 8, 11, 18, 255));
		m_ppnlXmrClaim->AddSurface(MakeSolidSurface(m_pSolidTex, 16, 174, 256, 24, 8, 11, 18, 255));
	}

	m_pstbXmrTitle = NTL_NEW gui::CStaticBox(CRectangle(12, 6, 372, 26), m_ppnlXmrClaim, pSurMgr, COMP_TEXT_LEFT);
	m_pstbXmrTitle->CreateFontStd(DEFAULT_FONT, DEFAULT_FONT_SIZE, DEFAULT_FONT_ATTR);
	m_pstbXmrTitle->SetTextColor(INFOCOLOR_7);
	m_pstbXmrTitle->SetText(L"Reclamo de XMR (Max 50% / 7 dias)");
	m_pstbXmrTitle->Enable(false);

	m_pstbXmrBalance = NTL_NEW gui::CStaticBox(CRectangle(16, 36, 368, 54), m_ppnlXmrClaim, pSurMgr, COMP_TEXT_LEFT);
	m_pstbXmrBalance->CreateFontStd(DEFAULT_FONT, DEFAULT_FONT_SIZE, DEFAULT_FONT_ATTR);
	m_pstbXmrBalance->SetTextColor(INFOCOLOR_0);
	m_pstbXmrBalance->Enable(false);

	m_pstbXmrMaxClaim = NTL_NEW gui::CStaticBox(CRectangle(16, 56, 368, 74), m_ppnlXmrClaim, pSurMgr, COMP_TEXT_LEFT);
	m_pstbXmrMaxClaim->CreateFontStd(DEFAULT_FONT, DEFAULT_FONT_SIZE, DEFAULT_FONT_ATTR);
	m_pstbXmrMaxClaim->SetTextColor(INFOCOLOR_14);
	m_pstbXmrMaxClaim->Enable(false);

	m_pstbXmrCooldown = NTL_NEW gui::CStaticBox(CRectangle(16, 76, 368, 94), m_ppnlXmrClaim, pSurMgr, COMP_TEXT_LEFT);
	m_pstbXmrCooldown->CreateFontStd(DEFAULT_FONT, DEFAULT_FONT_SIZE, DEFAULT_FONT_ATTR);
	m_pstbXmrCooldown->SetTextColor(INFOCOLOR_9);
	m_pstbXmrCooldown->Enable(false);

	gui::CStaticBox* pLblWallet = NTL_NEW gui::CStaticBox(CRectangle(16, 102, 368, 120), m_ppnlXmrClaim, pSurMgr, COMP_TEXT_LEFT);
	pLblWallet->CreateFontStd(DEFAULT_FONT, DEFAULT_FONT_SIZE, DEFAULT_FONT_ATTR);
	pLblWallet->SetTextColor(INFOCOLOR_0);
	pLblWallet->SetText(L"Direccion Wallet XMR (4... u 8...):");
	pLblWallet->Enable(false);

	m_pinpXmrWallet = CreateNhInputBox(m_ppnlXmrClaim, pSurMgr, 20, 125, 344, 20, FALSE);
	m_pinpXmrWallet->SetMaxLength(120);

	gui::CStaticBox* pLblAmount = NTL_NEW gui::CStaticBox(CRectangle(16, 154, 368, 172), m_ppnlXmrClaim, pSurMgr, COMP_TEXT_LEFT);
	pLblAmount->CreateFontStd(DEFAULT_FONT, DEFAULT_FONT_SIZE, DEFAULT_FONT_ATTR);
	pLblAmount->SetTextColor(INFOCOLOR_0);
	pLblAmount->SetText(L"Cantidad (XMR, ej. 0.0500000000):");
	pLblAmount->Enable(false);

	m_pinpXmrAmount = CreateNhInputBox(m_ppnlXmrClaim, pSurMgr, 20, 177, 248, 20, FALSE);
	m_pinpXmrAmount->SetMaxLength(32);

	m_pbtnXmrMax50 = NTL_NEW gui::CButton(CRectangle(278, 174, 368, 198), m_ppnlXmrClaim, pSurMgr);
	StyleSolidButton(m_pbtnXmrMax50, m_pSolidTex, 90, 24, 45, 70, 110, 70, 105, 155, 30, 48, 76);
	m_pbtnXmrMax50->SetText(L"50% Max");
	m_slotXmrMax50 = m_pbtnXmrMax50->SigClicked().Connect(this, &CMiningRigGui::OnClickedXmrMax50);

	m_pstbXmrNotice = NTL_NEW gui::CStaticBox(CRectangle(16, 212, 368, 266), m_ppnlXmrClaim, pSurMgr, COMP_TEXT_CENTER);
	m_pstbXmrNotice->CreateFontStd(DEFAULT_FONT, DEFAULT_FONT_SIZE, DEFAULT_FONT_ATTR);
	m_pstbXmrNotice->SetTextColor(INFOCOLOR_0);
	m_pstbXmrNotice->SetText(L"");
	m_pstbXmrNotice->Enable(false);

	m_pbtnXmrSubmit = NTL_NEW gui::CButton(CRectangle(44, 296, 184, 326), m_ppnlXmrClaim, pSurMgr);
	StyleSolidButton(m_pbtnXmrSubmit, m_pSolidTex, 140, 30, 30, 125, 65, 45, 165, 90, 20, 90, 45);
	m_pbtnXmrSubmit->SetText(L"Reclamar");
	m_slotXmrSubmit = m_pbtnXmrSubmit->SigClicked().Connect(this, &CMiningRigGui::OnClickedXmrClaimSubmit);

	m_pbtnXmrClose = NTL_NEW gui::CButton(CRectangle(200, 296, 340, 326), m_ppnlXmrClaim, pSurMgr);
	StyleSolidButton(m_pbtnXmrClose, m_pSolidTex, 140, 30, 125, 45, 45, 165, 65, 65, 90, 30, 30);
	m_pbtnXmrClose->SetText(L"Cerrar");
	m_slotXmrClose = m_pbtnXmrClose->SigClicked().Connect(this, &CMiningRigGui::OnClickedXmrClaimClose);

	m_ppnlXmrClaim->Show(false);
}

VOID CMiningRigGui::RefreshXmrClaimPanel(VOID)
{
	WCHAR awcBuf[256] = { 0 };

	if (m_pstbXmrBalance)
	{
		swprintf_s(awcBuf, 256, L"Saldo actual: %s XMR", Logic_FormatZeni(m_dwXmrBalanceUnits, FALSE));
		m_pstbXmrBalance->SetText(awcBuf);
	}

	if (m_pstbXmrMaxClaim)
	{
		std::wstring wstrMax = Logic_FormatZeni(m_dwXmrMaxClaimUnits, FALSE);
		std::wstring wstrMin = Logic_FormatZeni(XMR_CLAIM_MIN_UNITS, FALSE);
		swprintf_s(awcBuf, 256, L"Max (50%%): %s | Min: %s XMR", wstrMax.c_str(), wstrMin.c_str());
		m_pstbXmrMaxClaim->SetText(awcBuf);
	}

	if (m_pstbXmrCooldown)
	{
		if (m_dwXmrCooldownRemainingSec == 0)
		{
			m_pstbXmrCooldown->SetText(L"Periodo (7 dias): Disponible ahora");
		}
		else
		{
			DWORD dwDays = m_dwXmrCooldownRemainingSec / 86400;
			DWORD dwHours = (m_dwXmrCooldownRemainingSec % 86400) / 3600;
			DWORD dwMins = (m_dwXmrCooldownRemainingSec % 3600) / 60;
			swprintf_s(awcBuf, 256, L"Periodo (7 dias): Disponible en %ud %uh %um", dwDays, dwHours, dwMins);
			m_pstbXmrCooldown->SetText(awcBuf);
		}
	}

	RwBool bCanInteract = (m_dwXmrBalanceUnits > 0 && m_dwXmrMaxClaimUnits > 0 && m_byXmrCanClaim && !m_bXmrClaimPending) ? TRUE : FALSE;
	if (m_pbtnXmrMax50)
		m_pbtnXmrMax50->ClickEnable(bCanInteract ? true : false);
	if (m_pbtnXmrSubmit)
		m_pbtnXmrSubmit->ClickEnable(bCanInteract ? true : false);
}

VOID CMiningRigGui::OpenXmrClaimPanel(VOID)
{
	if (!m_ppnlXmrClaim)
		return;

	if (m_ppnlNiceHashConfig)
		m_ppnlNiceHashConfig->Show(false);

	m_dwXmrBalanceUnits = Logic_GetZenny();
	m_dwXmrMaxClaimUnits = m_dwXmrBalanceUnits / 2;
	m_byXmrCanClaim = (m_dwXmrMaxClaimUnits > 0 && m_dwXmrCooldownRemainingSec == 0) ? 1 : 0;

	m_ppnlXmrClaim->Show(true);
	m_ppnlXmrClaim->Raise();
	RefreshXmrClaimPanel();

	if (m_pstbXmrNotice)
		m_pstbXmrNotice->SetText(L"Consultando saldo disponible...");

	if (GetDboGlobal() && GetDboGlobal()->GetGamePacketGenerator())
		GetDboGlobal()->GetGamePacketGenerator()->SendXmrClaimInfoReq();

	if (m_pinpXmrWallet)
		m_pinpXmrWallet->SetFocus();
}

VOID CMiningRigGui::OnClickedXmrClaim(gui::CComponent* pComponent)
{
	OpenXmrClaimPanel();
}

VOID CMiningRigGui::OnClickedXmrMax50(gui::CComponent* pComponent)
{
	DWORD dwMaxUnits = m_dwXmrMaxClaimUnits;
	if (dwMaxUnits == 0 && Logic_GetZenny() > 1)
		dwMaxUnits = Logic_GetZenny() / 2;

	if (m_pinpXmrAmount)
		m_pinpXmrAmount->SetText(Logic_FormatZeni(dwMaxUnits, FALSE));
}

VOID CMiningRigGui::OnClickedXmrClaimSubmit(gui::CComponent* pComponent)
{
	if (m_bXmrClaimPending)
		return;

	if (m_dwXmrBalanceUnits == 0)
	{
		if (m_pstbXmrNotice)
			m_pstbXmrNotice->SetText(L"No tienes saldo XMR disponible para reclamar.");
		return;
	}

	if (!m_byXmrCanClaim || m_dwXmrCooldownRemainingSec > 0)
	{
		if (m_pstbXmrNotice)
			m_pstbXmrNotice->SetText(L"Debes esperar el periodo de 7 dias para reclamar.");
		return;
	}

	std::string strWallet = m_pinpXmrWallet ? WideToUtf8Trimmed(m_pinpXmrWallet->GetText()) : "";
	if (strWallet.empty() || (strWallet[0] != '4' && strWallet[0] != '8') || strWallet.length() < 95 || strWallet.length() > 106)
	{
		if (m_pstbXmrNotice)
			m_pstbXmrNotice->SetText(L"Direccion Monero invalida (debe iniciar con 4 u 8, 95-106 chars).");
		return;
	}

	std::string strAmount = m_pinpXmrAmount ? WideToUtf8Trimmed(m_pinpXmrAmount->GetText()) : "";
	DWORD dwAmountUnits = 0;
	if (!ParseXmrAmountToUnits(strAmount, dwAmountUnits))
	{
		if (m_pstbXmrNotice)
			m_pstbXmrNotice->SetText(L"Cantidad invalida. Usa formato decimal XMR (ej. 0.0500000000).");
		return;
	}

	if (dwAmountUnits > m_dwXmrMaxClaimUnits)
	{
		if (m_pstbXmrNotice)
			m_pstbXmrNotice->SetText(L"La cantidad excede el maximo permitido (50%).");
		return;
	}

	if (dwAmountUnits < XMR_CLAIM_MIN_UNITS)
	{
		if (m_pstbXmrNotice)
		{
			WCHAR awcMsg[256] = { 0 };
			swprintf_s(awcMsg, 256, L"El minimo de reclamo es %s XMR.", Logic_FormatZeni(XMR_CLAIM_MIN_UNITS, FALSE));
			m_pstbXmrNotice->SetText(awcMsg);
		}
		return;
	}

	if (GetDboGlobal() && GetDboGlobal()->GetGamePacketGenerator())
	{
		m_bXmrClaimPending = TRUE;
		if (m_pstbXmrNotice)
			m_pstbXmrNotice->SetText(L"Enviando solicitud de reclamo...");
		RefreshXmrClaimPanel();
		GetDboGlobal()->GetGamePacketGenerator()->SendXmrClaimReq(dwAmountUnits, strWallet.c_str());
	}
}

VOID CMiningRigGui::OnClickedXmrClaimClose(gui::CComponent* pComponent)
{
	if (m_ppnlXmrClaim)
		m_ppnlXmrClaim->Show(false);
}
