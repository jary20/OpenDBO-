# -*- coding: utf-8 -*-
"""
Dashboard nativo de escritorio (Tkinter) para gestionar todos los precios
de OpenDBO (Cash Shop HLS e Items/NPCs) en XMR, con guardado en
config\\item_prices.ini y recarga automatica en vivo en GameServer.
"""

import json
import os
import subprocess
import tkinter as tk
from tkinter import ttk, messagebox

SCALE = 10_000_000_000.0  # 1.0 XMR = 10^10 unidades internas
MAX_DWORD = 4_294_967_295

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CATALOG_PATH = os.path.join(BASE_DIR, "config", "price_catalog.tsv")
INI_PATH = os.path.join(BASE_DIR, "config", "item_prices.ini")


def atomic_to_xmr_str(val: int) -> str:
    s = f"{val / SCALE:.10f}".rstrip("0").rstrip(".")
    return s if s else "0"


def xmr_str_to_atomic(text: str) -> int:
    val = float(text.strip().replace(",", "."))
    if val < 0:
        raise ValueError("El precio no puede ser negativo.")
    atomic = int(round(val * SCALE))
    if atomic > MAX_DWORD:
        raise ValueError(f"El maximo permitido por DWORD es {atomic_to_xmr_str(MAX_DWORD)} XMR.")
    return atomic


class PriceDashboardApp:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("OpenDBO - Dashboard de Precios (XMR)")
        self.root.geometry("1040x680")
        self.root.minsize(880, 560)
        self.root.configure(bg="#181c24")

        self.hls_items = []
        self.normal_items = []
        self.hls_overrides = {}   # tblidx -> atomic_int
        self.item_overrides = {}  # tblidx -> (buy_atomic, sell_atomic_or_None)
        self.selected_record = None

        self._setup_style()
        self._build_ui()
        self.reload_all()

    def _setup_style(self):
        style = ttk.Style()
        style.theme_use("clam")
        style.configure("TFrame", background="#181c24")
        style.configure("Card.TFrame", background="#202632", relief="flat")
        style.configure("TLabel", background="#181c24", foreground="#e6edf3", font=("Segoe UI", 10))
        style.configure("Card.TLabel", background="#202632", foreground="#e6edf3", font=("Segoe UI", 10))
        style.configure("Title.TLabel", background="#181c24", foreground="#f0b90b", font=("Segoe UI", 14, "bold"))
        style.configure("Sub.TLabel", background="#181c24", foreground="#8b949e", font=("Segoe UI", 9))
        style.configure("TCheckbutton", background="#181c24", foreground="#e6edf3", font=("Segoe UI", 10))
        style.configure("TNotebook", background="#181c24", borderwidth=0)
        style.configure("TNotebook.Tab", background="#262d3b", foreground="#c9d1d9", padding=[14, 6], font=("Segoe UI", 10, "bold"))
        style.map("TNotebook.Tab", background=[("selected", "#344158")], foreground=[("selected", "#ffffff")])

        style.configure("Treeview",
                        background="#12161d",
                        foreground="#e6edf3",
                        fieldbackground="#12161d",
                        rowheight=26,
                        font=("Segoe UI", 9))
        style.configure("Treeview.Heading",
                        background="#262d3b",
                        foreground="#f0b90b",
                        font=("Segoe UI", 9, "bold"),
                        relief="flat")
        style.map("Treeview", background=[("selected", "#2b4b7e")], foreground=[("selected", "#ffffff")])

    def _build_ui(self):
        # Header
        hdr = ttk.Frame(self.root, padding=(14, 10, 14, 6))
        hdr.pack(fill="x")
        ttk.Label(hdr, text="Dashboard de Precios - OpenDBO (XMR)", style="Title.TLabel").pack(side="left")
        self.lbl_status = ttk.Label(hdr, text="Listo", style="Sub.TLabel")
        self.lbl_status.pack(side="right")

        # Filter bar
        flt = ttk.Frame(self.root, padding=(14, 4, 14, 8))
        flt.pack(fill="x")
        ttk.Label(flt, text="Buscar (ID o Nombre):").pack(side="left", padx=(0, 8))
        self.var_search = tk.StringVar()
        self.var_search.trace_add("write", lambda *_: self.refresh_tables())
        ent_search = tk.Entry(flt, textvariable=self.var_search, bg="#12161d", fg="#ffffff",
                              insertbackground="#ffffff", relief="solid", bd=1, font=("Segoe UI", 10), width=34)
        ent_search.pack(side="left", padx=(0, 14), ipady=3)

        self.var_only_modified = tk.BooleanVar(value=False)
        ttk.Checkbutton(flt, text="Solo modificados", variable=self.var_only_modified,
                        command=self.refresh_tables).pack(side="left", padx=(0, 14))

        btn_reload = tk.Button(flt, text="Recargar Catalogo", command=self.reload_all,
                               bg="#2d3748", fg="#ffffff", activebackground="#3b475c",
                               relief="flat", padx=12, pady=4, font=("Segoe UI", 9, "bold"), cursor="hand2")
        btn_reload.pack(side="right")

        # Notebook tabs
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill="both", expand=True, padx=14, pady=(0, 8))

        tab_hls = ttk.Frame(self.notebook)
        tab_items = ttk.Frame(self.notebook)
        tab_xmr = ttk.Frame(self.notebook)
        self.notebook.add(tab_hls, text="  Cash Shop (HLS)  ")
        self.notebook.add(tab_items, text="  Items / NPCs  ")
        self.notebook.add(tab_xmr, text="  XMR Admin / Tesoreria  ")

        # HLS Treeview
        hls_cols = ("tblidx", "item_tblidx", "name", "orig_xmr", "curr_xmr", "status")
        self.tree_hls = self._create_tree(tab_hls, hls_cols, [
            ("tblidx", "HLS ID", 90, "center"),
            ("item_tblidx", "Item ID", 90, "center"),
            ("name", "Nombre", 360, "w"),
            ("orig_xmr", "Original (XMR)", 140, "e"),
            ("curr_xmr", "Actual (XMR)", 140, "e"),
            ("status", "Estado", 120, "center"),
        ])
        self.tree_hls.bind("<<TreeviewSelect>>", lambda e: self._on_select("HLS"))

        # Items Treeview
        item_cols = ("tblidx", "name", "orig_buy", "curr_buy", "curr_sell", "status")
        self.tree_items = self._create_tree(tab_items, item_cols, [
            ("tblidx", "Item ID", 95, "center"),
            ("name", "Nombre", 380, "w"),
            ("orig_buy", "Orig. Compra (XMR)", 140, "e"),
            ("curr_buy", "Compra (XMR)", 140, "e"),
            ("curr_sell", "Venta (XMR)", 140, "e"),
            ("status", "Estado", 110, "center"),
        ])
        self.tree_items.bind("<<TreeviewSelect>>", lambda e: self._on_select("ITEM"))

        # XMR Admin / Tesoreria tab
        xmr_top = ttk.Frame(tab_xmr, style="Card.TFrame", padding=(10, 8))
        xmr_top.pack(fill="x", padx=6, pady=(6, 4))
        self.lbl_xmr_summary = ttk.Label(
            xmr_top,
            text="Pulsa 'Actualizar XMR' para consultar tesoreria y retiros en MySQL.",
            style="Card.TLabel",
            font=("Segoe UI", 9)
        )
        self.lbl_xmr_summary.pack(side="left", fill="x", expand=True)

        xmr_btns = ttk.Frame(tab_xmr, padding=(6, 4))
        xmr_btns.pack(fill="x")
        tk.Button(xmr_btns, text="Actualizar XMR", command=self.refresh_xmr_admin,
                  bg="#2d3748", fg="#ffffff", relief="flat", padx=10, pady=4,
                  font=("Segoe UI", 9, "bold"), cursor="hand2").pack(side="left", padx=(0, 8))
        tk.Button(xmr_btns, text="Aprobar Retiro (WAITING_ADMIN)", command=self.approve_selected_withdrawal,
                  bg="#1f8b4c", fg="#ffffff", relief="flat", padx=10, pady=4,
                  font=("Segoe UI", 9, "bold"), cursor="hand2").pack(side="left", padx=(0, 8))
        tk.Button(xmr_btns, text="Rechazar y Devolver", command=self.reject_selected_withdrawal,
                  bg="#8b2f2f", fg="#ffffff", relief="flat", padx=10, pady=4,
                  font=("Segoe UI", 9, "bold"), cursor="hand2").pack(side="left", padx=(0, 8))
        tk.Button(xmr_btns, text="Liquidar Fees (RPC)", command=self.withdraw_treasury_rpc,
                  bg="#b7791f", fg="#ffffff", relief="flat", padx=10, pady=4,
                  font=("Segoe UI", 9, "bold"), cursor="hand2").pack(side="right")

        xmr_cols = ("id", "char_id", "amount_xmr", "address", "status", "tx_hash", "created_at")
        self.tree_xmr = self._create_tree(tab_xmr, xmr_cols, [
            ("id", "ID", 60, "center"),
            ("char_id", "Char ID", 80, "center"),
            ("amount_xmr", "Monto (XMR)", 130, "e"),
            ("address", "Wallet Destino", 240, "w"),
            ("status", "Estado", 125, "center"),
            ("tx_hash", "TX / Nota", 210, "w"),
            ("created_at", "Fecha", 140, "center"),
        ])

        # Bottom editor card
        ed = ttk.Frame(self.root, style="Card.TFrame", padding=(14, 12))
        ed.pack(fill="x", padx=14, pady=(0, 12))

        self.lbl_sel = ttk.Label(ed, text="Selecciona un item arriba para editar su precio", style="Card.TLabel",
                                 font=("Segoe UI", 10, "bold"))
        self.lbl_sel.grid(row=0, column=0, columnspan=6, sticky="w", pady=(0, 8))

        ttk.Label(ed, text="Precio Compra (XMR):", style="Card.TLabel").grid(row=1, column=0, sticky="w", padx=(0, 8))
        self.var_buy = tk.StringVar()
        self.ent_buy = tk.Entry(ed, textvariable=self.var_buy, bg="#12161d", fg="#ffffff",
                                insertbackground="#ffffff", relief="solid", bd=1, font=("Segoe UI", 10), width=20)
        self.ent_buy.grid(row=1, column=1, sticky="w", padx=(0, 18), ipady=3)

        self.lbl_sell = ttk.Label(ed, text="Precio Venta (XMR):", style="Card.TLabel")
        self.lbl_sell.grid(row=1, column=2, sticky="w", padx=(0, 8))
        self.var_sell = tk.StringVar()
        self.ent_sell = tk.Entry(ed, textvariable=self.var_sell, bg="#12161d", fg="#ffffff",
                                 insertbackground="#ffffff", relief="solid", bd=1, font=("Segoe UI", 10), width=20)
        self.ent_sell.grid(row=1, column=3, sticky="w", padx=(0, 18), ipady=3)

        btn_save = tk.Button(ed, text="Guardar y Aplicar en Vivo", command=self.apply_selected_price,
                             bg="#1f8b4c", fg="#ffffff", activebackground="#27ae60",
                             relief="flat", padx=16, pady=6, font=("Segoe UI", 10, "bold"), cursor="hand2")
        btn_save.grid(row=1, column=4, padx=(0, 10))

        btn_reset = tk.Button(ed, text="Restaurar Original", command=self.reset_selected_price,
                              bg="#8b2f2f", fg="#ffffff", activebackground="#b03a3a",
                              relief="flat", padx=12, pady=6, font=("Segoe UI", 10, "bold"), cursor="hand2")
        btn_reset.grid(row=1, column=5)

    def _create_tree(self, parent, cols, col_specs):
        wrap = ttk.Frame(parent)
        wrap.pack(fill="both", expand=True)
        tree = ttk.Treeview(wrap, columns=cols, show="headings", selectmode="browse")
        vsb = ttk.Scrollbar(wrap, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=vsb.set)
        tree.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")
        for col_id, heading, width, anchor in col_specs:
            tree.heading(col_id, text=heading)
            tree.column(col_id, width=width, anchor=anchor)
        tree.tag_configure("modified", foreground="#f0b90b")
        return tree

    def reload_all(self):
        self._load_ini()
        self._load_catalog()
        self.refresh_tables()

    def _load_ini(self):
        self.hls_overrides.clear()
        self.item_overrides.clear()
        if not os.path.exists(INI_PATH):
            return
        section = 0
        with open(INI_PATH, "r", encoding="utf-8", errors="replace") as f:
            for raw in f:
                s = raw.strip()
                if not s or s.startswith(";") or s.startswith("#"):
                    continue
                if s.startswith("["):
                    if s == "[HLS_PRICES]":
                        section = 1
                    elif s == "[ITEM_PRICES]":
                        section = 2
                    else:
                        section = 0
                    continue
                if "=" not in s:
                    continue
                k, v = [p.strip() for p in s.split("=", 1)]
                if not k.isdigit():
                    continue
                tblidx = int(k)
                try:
                    if section == 1:
                        self.hls_overrides[tblidx] = xmr_str_to_atomic(v)
                    elif section == 2:
                        if "," in v:
                            b_str, s_str = [p.strip() for p in v.split(",", 1)]
                            buy_a = xmr_str_to_atomic(b_str)
                            sell_a = xmr_str_to_atomic(s_str) if s_str else None
                            self.item_overrides[tblidx] = (buy_a, sell_a)
                        else:
                            self.item_overrides[tblidx] = (xmr_str_to_atomic(v), None)
                except ValueError:
                    continue

    def _load_catalog(self):
        self.hls_items.clear()
        self.normal_items.clear()
        if not os.path.exists(CATALOG_PATH):
            self.lbl_status.config(text="Falta price_catalog.tsv (arranca GameServer.exe una vez)")
            return
        with open(CATALOG_PATH, "r", encoding="utf-8", errors="replace") as f:
            header = f.readline()
            for line in f:
                parts = line.rstrip("\r\n").split("\t")
                if len(parts) < 6:
                    continue
                rtype, tblidx, sub_tblidx, name, orig_buy, orig_sell = parts[:6]
                rec = {
                    "type": rtype,
                    "tblidx": int(tblidx),
                    "sub_tblidx": int(sub_tblidx),
                    "name": name,
                    "orig_buy": int(orig_buy),
                    "orig_sell": int(orig_sell),
                }
                if rtype == "HLS":
                    self.hls_items.append(rec)
                elif rtype == "ITEM":
                    self.normal_items.append(rec)

        self.hls_items.sort(key=lambda r: r["tblidx"])
        self.normal_items.sort(key=lambda r: r["tblidx"])
        self.lbl_status.config(
            text=f"Catalogo: {len(self.hls_items)} HLS | {len(self.normal_items)} Items | {len(self.hls_overrides) + len(self.item_overrides)} personalizados"
        )

    def refresh_tables(self):
        q = self.var_search.get().strip().lower()
        only_mod = self.var_only_modified.get()

        self.tree_hls.delete(*self.tree_hls.get_children())
        for rec in self.hls_items:
            tid = rec["tblidx"]
            is_mod = tid in self.hls_overrides
            if only_mod and not is_mod:
                continue
            if q and (q not in str(tid) and q not in str(rec["sub_tblidx"]) and q not in rec["name"].lower()):
                continue
            curr = self.hls_overrides.get(tid, rec["orig_buy"])
            tags = ("modified",) if is_mod else ()
            self.tree_hls.insert("", "end", iid=f"HLS:{tid}", values=(
                tid,
                rec["sub_tblidx"],
                rec["name"],
                atomic_to_xmr_str(rec["orig_buy"]),
                atomic_to_xmr_str(curr),
                "Modificado" if is_mod else "Original"
            ), tags=tags)

        self.tree_items.delete(*self.tree_items.get_children())
        shown = 0
        for rec in self.normal_items:
            tid = rec["tblidx"]
            is_mod = tid in self.item_overrides
            if only_mod and not is_mod:
                continue
            if q and (q not in str(tid) and q not in rec["name"].lower()):
                continue
            ov = self.item_overrides.get(tid)
            curr_buy = ov[0] if ov else rec["orig_buy"]
            curr_sell = ov[1] if (ov and ov[1] is not None) else 0
            tags = ("modified",) if is_mod else ()
            self.tree_items.insert("", "end", iid=f"ITEM:{tid}", values=(
                tid,
                rec["name"],
                atomic_to_xmr_str(rec["orig_buy"]),
                atomic_to_xmr_str(curr_buy),
                atomic_to_xmr_str(curr_sell),
                "Modificado" if is_mod else "Original"
            ), tags=tags)
            shown += 1
            if not q and not only_mod and shown >= 500:
                break

    def _on_select(self, kind: str):
        tree = self.tree_hls if kind == "HLS" else self.tree_items
        sel = tree.selection()
        if not sel:
            return
        iid = sel[0]
        tid = int(iid.split(":")[1])
        src = self.hls_items if kind == "HLS" else self.normal_items
        rec = next((r for r in src if r["tblidx"] == tid), None)
        if not rec:
            return
        self.selected_record = rec
        self.lbl_sel.config(text=f"[{kind}] ID {tid} - {rec['name']}")
        if kind == "HLS":
            curr = self.hls_overrides.get(tid, rec["orig_buy"])
            self.var_buy.set(atomic_to_xmr_str(curr))
            self.var_sell.set("")
            self.ent_sell.config(state="disabled")
        else:
            ov = self.item_overrides.get(tid)
            curr_buy = ov[0] if ov else rec["orig_buy"]
            curr_sell = ov[1] if (ov and ov[1] is not None) else 0
            self.ent_sell.config(state="normal")
            self.var_buy.set(atomic_to_xmr_str(curr_buy))
            self.var_sell.set(atomic_to_xmr_str(curr_sell))

    def _write_ini(self):
        os.makedirs(os.path.dirname(INI_PATH), exist_ok=True)
        lines = [
            "; =============================================================================",
            "; Precios personalizados del Servidor (OpenDBO)",
            "; Generado por PriceDashboard.py - GameServer recarga automaticamente cada 2s",
            "; =============================================================================",
            "",
            "[HLS_PRICES]",
        ]
        for tid in sorted(self.hls_overrides):
            lines.append(f"{tid} = {atomic_to_xmr_str(self.hls_overrides[tid])}")
        lines.append("")
        lines.append("[ITEM_PRICES]")
        for tid in sorted(self.item_overrides):
            buy_a, sell_a = self.item_overrides[tid]
            if sell_a is not None:
                lines.append(f"{tid} = {atomic_to_xmr_str(buy_a)}, {atomic_to_xmr_str(sell_a)}")
            else:
                lines.append(f"{tid} = {atomic_to_xmr_str(buy_a)}")
        lines.append("")
        with open(INI_PATH, "w", encoding="utf-8") as f:
            f.write("\n".join(lines))

    def apply_selected_price(self):
        if not self.selected_record:
            messagebox.showinfo("Sin seleccion", "Selecciona un item de la lista primero.")
            return
        rec = self.selected_record
        tid = rec["tblidx"]
        try:
            buy_a = xmr_str_to_atomic(self.var_buy.get())
            if rec["type"] == "HLS":
                self.hls_overrides[tid] = buy_a
            else:
                sell_txt = self.var_sell.get().strip()
                sell_a = xmr_str_to_atomic(sell_txt) if sell_txt else 0
                self.item_overrides[tid] = (buy_a, sell_a)
        except ValueError as err:
            messagebox.showerror("Precio invalido", str(err))
            return

        self._write_ini()
        self.refresh_tables()
        self.lbl_status.config(text=f"Guardado {rec['type']} {tid} -> GameServer aplicara en vivo (<2s)")

    def reset_selected_price(self):
        if not self.selected_record:
            return
        rec = self.selected_record
        tid = rec["tblidx"]
        if rec["type"] == "HLS":
            self.hls_overrides.pop(tid, None)
            self.var_buy.set(atomic_to_xmr_str(rec["orig_buy"]))
        else:
            self.item_overrides.pop(tid, None)
            self.var_buy.set(atomic_to_xmr_str(rec["orig_buy"]))
            self.var_sell.set(atomic_to_xmr_str(rec["orig_sell"]))
        self._write_ini()
        self.refresh_tables()
        self.lbl_status.config(text=f"Restaurado {rec['type']} {tid} al precio original")

    def _find_bridge_dir(self):
        candidates = [
            BASE_DIR,
            os.path.join(BASE_DIR, "..", "..", "..", "CryptoPoolBridge"),
            r"G:\serverlocal dbo pasar a C\CryptoPoolBridge",
        ]
        for d in candidates:
            norm = os.path.abspath(d)
            if os.path.isfile(os.path.join(norm, "config.json")) and os.path.isdir(os.path.join(norm, "node_modules")):
                return norm
        return None

    def _run_bridge_node(self, script: str, timeout: int = 12):
        bridge_dir = self._find_bridge_dir()
        if not bridge_dir:
            raise RuntimeError("No se encontro la carpeta CryptoPoolBridge con node_modules.")
        proc = subprocess.run(
            ["node", "-e", script],
            cwd=bridge_dir,
            capture_output=True,
            text=True,
            timeout=timeout,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        if proc.returncode != 0:
            raise RuntimeError((proc.stderr or proc.stdout or "Error ejecutando Node").strip())
        return proc.stdout.strip()

    def refresh_xmr_admin(self):
        script = (
            "const fs=require('fs'), mysql=require('mysql2/promise');"
            "(async()=>{"
            "const cfg=JSON.parse(fs.readFileSync('config.json','utf8'));"
            "const c=await mysql.createConnection({host:cfg.MYSQL.host,port:cfg.MYSQL.port||3306,user:cfg.MYSQL.user,password:cfg.MYSQL.password,database:cfg.MYSQL.database});"
            "const [wd]=await c.query('SELECT id,char_id,amount_units,address,status,COALESCE(tx_hash,error_msg,\"\") AS note,DATE_FORMAT(created_at,\"%Y-%m-%d %H:%i\") AS dt FROM xmr_withdrawals ORDER BY id DESC LIMIT 100');"
            "const [tl]=await c.query('SELECT source_type,COALESCE(SUM(CASE WHEN withdrawn=0 THEN fee_amount ELSE 0 END),0) AS pend,COALESCE(SUM(fee_amount),0) AS tot FROM treasury_ledger GROUP BY source_type');"
            "const [mq]=await c.query('SELECT status,COALESCE(SUM(net_amount),0) AS net FROM mining_rewards_queue GROUP BY status');"
            "console.log(JSON.stringify({wd,tl,mq}));"
            "await c.end();"
            "})().catch(e=>{console.error(e.message);process.exit(1);});"
        )
        try:
            raw = self._run_bridge_node(script)
            data = json.loads(raw)
        except Exception as err:
            messagebox.showerror("Error MySQL / Bridge", str(err))
            return

        for row_id in self.tree_xmr.get_children():
            self.tree_xmr.delete(row_id)

        for w in data.get("wd", []):
            amt_xmr = atomic_to_xmr_str(int(w["amount_units"]))
            addr = w["address"] or ""
            short_addr = addr if len(addr) <= 28 else f"{addr[:14]}...{addr[-10:]}"
            self.tree_xmr.insert("", "end", iid=str(w["id"]), values=(
                w["id"], w["char_id"], amt_xmr, short_addr, w["status"], w["note"], w["dt"]
            ))

        tl_parts = [f"{r['source_type']}: {atomic_to_xmr_str(int(float(r['pend'])))} pend." for r in data.get("tl", [])]
        mq_parts = [f"{r['status']}: {atomic_to_xmr_str(int(float(r['net'])))} XMR" for r in data.get("mq", [])]
        summary_txt = "Tesoreria -> " + (" | ".join(tl_parts) if tl_parts else "0") + "   ||   Cola -> " + (" | ".join(mq_parts) if mq_parts else "0")
        self.lbl_xmr_summary.config(text=summary_txt)
        self.lbl_status.config(text="Datos XMR actualizados desde MySQL")

    def approve_selected_withdrawal(self):
        sel = self.tree_xmr.selection()
        if not sel:
            messagebox.showinfo("Sin seleccion", "Selecciona un retiro en la tabla XMR.")
            return
        wid = int(sel[0])
        script = (
            "const fs=require('fs'), mysql=require('mysql2/promise');"
            f"(async()=>{{const cfg=JSON.parse(fs.readFileSync('config.json','utf8'));"
            "const c=await mysql.createConnection({host:cfg.MYSQL.host,port:cfg.MYSQL.port||3306,user:cfg.MYSQL.user,password:cfg.MYSQL.password,database:cfg.MYSQL.database});"
            f"const [r]=await c.execute(\"UPDATE xmr_withdrawals SET status='APPROVED_ADMIN', error_msg=NULL WHERE id=? AND status='WAITING_ADMIN'\",[{wid}]);"
            "console.log(r.affectedRows);await c.end();})().catch(e=>{console.error(e.message);process.exit(1);});"
        )
        try:
            changed = int(self._run_bridge_node(script) or "0")
            if changed == 0:
                messagebox.showinfo("Sin cambios", "Solo se pueden aprobar retiros en estado WAITING_ADMIN.")
            else:
                self.refresh_xmr_admin()
                self.lbl_status.config(text=f"Retiro #{wid} aprobado -> payout_worker lo procesara")
        except Exception as err:
            messagebox.showerror("Error aprobando retiro", str(err))

    def reject_selected_withdrawal(self):
        sel = self.tree_xmr.selection()
        if not sel:
            messagebox.showinfo("Sin seleccion", "Selecciona un retiro en la tabla XMR.")
            return
        wid = int(sel[0])
        if not messagebox.askyesno("Confirmar rechazo", f"Rechazar retiro #{wid} y devolver el saldo al jugador?"):
            return
        script = (
            "const fs=require('fs'), mysql=require('mysql2/promise');"
            "(async()=>{const cfg=JSON.parse(fs.readFileSync('config.json','utf8'));"
            "const c=await mysql.createConnection({host:cfg.MYSQL.host,port:cfg.MYSQL.port||3306,user:cfg.MYSQL.user,password:cfg.MYSQL.password,database:cfg.MYSQL.database});"
            "await c.beginTransaction();"
            f"const [rows]=await c.execute(\"SELECT char_id,amount_units,status FROM xmr_withdrawals WHERE id=? FOR UPDATE\",[{wid}]);"
            "if(!rows.length || !['PENDING','WAITING_ADMIN'].includes(rows[0].status)){await c.rollback();console.log(0);await c.end();return;}"
            f"await c.execute(\"UPDATE xmr_withdrawals SET status='FAILED', error_msg='Rejected by admin' WHERE id=?\",[{wid}]);"
            "await c.execute(\"INSERT INTO mining_rewards_queue (char_id,gross_amount,fee_amount,net_amount,shares,status,created_at) VALUES (?, ?, 0, ?, 0, 'PENDING', NOW())\",[rows[0].char_id,rows[0].amount_units,rows[0].amount_units]);"
            "await c.commit();console.log(1);await c.end();})().catch(e=>{console.error(e.message);process.exit(1);});"
        )
        try:
            changed = int(self._run_bridge_node(script) or "0")
            if changed == 0:
                messagebox.showinfo("Sin cambios", "Solo se pueden rechazar retiros PENDING o WAITING_ADMIN.")
            else:
                self.refresh_xmr_admin()
                self.lbl_status.config(text=f"Retiro #{wid} rechazado y saldo devuelto")
        except Exception as err:
            messagebox.showerror("Error rechazando retiro", str(err))

    def withdraw_treasury_rpc(self):
        if not messagebox.askyesno("Confirmar liquidacion RPC", "Enviar los fees pendientes (withdrawn=0) a FEE_TREASURY_WALLET via Monero RPC?"):
            return
        bridge_dir = self._find_bridge_dir()
        if not bridge_dir:
            messagebox.showerror("Error", "No se encontro CryptoPoolBridge.")
            return
        try:
            proc = subprocess.run(
                ["node", "treasury_cli.js", "withdraw-treasury", "--rpc"],
                cwd=bridge_dir,
                capture_output=True,
                text=True,
                timeout=20,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
            if proc.returncode != 0:
                raise RuntimeError((proc.stderr or proc.stdout).strip())
            messagebox.showinfo("Tesorería RPC", proc.stdout.strip() or "Completado")
            self.refresh_xmr_admin()
        except Exception as err:
            messagebox.showerror("Error RPC", str(err))


if __name__ == "__main__":
    root = tk.Tk()
    app = PriceDashboardApp(root)
    root.mainloop()
