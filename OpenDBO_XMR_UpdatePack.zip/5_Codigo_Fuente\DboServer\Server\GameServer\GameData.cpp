#include "stdafx.h"
#include "GameData.h"
#include "GameServer.h"
#include "CPlayer.h"
#include "ObjectManager.h"
#include "HLSItemTable.h"
#include "ItemTable.h"
#include <fstream>
#include <sstream>
#include <cmath>


CGameData::CGameData()
{
	Init();
}

CGameData::~CGameData()
{
	Destroy();
}


bool CGameData::Create(DWORD dwCodePage)
{
	CGameServer* app = (CGameServer*)g_pApp;

	NTL_PRINT(PRINT_APP, "Create Table Container");
	if (!m_tableContainer.CreateTableContainer(app->m_config.LoadTableFormat, (char*)app->m_config.TablePath.c_str()))
	{
		ERR_LOG(LOG_GENERAL, "CreateTableContainer == false");
		Destroy();
		return false;
	}

	if (app->IsDojoChannel() == false) //check if not dojo channel
	{
		NTL_PRINT(PRINT_APP, "Init Play Script Manager");
		if (!m_playScriptManager.Create(app->m_config.strPlayScriptPath.c_str(), CControlScriptManager::FILE_SCRIPT, "sps", "spe", "spc"))
		{
			ERR_LOG(LOG_GENERAL, "m_playScriptManager.Create == false");
			return false;
		}

		NTL_PRINT(PRINT_APP, "Init AI Script Manager");
		if (!m_AiScriptManager.Create(app->m_config.strAIScriptPath.c_str(), CControlScriptManager::FILE_SCRIPT, "ais", "aie", "aic"))
		{
			ERR_LOG(LOG_GENERAL, "m_AiScriptManager.Create == false");
			return false;
		}

		NTL_PRINT(PRINT_APP, "Init Time Quest Script Manager");
		if (!m_timeQuestScriptManager.Create(app->m_config.strTimeQuestScriptPath.c_str(), CControlScriptManager::FILE_SCRIPT, "tqs", "tqe", "tqc"))
		{
			ERR_LOG(LOG_GENERAL, "m_timeQuestScriptManager.Create == false");
			return false;
		}

		NTL_PRINT(PRINT_APP, "Init World Play Script Manager");
		if (!m_WorldPlayScriptManager.Create(app->m_config.strWorldPlayScriptPath.c_str(), CControlScriptManager::FILE_SCRIPT, "wps", "wpe", "wpc"))
		{
			ERR_LOG(LOG_GENERAL, "m_WorldPlayScriptManager.Create == false");
		}
	}

	ExportPriceCatalog();
	LoadAndApplyPriceOverrides();

	return true;
}


void CGameData::Destroy()
{
	m_tableContainer.Destroy();
	m_playScriptManager.Destroy();
	m_AiScriptManager.Destroy();
	m_timeQuestScriptManager.Destroy();
	m_WorldPlayScriptManager.Destroy();
}


void CGameData::Init()
{
	m_dwPriceWatchAccumMs = 0;
	ZeroMemory(&m_ftLastPricesWrite, sizeof(m_ftLastPricesWrite));
}

static std::string TrimPriceStr(const std::string& s)
{
	size_t start = s.find_first_not_of(" \t\r\n");
	if (start == std::string::npos)
		return "";
	size_t end = s.find_last_not_of(" \t\r\n");
	return s.substr(start, end - start + 1);
}

static DWORD XmrDoubleToAtomic(double dXmr)
{
	if (dXmr <= 0.0)
		return 0;
	long long llVal = llround(dXmr * 10000000000.0);
	if (llVal < 0)
		return 0;
	if (llVal > 4294967295LL)
		return 4294967295UL;
	return static_cast<DWORD>(llVal);
}

int CGameData::LoadAndApplyPriceOverrides()
{
	m_vecPendingBroadcastOverrides.clear();

	// 1. Restore any previously overridden prices so removed entries revert cleanly
	for (std::map<TBLIDX, DWORD>::const_iterator it = m_mapOrigHlsPrices.begin(); it != m_mapOrigHlsPrices.end(); ++it)
	{
		sHLS_ITEM_TBLDAT* pHls = (sHLS_ITEM_TBLDAT*)m_tableContainer.GetHLSItemTable()->FindData(it->first);
		if (pHls)
		{
			pHls->dwCash = it->second;
			sPRICE_OVERRIDE_ENTRY entry;
			entry.byType = 0;
			entry.tblidx = it->first;
			entry.dwPrice1 = it->second;
			entry.dwPrice2 = INVALID_DWORD;
			m_vecPendingBroadcastOverrides.push_back(entry);
		}
	}
	for (std::map<TBLIDX, std::pair<DWORD, DWORD>>::const_iterator it = m_mapOrigItemPrices.begin(); it != m_mapOrigItemPrices.end(); ++it)
	{
		sITEM_TBLDAT* pItem = (sITEM_TBLDAT*)m_tableContainer.GetItemTable()->FindData(it->first);
		if (pItem)
		{
			pItem->dwCost = it->second.first;
			pItem->dwSell_Price = it->second.second;
			sPRICE_OVERRIDE_ENTRY entry;
			entry.byType = 1;
			entry.tblidx = it->first;
			entry.dwPrice1 = it->second.first;
			entry.dwPrice2 = it->second.second;
			m_vecPendingBroadcastOverrides.push_back(entry);
		}
	}

	m_vecPriceOverrides.clear();

	std::ifstream ifs(".\\config\\item_prices.ini");
	if (!ifs.is_open())
		ifs.open("config\\item_prices.ini");
	if (!ifs.is_open())
		return 0;

	int nSection = 0; // 1 = HLS_PRICES, 2 = ITEM_PRICES
	std::string strLine;
	while (std::getline(ifs, strLine))
	{
		std::string s = TrimPriceStr(strLine);
		if (s.empty() || s[0] == ';' || s[0] == '#')
			continue;

		if (s[0] == '[')
		{
			if (s == "[HLS_PRICES]")
				nSection = 1;
			else if (s == "[ITEM_PRICES]")
				nSection = 2;
			else
				nSection = 0;
			continue;
		}

		size_t eqPos = s.find('=');
		if (eqPos == std::string::npos)
			continue;

		std::string strKey = TrimPriceStr(s.substr(0, eqPos));
		std::string strVal = TrimPriceStr(s.substr(eqPos + 1));
		if (strKey.empty() || strVal.empty())
			continue;

		TBLIDX tblidx = static_cast<TBLIDX>(strtoul(strKey.c_str(), NULL, 10));
		if (tblidx == 0 || tblidx == INVALID_TBLIDX)
			continue;

		if (nSection == 1)
		{
			sHLS_ITEM_TBLDAT* pHls = (sHLS_ITEM_TBLDAT*)m_tableContainer.GetHLSItemTable()->FindData(tblidx);
			if (!pHls)
				continue;

			if (m_mapOrigHlsPrices.find(tblidx) == m_mapOrigHlsPrices.end())
				m_mapOrigHlsPrices[tblidx] = pHls->dwCash;

			double dXmr = atof(strVal.c_str());
			DWORD dwNewCash = XmrDoubleToAtomic(dXmr);
			pHls->dwCash = dwNewCash;

			sPRICE_OVERRIDE_ENTRY entry;
			entry.byType = 0;
			entry.tblidx = tblidx;
			entry.dwPrice1 = dwNewCash;
			entry.dwPrice2 = INVALID_DWORD;
			m_vecPriceOverrides.push_back(entry);
			m_vecPendingBroadcastOverrides.push_back(entry);
		}
		else if (nSection == 2)
		{
			sITEM_TBLDAT* pItem = (sITEM_TBLDAT*)m_tableContainer.GetItemTable()->FindData(tblidx);
			if (!pItem)
				continue;

			if (m_mapOrigItemPrices.find(tblidx) == m_mapOrigItemPrices.end())
				m_mapOrigItemPrices[tblidx] = std::make_pair(pItem->dwCost, pItem->dwSell_Price);

			size_t commaPos = strVal.find(',');
			double dBuyXmr = atof((commaPos == std::string::npos ? strVal : TrimPriceStr(strVal.substr(0, commaPos))).c_str());
			DWORD dwNewCost = XmrDoubleToAtomic(dBuyXmr);
			DWORD dwNewSell = INVALID_DWORD;
			pItem->dwCost = dwNewCost;

			if (commaPos != std::string::npos)
			{
				std::string strSell = TrimPriceStr(strVal.substr(commaPos + 1));
				if (!strSell.empty())
				{
					dwNewSell = XmrDoubleToAtomic(atof(strSell.c_str()));
					pItem->dwSell_Price = dwNewSell;
				}
			}

			sPRICE_OVERRIDE_ENTRY entry;
			entry.byType = 1;
			entry.tblidx = tblidx;
			entry.dwPrice1 = dwNewCost;
			entry.dwPrice2 = dwNewSell;
			m_vecPriceOverrides.push_back(entry);
			m_vecPendingBroadcastOverrides.push_back(entry);
		}
	}

	NTL_PRINT(PRINT_APP, "Loaded %d price overrides from config\\item_prices.ini", static_cast<int>(m_vecPriceOverrides.size()));

	WIN32_FILE_ATTRIBUTE_DATA fad;
	if (GetFileAttributesExA(".\\config\\item_prices.ini", GetFileExInfoStandard, &fad))
		m_ftLastPricesWrite = fad.ftLastWriteTime;

	return static_cast<int>(m_vecPriceOverrides.size());
}

static std::string WideToUtf8Clean(const WCHAR* pwszText)
{
	if (!pwszText || pwszText[0] == L'\0')
		return "";
	char szBuf[256] = { 0 };
	int nLen = WideCharToMultiByte(CP_UTF8, 0, pwszText, -1, szBuf, sizeof(szBuf), NULL, NULL);
	if (nLen <= 0)
		return "";
	for (int i = 0; szBuf[i] != '\0'; ++i)
	{
		if (szBuf[i] == '\t' || szBuf[i] == '\r' || szBuf[i] == '\n')
			szBuf[i] = ' ';
	}
	return std::string(szBuf);
}

void CGameData::ExportPriceCatalog()
{
	std::ofstream ofs(".\\config\\price_catalog.tsv", std::ios::binary | std::ios::trunc);
	if (!ofs.is_open())
		return;

	ofs << "TYPE\tTBLIDX\tSUB_TBLIDX\tNAME\tORIG_BUY\tORIG_SELL\n";

	CHLSItemTable* pHlsTable = m_tableContainer.GetHLSItemTable();
	CItemTable* pItemTable = m_tableContainer.GetItemTable();

	if (pHlsTable)
	{
		for (CTable::TABLEIT it = pHlsTable->Begin(); it != pHlsTable->End(); ++it)
		{
			sHLS_ITEM_TBLDAT* pHls = (sHLS_ITEM_TBLDAT*)it->second;
			if (!pHls)
				continue;

			std::string strName = "HLS Item";
			if (pHls->tblidx == 2700142)
			{
				strName = "Licencia NiceHash";
			}
			else if (pItemTable)
			{
				sITEM_TBLDAT* pItem = (sITEM_TBLDAT*)pItemTable->FindData(pHls->itemTblidx);
				if (pItem)
				{
					std::string n = WideToUtf8Clean(pItem->wszNameText);
					if (!n.empty())
						strName = n;
				}
			}

			ofs << "HLS\t" << pHls->tblidx << "\t" << pHls->itemTblidx << "\t" << strName << "\t" << pHls->dwCash << "\t0\n";
		}
	}

	if (pItemTable)
	{
		for (CTable::TABLEIT it = pItemTable->Begin(); it != pItemTable->End(); ++it)
		{
			sITEM_TBLDAT* pItem = (sITEM_TBLDAT*)it->second;
			if (!pItem)
				continue;

			std::string strName = (pItem->tblidx == 2992003) ? "Licencia NiceHash" : WideToUtf8Clean(pItem->wszNameText);
			if (strName.empty())
				strName = "Item";

			ofs << "ITEM\t" << pItem->tblidx << "\t0\t" << strName << "\t" << pItem->dwCost << "\t" << pItem->dwSell_Price << "\n";
		}
	}
}

void CGameData::TickPriceWatcher(DWORD dwTickDiff)
{
	m_dwPriceWatchAccumMs += dwTickDiff;
	if (m_dwPriceWatchAccumMs < 2000)
		return;
	m_dwPriceWatchAccumMs = 0;

	WIN32_FILE_ATTRIBUTE_DATA fad;
	if (!GetFileAttributesExA(".\\config\\item_prices.ini", GetFileExInfoStandard, &fad))
		return;

	if (CompareFileTime(&fad.ftLastWriteTime, &m_ftLastPricesWrite) != 0)
	{
		LoadAndApplyPriceOverrides();
		BroadcastPriceOverrides();
	}
}

void CGameData::SendPriceOverridesToPlayer(CPlayer* pPlayer)
{
	if (!pPlayer || m_vecPriceOverrides.empty())
		return;

	size_t nTotal = m_vecPriceOverrides.size();
	for (size_t nOffset = 0; nOffset < nTotal; nOffset += NTL_MAX_PRICE_OVERRIDE_BATCH)
	{
		WORD wBatch = static_cast<WORD>((nTotal - nOffset > NTL_MAX_PRICE_OVERRIDE_BATCH) ? NTL_MAX_PRICE_OVERRIDE_BATCH : (nTotal - nOffset));
		CNtlPacket packet(sizeof(sGU_PRICE_OVERRIDES_NFY));
		sGU_PRICE_OVERRIDES_NFY* res = (sGU_PRICE_OVERRIDES_NFY*)packet.GetPacketData();
		res->wOpCode = GU_PRICE_OVERRIDES_NFY;
		res->wCount = wBatch;
		for (WORD i = 0; i < wBatch; ++i)
		{
			res->aEntries[i] = m_vecPriceOverrides[nOffset + i];
		}
		packet.SetPacketLen(sizeof(sGU_PRICE_OVERRIDES_NFY));
		g_pApp->Send(pPlayer->GetClientSessionID(), &packet);
	}
}

void CGameData::BroadcastPriceOverrides()
{
	const std::vector<sPRICE_OVERRIDE_ENTRY>& vec = m_vecPendingBroadcastOverrides.empty() ? m_vecPriceOverrides : m_vecPendingBroadcastOverrides;
	if (vec.empty())
		return;

	size_t nTotal = vec.size();
	for (size_t nOffset = 0; nOffset < nTotal; nOffset += NTL_MAX_PRICE_OVERRIDE_BATCH)
	{
		WORD wBatch = static_cast<WORD>((nTotal - nOffset > NTL_MAX_PRICE_OVERRIDE_BATCH) ? NTL_MAX_PRICE_OVERRIDE_BATCH : (nTotal - nOffset));
		CNtlPacket packet(sizeof(sGU_PRICE_OVERRIDES_NFY));
		sGU_PRICE_OVERRIDES_NFY* res = (sGU_PRICE_OVERRIDES_NFY*)packet.GetPacketData();
		res->wOpCode = GU_PRICE_OVERRIDES_NFY;
		res->wCount = wBatch;
		for (WORD i = 0; i < wBatch; ++i)
		{
			res->aEntries[i] = vec[nOffset + i];
		}
		packet.SetPacketLen(sizeof(sGU_PRICE_OVERRIDES_NFY));
		g_pObjectManager->SendPacketToAll(&packet);
	}

	m_vecPendingBroadcastOverrides.clear();
}
