-- =====================================================================
-- crypto_mining_schema.sql
--
-- PURPOSE:
--   Adds the crypto mining, rewards queue, treasury ledger, and config
--   tables to an EXISTING OpenDBO database (`dbo_acc` and `dbo_char`).
--   Safe to re-run (idempotent) on MySQL 5.7+.
--
-- USAGE:
--   mysql -u root -p < crypto_mining_schema.sql
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1. dbo_acc.accounts: add wallet_address column if it does not exist
--    Equivalent direct statement:
--      ALTER TABLE `dbo_acc`.`accounts`
--        ADD COLUMN `wallet_address` varchar(128) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL;
-- ---------------------------------------------------------------------
SET @wallet_col_exists := (
  SELECT COUNT(*)
  FROM `information_schema`.`COLUMNS`
  WHERE `TABLE_SCHEMA` = 'dbo_acc'
    AND `TABLE_NAME` = 'accounts'
    AND `COLUMN_NAME` = 'wallet_address'
);

SET @alter_accounts_sql := IF(
  @wallet_col_exists = 0,
  'ALTER TABLE `dbo_acc`.`accounts` ADD COLUMN `wallet_address` varchar(128) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL',
  'SELECT 1'
);

PREPARE stmt_alter_accounts FROM @alter_accounts_sql;
EXECUTE stmt_alter_accounts;
DEALLOCATE PREPARE stmt_alter_accounts;

-- ---------------------------------------------------------------------
-- 2. dbo_char.mining_rigs
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `dbo_char`.`mining_rigs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `char_id` int(10) unsigned NOT NULL,
  `slot_index` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `item_tblidx` int(10) unsigned NOT NULL,
  `max_cpu_threads` smallint(5) unsigned NOT NULL DEFAULT '1',
  `bonus_pct` decimal(5,2) unsigned NOT NULL DEFAULT '0.00',
  `durability_sec` int(10) unsigned NOT NULL DEFAULT '0',
  `is_active` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_char_slot` (`char_id`,`slot_index`) USING BTREE,
  KEY `idx_char_active` (`char_id`,`is_active`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ---------------------------------------------------------------------
-- 3. dbo_char.mining_rewards_queue
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `dbo_char`.`mining_rewards_queue` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `char_id` int(10) unsigned NOT NULL,
  `gross_amount` decimal(20,8) unsigned NOT NULL DEFAULT '0.00000000',
  `fee_amount` decimal(20,8) unsigned NOT NULL DEFAULT '0.00000000',
  `net_amount` decimal(20,8) unsigned NOT NULL DEFAULT '0.00000000',
  `shares` bigint(20) unsigned NOT NULL DEFAULT '0',
  `status` enum('PENDING','CLAIMED','FAILED') CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT 'PENDING',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `claimed_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_char_status` (`char_id`,`status`) USING BTREE,
  KEY `idx_status_created` (`status`,`created_at`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ---------------------------------------------------------------------
-- 4. dbo_char.treasury_ledger
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `dbo_char`.`treasury_ledger` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `source_type` enum('MINING_FEE','MARKET_TAX','NPC_TAX') CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `char_id` int(10) unsigned NOT NULL DEFAULT '0',
  `gross_amount` decimal(20,8) unsigned NOT NULL DEFAULT '0.00000000',
  `fee_amount` decimal(20,8) unsigned NOT NULL DEFAULT '0.00000000',
  `note` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `withdrawn` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_source_withdrawn` (`source_type`,`withdrawn`) USING BTREE,
  KEY `idx_char_created` (`char_id`,`created_at`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ---------------------------------------------------------------------
-- 5. dbo_char.crypto_config
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `dbo_char`.`crypto_config` (
  `config_key` varchar(64) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `config_value` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`config_key`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT IGNORE INTO `dbo_char`.`crypto_config` (`config_key`, `config_value`) VALUES
  ('CURRENCY_NAME', 'ZeniCoin'),
  ('CURRENCY_TICKER', 'ZNC'),
  ('FEE_MINING_PCT', '5'),
  ('FEE_MARKET_PCT', '5'),
  ('FEE_NPC_PCT', '5');
