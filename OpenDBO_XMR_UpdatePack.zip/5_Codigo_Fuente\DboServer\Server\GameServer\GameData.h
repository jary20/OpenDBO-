#ifndef __DBOG_GAME_DATA_H__
#define __DBOG_GAME_DATA_H__

#include "TableContainerManager.h"
#include "PlayScriptManager.h"
#include "AIScriptManager.h"
#include "TimeQuestScriptManager.h"
#include "WorldPlayScriptManager.h"
#include "NtlPacketGU.h"
#include <vector>
#include <map>

class CPlayer;



class CGameData
{

public:

	CGameData();
	virtual ~CGameData();

public:

	bool					Create(DWORD dwCodePage);

	void					Destroy();

	CTableContainerManager*	GetTableContainer() { return &m_tableContainer; }

	CPlayScriptManager*		GetPlayScriptManager() { return &m_playScriptManager; }

	CAIScriptManager*		GetAIScriptManager() { return &m_AiScriptManager; }

	int						LoadAndApplyPriceOverrides();
	void					ExportPriceCatalog();
	void					TickPriceWatcher(DWORD dwTickDiff);
	void					SendPriceOverridesToPlayer(CPlayer* pPlayer);
	void					BroadcastPriceOverrides();


protected:

	void					Init();


private:

	CTableContainerManager	m_tableContainer;

	CPlayScriptManager		m_playScriptManager;

	CAIScriptManager		m_AiScriptManager;

	CTimeQuestScriptManager	m_timeQuestScriptManager;

	CWorldPlayScriptManager	m_WorldPlayScriptManager;

	std::vector<sPRICE_OVERRIDE_ENTRY>			m_vecPriceOverrides;
	std::vector<sPRICE_OVERRIDE_ENTRY>			m_vecPendingBroadcastOverrides;
	std::map<TBLIDX, DWORD>						m_mapOrigHlsPrices;
	std::map<TBLIDX, std::pair<DWORD, DWORD>>	m_mapOrigItemPrices;
	DWORD										m_dwPriceWatchAccumMs;
	FILETIME									m_ftLastPricesWrite;

};

#endif
