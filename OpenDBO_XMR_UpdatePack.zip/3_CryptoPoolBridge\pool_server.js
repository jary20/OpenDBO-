'use strict';

const net = require('net');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const mysql = require('mysql2/promise');

const CONFIG_PATH = path.join(__dirname, 'config.json');
const config = JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'));

const JOB_ROTATION_MS = 30000;
const MAX_ACTIVE_JOBS = 10;

let dbPool = null;
let jobCounter = 0;
let sessionCounter = 0;
const activeJobs = new Map();
const sessions = new Set();

/**
 * Parse worker identifier formatted as "accountId_charId" (with optional ".rigName").
 * @param {string} rawWorker
 * @returns {{ accountId: number, charId: number, worker: string } | null}
 */
function parseWorkerId(rawWorker) {
  if (typeof rawWorker !== 'string') return null;
  const base = rawWorker.trim().split('.')[0];
  const match = /^(\d+)_(\d+)$/.exec(base);
  if (!match) return null;

  const accountId = Number(match[1]);
  const charId = Number(match[2]);
  if (!Number.isSafeInteger(accountId) || accountId <= 0) return null;
  if (!Number.isSafeInteger(charId) || charId <= 0) return null;

  return { accountId, charId, worker: rawWorker.trim() };
}

/**
 * Compute target hex string (8-char little-endian / prefix) for RandomX-style jobs.
 * @param {number} difficulty
 * @returns {string}
 */
function difficultyToTargetHex(difficulty) {
  const safeDiff = Math.max(1, Number(difficulty) || 1);
  const maxTarget = 0xffffffff;
  const targetVal = Math.max(1, Math.floor(maxTarget / safeDiff));
  const buf = Buffer.alloc(4);
  buf.writeUInt32LE(targetVal, 0);
  return buf.toString('hex');
}

/**
 * Create and register a new mining job.
 * @returns {{ job_id: string, blob: string, target: string, seed_hash: string, height: number, createdAt: number }}
 */
function createJob() {
  jobCounter += 1;
  const jobId = `job_${jobCounter}_${crypto.randomBytes(4).toString('hex')}`;
  const blob = crypto.randomBytes(76).toString('hex');
  const seedHash = crypto.createHash('sha256').update(`ZNC_RX_SEED_${Math.floor(jobCounter / 64)}`).digest('hex');
  const job = {
    job_id: jobId,
    blob,
    target: difficultyToTargetHex(config.SHARE_DIFFICULTY),
    seed_hash: seedHash,
    height: jobCounter,
    createdAt: Date.now()
  };

  activeJobs.set(jobId, job);
  if (activeJobs.size > MAX_ACTIVE_JOBS) {
    const oldestKey = activeJobs.keys().next().value;
    activeJobs.delete(oldestKey);
  }
  return job;
}

/**
 * Validate a submitted RandomX / test-mode share.
 * Accepts shares whose result hash meets either the configured TEST_TARGET_PREFIX
 * or the 32-bit difficulty target.
 * @param {object} job
 * @param {string} nonce
 * @param {string} resultHex
 * @returns {boolean}
 */
function validateSharePow(job, nonce, resultHex) {
  if (typeof nonce !== 'string' || !/^[0-9a-fA-F]{4,16}$/.test(nonce)) {
    return false;
  }
  if (typeof resultHex !== 'string' || !/^[0-9a-fA-F]{64}$/.test(resultHex)) {
    return false;
  }

  const normalized = resultHex.toLowerCase();
  const prefix = (config.TEST_TARGET_PREFIX || '000').toLowerCase();
  if (normalized.startsWith(prefix)) {
    return true;
  }

  // Fallback: check 32-bit tail value against difficulty target (CryptoNote little-endian convention)
  const tailVal = Buffer.from(normalized.slice(56, 64), 'hex').readUInt32LE(0);
  const targetVal = Buffer.from(job.target, 'hex').readUInt32LE(0);
  return tailVal <= targetVal;
}

/**
 * Record an accepted share in MySQL:
 * - Deduct FEE_MINING_PCT into dbo_char.treasury_ledger (MINING_FEE)
 * - Insert net ZNC reward into dbo_char.mining_rewards_queue (PENDING)
 * @param {number} charId
 * @returns {Promise<{ grossAmount: number, feeAmount: number, netAmount: number }>}
 */
async function recordShareReward(charId) {
  const grossAmount = Number(config.REWARD_PER_SHARE) || 100;
  const feePct = Number(config.FEE_MINING_PCT) || 5;
  const feeAmount = Math.floor((grossAmount * feePct) / 100);
  const netAmount = grossAmount - feeAmount;

  if (!dbPool) {
    throw new Error('MySQL pool is not initialized');
  }

  const conn = await dbPool.getConnection();
  try {
    await conn.beginTransaction();

    await conn.execute(
      `INSERT INTO treasury_ledger (source_type, char_id, gross_amount, fee_amount, created_at, withdrawn)
       VALUES ('MINING_FEE', ?, ?, ?, NOW(), 0)`,
      [charId, grossAmount, feeAmount]
    );

    await conn.execute(
      `INSERT INTO mining_rewards_queue (char_id, gross_amount, fee_amount, net_amount, shares, status, created_at)
       VALUES (?, ?, ?, ?, 1, 'PENDING', NOW())`,
      [charId, grossAmount, feeAmount, netAmount]
    );

    await conn.commit();
    return { grossAmount, feeAmount, netAmount };
  } catch (err) {
    await conn.rollback();
    throw err;
  } finally {
    conn.release();
  }
}

/**
 * Write a JSON-RPC message over a TCP socket.
 * @param {net.Socket} socket
 * @param {object} payload
 */
function sendJson(socket, payload) {
  if (!socket.destroyed) {
    socket.write(`${JSON.stringify(payload)}\n`);
  }
}

/**
 * Format a Stratum error response.
 * @param {number|string|null} id
 * @param {number} code
 * @param {string} message
 */
function sendError(socket, id, code, message) {
  sendJson(socket, {
    id: id !== undefined ? id : null,
    jsonrpc: '2.0',
    result: null,
    error: { code, message }
  });
}

/**
 * Authorize a Stratum session with worker = accountId_charId.
 * @param {object} session
 * @param {string} rawWorker
 * @returns {boolean}
 */
async function authorizeSession(session, rawWorker) {
  const parsed = parseWorkerId(rawWorker);
  if (parsed) {
    session.authorized = true;
    session.accountId = parsed.accountId;
    session.charId = parsed.charId;
    session.worker = parsed.worker;
    return true;
  }

  if (typeof rawWorker === 'string') {
    const base = rawWorker.trim().split('.')[0];
    const nameMatch = /^name_(.+)$/i.exec(base);
    if (nameMatch && dbPool) {
      const charName = nameMatch[1];
      const [rows] = await dbPool.query(
        'SELECT id, account_id FROM characters WHERE char_name = ? LIMIT 1',
        [charName]
      );
      if (rows.length > 0) {
        session.authorized = true;
        session.accountId = Number(rows[0].account_id) || 0;
        session.charId = Number(rows[0].id);
        session.worker = rawWorker.trim();
        return true;
      }
    }
  }
  return false;
}

/**
 * Process a single accepted/rejected share submission for both XMRig ("submit") and classic ("mining.submit").
 * @param {object} session
 * @param {number|string|null} id
 * @param {string} jobId
 * @param {string} nonce
 * @param {string} resultHex
 */
async function handleShareSubmission(session, id, jobId, nonce, resultHex) {
  if (!session.authorized) {
    sendError(session.socket, id, 24, 'Unauthorized worker');
    return;
  }

  const job = activeJobs.get(jobId);
  if (!job) {
    session.rejectedShares += 1;
    sendError(session.socket, id, 21, 'Job not found or stale');
    return;
  }

  const dedupeKey = `${jobId}:${nonce.toLowerCase()}`;
  if (session.submittedNonces.has(dedupeKey)) {
    session.rejectedShares += 1;
    sendError(session.socket, id, 22, 'Duplicate share');
    return;
  }

  if (!validateSharePow(job, nonce, resultHex)) {
    session.rejectedShares += 1;
    sendError(session.socket, id, 23, 'Low difficulty share');
    return;
  }

  session.submittedNonces.add(dedupeKey);

  try {
    const reward = await recordShareReward(session.charId);
    session.acceptedShares += 1;
    session.totalNetZnc += reward.netAmount;

    console.log(
      `[Pool] Share ACCEPTED | worker=${session.worker} | job=${jobId} | ` +
      `gross=${reward.grossAmount} fee=${reward.feeAmount} net=${reward.netAmount} ${config.CURRENCY_TICKER}`
    );

    sendJson(session.socket, {
      id,
      jsonrpc: '2.0',
      result: { status: 'OK' },
      error: null
    });
  } catch (err) {
    console.error(`[Pool] MySQL error recording share for char_id=${session.charId}:`, err.message);
    sendError(session.socket, id, 20, 'Internal pool database error');
  }
}

/**
 * Handle one parsed JSON-RPC request from a miner client.
 * @param {object} session
 * @param {object} msg
 */
async function handleStratumMessage(session, msg) {
  const { id, method, params } = msg;

  switch (method) {
    case 'mining.subscribe': {
      sendJson(session.socket, {
        id,
        jsonrpc: '2.0',
        result: [[['mining.notify', session.id]], session.extranonce1, 4],
        error: null
      });
      break;
    }

    case 'mining.authorize': {
      const rawWorker = Array.isArray(params) ? params[0] : '';
      if (!(await authorizeSession(session, rawWorker))) {
        sendError(session.socket, id, 24, 'Invalid worker format; expected accountId_charId');
        return;
      }
      console.log(`[Pool] Worker authorized (Stratum v1): ${session.worker}`);
      sendJson(session.socket, { id, jsonrpc: '2.0', result: true, error: null });

      const job = createJob();
      sendJson(session.socket, {
        id: null,
        jsonrpc: '2.0',
        method: 'mining.notify',
        params: [job.job_id, job.blob, job.target, job.seed_hash, true]
      });
      break;
    }

    case 'login': {
      const rawWorker = params && typeof params.login === 'string' ? params.login : '';
      if (!(await authorizeSession(session, rawWorker))) {
        sendError(session.socket, id, 24, 'Invalid login; expected accountId_charId');
        return;
      }
      console.log(`[Pool] Worker logged in (RandomX): ${session.worker}`);
      const job = createJob();
      sendJson(session.socket, {
        id,
        jsonrpc: '2.0',
        result: {
          id: session.id,
          job: {
            job_id: job.job_id,
            blob: job.blob,
            target: job.target,
            seed_hash: job.seed_hash,
            height: job.height,
            algo: 'rx/0'
          },
          status: 'OK'
        },
        error: null
      });
      break;
    }

    case 'submit': {
      const jobId = params && params.job_id;
      const nonce = params && params.nonce;
      const resultHex = params && params.result;
      await handleShareSubmission(session, id, jobId, nonce, resultHex);
      break;
    }

    case 'mining.submit': {
      const jobId = Array.isArray(params) ? params[1] : '';
      const nonce = Array.isArray(params) ? params[2] : '';
      const resultHex = Array.isArray(params) ? params[3] : '';
      await handleShareSubmission(session, id, jobId, nonce, resultHex);
      break;
    }

    case 'keepalived': {
      sendJson(session.socket, {
        id,
        jsonrpc: '2.0',
        result: { status: 'KEEPALIVED' },
        error: null
      });
      break;
    }

    default: {
      sendError(session.socket, id, -32601, `Unknown method: ${method}`);
      break;
    }
  }
}

/**
 * Broadcast a fresh RandomX job to all authorized connected sessions.
 */
function broadcastNewJob() {
  if (sessions.size === 0) return;
  const job = createJob();

  for (const session of sessions) {
    if (!session.authorized || session.socket.destroyed) continue;
    sendJson(session.socket, {
      id: null,
      jsonrpc: '2.0',
      method: 'job',
      params: {
        job_id: job.job_id,
        blob: job.blob,
        target: job.target,
        seed_hash: job.seed_hash,
        height: job.height,
        algo: 'rx/0'
      }
    });
  }
}

async function startServer() {
  dbPool = mysql.createPool({
    host: config.MYSQL.host,
    port: config.MYSQL.port || 3306,
    user: config.MYSQL.user,
    password: config.MYSQL.password,
    database: config.MYSQL.database,
    waitForConnections: true,
    connectionLimit: config.MYSQL.connectionLimit || 10
  });

  try {
    const conn = await dbPool.getConnection();
    await conn.ping();
    conn.release();
    console.log(`[Pool] Connected to MySQL (${config.MYSQL.host}:${config.MYSQL.port || 3306}/${config.MYSQL.database})`);
  } catch (err) {
    console.warn(`[Pool] Warning: MySQL not reachable at startup (${err.message}). Shares will fail until MySQL is online.`);
  }

  createJob();

  const server = net.createServer((socket) => {
    sessionCounter += 1;
    const session = {
      id: `sess_${sessionCounter}`,
      extranonce1: crypto.randomBytes(4).toString('hex'),
      socket,
      authorized: false,
      accountId: 0,
      charId: 0,
      worker: '',
      acceptedShares: 0,
      rejectedShares: 0,
      totalNetZnc: 0,
      submittedNonces: new Set()
    };

    sessions.add(session);
    socket.setEncoding('utf8');

    let buffer = '';
    socket.on('data', (chunk) => {
      buffer += chunk;
      let newlineIdx;
      while ((newlineIdx = buffer.indexOf('\n')) !== -1) {
        const line = buffer.slice(0, newlineIdx).trim();
        buffer = buffer.slice(newlineIdx + 1);
        if (!line) continue;

        let msg;
        try {
          msg = JSON.parse(line);
        } catch (_err) {
          sendError(socket, null, -32700, 'Parse error');
          continue;
        }

        handleStratumMessage(session, msg).catch((err) => {
          console.error('[Pool] Unhandled message error:', err);
        });
      }
    });

    socket.on('close', () => {
      sessions.delete(session);
      if (session.worker) {
        console.log(
          `[Pool] Disconnected: ${session.worker} ` +
          `(accepted=${session.acceptedShares}, rejected=${session.rejectedShares}, net=${session.totalNetZnc} ${config.CURRENCY_TICKER})`
        );
      }
    });

    socket.on('error', (err) => {
      console.warn(`[Pool] Socket error (${session.id}): ${err.message}`);
    });
  });

  const jobTimer = setInterval(broadcastNewJob, JOB_ROTATION_MS);

  server.listen(config.STRATUM_PORT, config.STRATUM_HOST || '0.0.0.0', () => {
    console.log(
      `[Pool] ${config.CURRENCY_NAME} (${config.CURRENCY_TICKER}) RandomX Stratum v1 listening on ` +
      `${config.STRATUM_HOST || '0.0.0.0'}:${config.STRATUM_PORT} | Fee=${config.FEE_MINING_PCT}%`
    );
  });

  const shutdown = async () => {
    console.log('\n[Pool] Shutting down...');
    clearInterval(jobTimer);
    server.close();
    for (const session of sessions) {
      session.socket.destroy();
    }
    if (dbPool) {
      await dbPool.end();
    }
    process.exit(0);
  };

  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);
}

startServer().catch((err) => {
  console.error('[Pool] Fatal startup error:', err);
  process.exit(1);
});
