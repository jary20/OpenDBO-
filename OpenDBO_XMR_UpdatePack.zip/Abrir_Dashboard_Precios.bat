@echo off
cd /d "G:\serverlocal dbo pasar a C\OpenDBO-Core\DboServer\ExecutionEnv"
start "" pythonw PriceDashboard.py
