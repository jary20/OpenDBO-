@echo off
title OpenDBO XMR - Instalador Plug and Play
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0instalar_actualizacion.ps1"
pause
