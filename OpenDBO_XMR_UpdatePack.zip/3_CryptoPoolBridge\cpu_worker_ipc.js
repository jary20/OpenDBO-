'use strict';

const net = require('net');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { spawn, execSync } = require('child_process');
const { Worker } = require('worker_threads');
const mysql = require('mysql2/promise');
const nicehash = require('./nicehash_client');

const CONFIG_PATH = path.join(__dirname, 'config.json');
let config = JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'));
const dbPool = mysql.createPool(config.MYSQL);

function reloadConfig() {
  try {
    config = JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'));
  } catch (err) {
    console.warn(`[WorkerIPC] Failed to reload config.json: ${err.message}`);
  }
}

const PIPE_PATH = config.NAMED_PIPE_PATH || '\\\\.\\pipe\\DBO_RandomX_Miner';
const MAX_CPUS = 16;

const state = {
  running: false,
  mode: 'idle', // 'idle' | 'xmrig' | 'builtin_test'
  threads: 0,
  workerId: '',
  hashrate: 0,
  acceptedShares: 0,
  rejectedShares: 0,
  persistedShares: 0,
  persistedMined: 0,
  resolvedCharId: 0,
  xmrigProc: null,
  stratumSocket: null,
  testWorkers: [],
  currentJob: null,
  rpcSeq: 1,
  pendingSubmits: new Map(),
  hashCounts: new Map(),
  nicehash: {
    active: false,
    orderId: '',
    speed: '0',
    status: 'IDLE'
  }
};

/**
 * Resolve xmrig.exe path if available locally or in system PATH.
 * @returns {string | null}
 */
function findXmrigBinary() {
  const configured = config.XMRIG_PATH || 'xmrig.exe';
  const localPath = path.isAbsolute(configured)
    ? configured
    : path.resolve(__dirname, configured);

  if (fs.existsSync(localPath)) {
    return localPath;
  }

  try {
    const out = execSync(`where ${configured}`, { stdio: ['ignore', 'pipe', 'ignore'] })
      .toString('utf8')
      .trim()
      .split(/\r?\n/)[0];
    if (out && fs.existsSync(out)) {
      return out;
    }
  } catch (_err) {
    // xmrig.exe not found in PATH; fall back to built-in test mode
  }
  return null;
}

/**
 * Stop any active miner process, built-in worker threads, and Stratum socket.
 */
async function stopMining() {
  state.running = false;
  state.mode = 'idle';
  state.hashrate = 0;

  if (state.xmrigProc) {
    try {
      state.xmrigProc.kill('SIGTERM');
    } catch (_err) {
      // Ignore already-exited process
    }
    state.xmrigProc = null;
  }

  if (state.testWorkers.length > 0) {
    const terminations = state.testWorkers.map((w) => w.terminate().catch(() => {}));
    state.testWorkers = [];
    await Promise.all(terminations);
  }

  if (state.stratumSocket) {
    state.stratumSocket.destroy();
    state.stratumSocket = null;
  }

  state.currentJob = null;
  state.pendingSubmits.clear();
  state.hashCounts.clear();
}

/**
 * Resolve real DB char_id from workerId ("name_<charName>" or "dbo_<charId>").
 * @param {string} workerId
 * @returns {Promise<number>}
 */
async function resolveCharId(workerId) {
  const s = String(workerId || '').trim();
  const nameMatch = /^name_(.+)$/i.exec(s);
  if (nameMatch) {
    try {
      const [rows] = await dbPool.query(
        'SELECT id FROM characters WHERE char_name = ? LIMIT 1',
        [nameMatch[1]]
      );
      if (rows.length > 0) {
        return Number(rows[0].id) || 0;
      }
    } catch (err) {
      console.error('[WorkerIPC] Failed to resolve char_name:', err.message);
    }
  }
  const charIdMatch = s.match(/(\d+)$/);
  return charIdMatch ? parseInt(charIdMatch[1], 10) : 0;
}

/**
 * Load cumulative shares and mined amount from MySQL for the character.
 * @param {string} workerId
 */
async function loadPersistedStats(workerId) {
  const charId = await resolveCharId(workerId);
  state.resolvedCharId = charId;
  if (!Number.isSafeInteger(charId) || charId <= 0) {
    state.persistedShares = 0;
    state.persistedMined = 0;
    return;
  }
  try {
    const [rows] = await dbPool.query(
      'SELECT COALESCE(SUM(shares), 0) AS shares, COALESCE(SUM(net_amount), 0) AS net FROM mining_rewards_queue WHERE char_id = ?',
      [charId]
    );
    state.persistedShares = Number(rows[0]?.shares) || 0;
    state.persistedMined = Math.floor(Number(rows[0]?.net) || 0);
  } catch (err) {
    console.error('[WorkerIPC] Failed to load persisted mining stats:', err.message);
  }
}

const networkStats = {
  difficulty: 801238592255,
  rewardPiconeros: 620139700000,
  lastFetchMs: 0
};

async function getNetworkStats() {
  const now = Date.now();
  if (now - networkStats.lastFetchMs < 5 * 60 * 1000) {
    return networkStats;
  }
  try {
    const res = await fetch('https://supportxmr.com/api/network/stats', {
      signal: AbortSignal.timeout(3000)
    });
    if (res.ok) {
      const data = await res.json();
      if (Number(data.difficulty) > 0 && Number(data.value) > 0) {
        networkStats.difficulty = Number(data.difficulty);
        networkStats.rewardPiconeros = Number(data.value);
        networkStats.lastFetchMs = now;
      }
    }
  } catch (err) {
    // Keep cached/fallback network difficulty on transient fetch errors
  }
  return networkStats;
}

/**
 * Credit one accepted XMRig share in MySQL (treasury_ledger + mining_rewards_queue).
 * @param {string} workerId
 * @param {number} shareDiff
 */
async function recordExternalShareReward(workerId, shareDiff = 0) {
  const charId = state.resolvedCharId > 0 ? state.resolvedCharId : await resolveCharId(workerId);
  if (!Number.isSafeInteger(charId) || charId <= 0) return;

  const baseReward = Math.max(1, Math.floor(Number(config.REWARD_PER_SHARE) || 2400));
  let grossAmount = baseReward;
  if (shareDiff > 0) {
    const netStats = await getNetworkStats();
    const blockRewardUnits = netStats.rewardPiconeros / 100; // 1 internal unit = 100 piconeros = 10^-10 XMR
    grossAmount = Math.max(1, Math.round((blockRewardUnits * shareDiff) / netStats.difficulty));
  }
  const feePct = Math.min(100, Math.max(0, Number(config.FEE_MINING_PCT) || 0));
  const feeAmount = Math.floor((grossAmount * feePct) / 100);
  const netAmount = Math.max(0, grossAmount - feeAmount);

  const conn = await dbPool.getConnection();
  try {
    await conn.beginTransaction();
    await conn.execute(
      `INSERT INTO treasury_ledger (source_type, char_id, gross_amount, fee_amount, created_at, withdrawn)
       VALUES ('MINING_FEE', ?, ?, ?, NOW(), 0)`,
      [charId, grossAmount, feeAmount]
    );
    await conn.execute(
      `INSERT INTO mining_rewards_queue (char_id, gross_amount, fee_amount, net_amount, shares, status, created_at)
       VALUES (?, ?, ?, ?, 1, 'PENDING', NOW())`,
      [charId, grossAmount, feeAmount, netAmount]
    );
    await conn.commit();
    console.log(
      `[WorkerIPC] External share ACCEPTED -> credited char_id=${charId} diff=${shareDiff} net=${netAmount} fee=${feeAmount} ${config.CURRENCY_TICKER}`
    );
  } catch (err) {
    await conn.rollback();
    console.error(`[WorkerIPC] MySQL error crediting external share for char_id=${charId}:`, err.message);
  } finally {
    conn.release();
  }
}

/**
 * Start external xmrig.exe process and parse its console output for hashrate & shares.
 * @param {string} xmrigBin
 * @param {number} threads
 * @param {string} workerId
 */
function startXmrigMode(xmrigBin, threads, workerId) {
  reloadConfig();
  state.running = true;
  state.mode = 'xmrig';
  state.threads = threads;
  state.workerId = workerId;
  state.hashrate = 0;
  state.acceptedShares = 0;
  state.rejectedShares = 0;

  const useExternalPool = Boolean(
    config.EXTERNAL_POOL_URL &&
    config.DEVELOPER_TREASURY_WALLET &&
    !/^0x0+DEAD$/i.test(config.DEVELOPER_TREASURY_WALLET)
  );
  const poolUrl = useExternalPool
    ? config.EXTERNAL_POOL_URL
    : `127.0.0.1:${config.STRATUM_PORT}`;
  const poolUser = useExternalPool
    ? config.DEVELOPER_TREASURY_WALLET
    : workerId;

  const args = [
    '-o', poolUrl,
    '-u', poolUser,
    '-p', 'x',
    '-t', String(threads),
    '--algo=rx/0',
    '--donate-level=0',
    '--cpu-priority=0',
    '--retries=999999',
    '--retry-pause=5',
    '--print-time=10',
    '--no-color'
  ];

  console.log(`[WorkerIPC] Spawning xmrig -> pool=${poolUrl} threads=${threads}`);
  const proc = spawn(xmrigBin, args, { stdio: ['ignore', 'pipe', 'pipe'] });
  state.xmrigProc = proc;

  const handleOutput = (chunk) => {
    const text = chunk.toString('utf8');
    for (const line of text.split(/\r?\n/)) {
      if (!line.trim()) continue;
      // Match XMRig speed line: "speed 10s/60s/15m 1234.5 ... H/s"
      const speedMatch = /speed\s+\S+\s+([0-9.]+)\s+/i.exec(line);
      if (speedMatch) {
        state.hashrate = Math.round(parseFloat(speedMatch[1]) || 0);
      }
      if (/accepted\s+\((\d+)\/(\d+)\)/i.test(line)) {
        const shareMatch = /accepted\s+\((\d+)\/(\d+)\)/i.exec(line);
        if (shareMatch) {
          const prevAccepted = state.acceptedShares;
          const nextAccepted = Number(shareMatch[1]) || state.acceptedShares;
          state.acceptedShares = nextAccepted;
          state.rejectedShares = Number(shareMatch[2]) || state.rejectedShares;
          if (useExternalPool && nextAccepted > prevAccepted) {
            const diffMatch = /diff\s+(\d+)/i.exec(line);
            const shareDiff = diffMatch ? (Number(diffMatch[1]) || 0) : 0;
            const delta = nextAccepted - prevAccepted;
            for (let i = 0; i < delta; i += 1) {
              recordExternalShareReward(workerId, shareDiff).catch(() => {});
            }
          }
        }
      }
      if (/error|use pool|new job|accepted|rejected/i.test(line)) {
        console.log(`[XMRig] ${line.trim()}`);
      }
    }
  };

  proc.stdout.on('data', handleOutput);
  proc.stderr.on('data', handleOutput);

  proc.on('exit', (code) => {
    console.log(`[WorkerIPC] xmrig.exe exited with code ${code}`);
    if (state.xmrigProc === proc) {
      state.xmrigProc = null;
      state.running = false;
      state.mode = 'idle';
      state.hashrate = 0;
    }
  });
}

const BUILTIN_WORKER_SCRIPT = `
const { parentPort, workerData } = require('worker_threads');
const crypto = require('crypto');

const { prefix, workerIndex } = workerData;
let currentJob = null;
let nonceCounter = workerIndex * 1000000;
let hashesSinceReport = 0;
let lastReport = Date.now();

parentPort.on('message', (msg) => {
  if (msg && msg.type === 'job') {
    currentJob = msg.job;
  }
});

function tick() {
  if (currentJob) {
    const batch = 250;
    for (let i = 0; i < batch; i++) {
      nonceCounter = (nonceCounter + 1) >>> 0;
      const nonceHex = nonceCounter.toString(16).padStart(8, '0');
      const digest = crypto
        .createHash('sha256')
        .update(currentJob.blob + ':' + nonceHex)
        .digest('hex');
      hashesSinceReport += 1;

      if (digest.startsWith(prefix)) {
        parentPort.postMessage({
          type: 'share',
          job_id: currentJob.job_id,
          nonce: nonceHex,
          result: digest
        });
      }
    }
  }

  const now = Date.now();
  if (now - lastReport >= 1000) {
    const elapsedSec = Math.max(0.001, (now - lastReport) / 1000);
    parentPort.postMessage({
      type: 'rate',
      workerIndex,
      hps: Math.round(hashesSinceReport / elapsedSec)
    });
    hashesSinceReport = 0;
    lastReport = now;
  }

  setImmediate(tick);
}

tick();
`;

/**
 * Start built-in RandomX-compatible CPU test miner when xmrig.exe is not present.
 * Connects to pool_server.js over Stratum and spawns Worker threads.
 * @param {number} threads
 * @param {string} workerId
 */
function startBuiltinTestMode(threads, workerId) {
  state.running = true;
  state.mode = 'builtin_test';
  state.threads = threads;
  state.workerId = workerId;
  state.hashrate = 0;
  state.acceptedShares = 0;
  state.rejectedShares = 0;
  state.hashCounts.clear();

  const targetPrefix = (config.TEST_TARGET_PREFIX || '000').toLowerCase();

  const socket = net.createConnection({
    host: '127.0.0.1',
    port: config.STRATUM_PORT
  });
  state.stratumSocket = socket;
  socket.setEncoding('utf8');

  const sendStratum = (payload) => {
    if (!socket.destroyed) {
      socket.write(`${JSON.stringify(payload)}\n`);
    }
  };

  const broadcastJobToWorkers = (job) => {
    state.currentJob = job;
    for (const w of state.testWorkers) {
      w.postMessage({ type: 'job', job });
    }
  };

  socket.on('connect', () => {
    console.log(`[WorkerIPC] Built-in test miner connected to Stratum 127.0.0.1:${config.STRATUM_PORT}`);
    const loginId = state.rpcSeq++;
    sendStratum({
      id: loginId,
      jsonrpc: '2.0',
      method: 'login',
      params: { login: workerId, pass: 'x', agent: 'DBO-CryptoPoolBridge/1.0' }
    });
  });

  let buf = '';
  socket.on('data', (chunk) => {
    buf += chunk;
    let idx;
    while ((idx = buf.indexOf('\n')) !== -1) {
      const line = buf.slice(0, idx).trim();
      buf = buf.slice(idx + 1);
      if (!line) continue;

      let msg;
      try {
        msg = JSON.parse(line);
      } catch (_err) {
        continue;
      }

      if (msg.result && msg.result.job) {
        broadcastJobToWorkers(msg.result.job);
      } else if (msg.method === 'job' && msg.params) {
        broadcastJobToWorkers(msg.params);
      } else if (msg.id && state.pendingSubmits.has(msg.id)) {
        state.pendingSubmits.delete(msg.id);
        if (msg.error) {
          state.rejectedShares += 1;
        } else {
          state.acceptedShares += 1;
        }
      }
    }
  });

  socket.on('error', (err) => {
    console.warn(`[WorkerIPC] Stratum socket error: ${err.message}`);
  });

  socket.on('close', () => {
    if (state.stratumSocket === socket && state.running) {
      console.warn('[WorkerIPC] Stratum connection closed.');
    }
  });

  for (let i = 0; i < threads; i++) {
    const worker = new Worker(BUILTIN_WORKER_SCRIPT, {
      eval: true,
      workerData: { prefix: targetPrefix, workerIndex: i + 1 }
    });

    worker.on('message', (msg) => {
      if (!state.running) return;

      if (msg.type === 'rate') {
        state.hashCounts.set(msg.workerIndex, msg.hps);
        let total = 0;
        for (const v of state.hashCounts.values()) total += v;
        state.hashrate = total;
      } else if (msg.type === 'share' && state.stratumSocket && !state.stratumSocket.destroyed) {
        const submitId = state.rpcSeq++;
        state.pendingSubmits.set(submitId, true);
        sendStratum({
          id: submitId,
          jsonrpc: '2.0',
          method: 'submit',
          params: {
            job_id: msg.job_id,
            nonce: msg.nonce,
            result: msg.result
          }
        });
      }
    });

    worker.on('error', (err) => {
      console.error(`[WorkerIPC] Worker thread error:`, err.message);
    });

    state.testWorkers.push(worker);
    if (state.currentJob) {
      worker.postMessage({ type: 'job', job: state.currentJob });
    }
  }
}

/**
 * Format current miner status as a single line for CMiningRigGui.
 * @returns {string}
 */
function formatStatusLine() {
  const grossPerShare = Math.max(1, Math.floor(Number(config.REWARD_PER_SHARE) || 100));
  const feePct = Math.min(100, Math.max(0, Number(config.FEE_MINING_PCT) || 0));
  const netPerShare = Math.max(0, grossPerShare - Math.floor((grossPerShare * feePct) / 100));
  const totalShares = state.persistedShares + state.acceptedShares;
  const totalMined = state.persistedMined + (state.acceptedShares * netPerShare);
  return `STATUS ${state.hashrate} ${totalShares} ${totalMined}`;
}

/**
 * Handle one IPC command line from the Named Pipe.
 * @param {string} rawLine
 * @returns {Promise<string>}
 */
async function handlePipeCommand(rawLine) {
  const parts = rawLine.trim().split(/\s+/);
  const cmd = (parts[0] || '').toUpperCase();

  switch (cmd) {
    case 'START': {
      const requestedThreads = parseInt(parts[1], 10);
      const workerId = parts[2] || '';
      if (!Number.isFinite(requestedThreads) || requestedThreads <= 0 || !workerId) {
        return 'ERR USAGE: START <threads> <worker_id>';
      }

      const threads = Math.min(Math.max(1, requestedThreads), MAX_CPUS);
      await stopMining();
      await loadPersistedStats(workerId);

      const xmrigBin = findXmrigBinary();
      if (xmrigBin) {
        startXmrigMode(xmrigBin, threads, workerId);
      } else {
        startBuiltinTestMode(threads, workerId);
      }

      console.log(`[WorkerIPC] Started miner: mode=${state.mode} threads=${threads} worker=${workerId}`);
      return `OK STARTED threads=${threads} worker=${workerId} mode=${state.mode}`;
    }

    case 'STOP': {
      await stopMining();
      console.log('[WorkerIPC] Stopped miner.');
      return 'OK STOPPED';
    }

    case 'STATUS': {
      return formatStatusLine();
    }

    case 'REPAIR': {
      const workerId = parts[1] || '';
      const repairCost = parseInt(parts[2], 10);
      if (!workerId || !Number.isFinite(repairCost) || repairCost <= 0) {
        return 'ERR USAGE: REPAIR <worker_id> <cost>';
      }
      const charIdMatch = workerId.match(/(\d+)$/);
      const charId = charIdMatch ? parseInt(charIdMatch[1], 10) : 0;
      try {
        await dbPool.query(
          `INSERT INTO treasury_ledger (source_type, char_id, gross_amount, fee_amount, notes)
           VALUES ('NPC_TAX', ?, ?, ?, ?)`,
          [charId, repairCost, repairCost, `Mining card 33% repair fee (${workerId})`]
        );
      } catch (err) {
        console.error('[WorkerIPC] Failed to log repair fee:', err.message);
      }
      console.log(`[WorkerIPC] Repair fee recorded: worker=${workerId} cost=${repairCost} ZNC`);
      return `OK REPAIRED cost=${repairCost}`;
    }

    case 'PING': {
      return 'PONG';
    }

    case 'NH_GET_CONFIG': {
      const cfg = nicehash.loadUserConfig();
      const apiKey = (cfg.apiKey && cfg.apiKey.trim()) ? cfg.apiKey.trim() : 'NONE';
      const orgId = (cfg.orgId && cfg.orgId.trim()) ? cfg.orgId.trim() : 'NONE';
      const poolId = (cfg.poolId && cfg.poolId.trim()) ? cfg.poolId.trim() : 'NONE';
      const hasSecret = (cfg.apiSecret && cfg.apiSecret.trim()) ? 1 : 0;
      return `NH_CONFIG ${apiKey} ${orgId} ${poolId} ${hasSecret}`;
    }

    case 'NH_SET_CONFIG': {
      const apiKey = (parts[1] || '').trim();
      const apiSecret = (parts[2] || '').trim();
      const orgId = (parts[3] || '').trim();
      const poolId = (parts[4] || '').trim();
      if (!apiKey || !apiSecret || !orgId || !poolId) {
        return 'ERR NH_CONFIG_FIELDS_REQUIRED';
      }
      const saved = nicehash.saveUserConfig({ apiKey, apiSecret, orgId, poolId });
      const configured = nicehash.isUserConfigReady(saved) ? 1 : 0;
      console.log(`[WorkerIPC] NiceHash user config saved (configured=${configured}).`);
      return `OK NH_CONFIG_SAVED ${configured}`;
    }

    case 'NH_STATUS': {
      const cfg = nicehash.loadUserConfig();
      const configured = nicehash.isUserConfigReady(cfg) ? 1 : 0;
      if (state.nicehash.active && state.nicehash.orderId && configured) {
        try {
          const order = await nicehash.getOrderStatus(cfg, state.nicehash.orderId);
          state.nicehash.status = (order && order.type && order.type.code) ? String(order.type.code) : (order.alive ? 'ACTIVE' : 'STOPPED');
          state.nicehash.speed = (order && order.acceptedCurrentSpeed !== undefined) ? String(order.acceptedCurrentSpeed) : '0';
          if (order && order.alive === false) {
            state.nicehash.active = false;
          }
        } catch (err) {
          state.nicehash.status = 'ERR';
        }
      }
      return `NH_STATUS ${configured} ${state.nicehash.active ? 1 : 0} ${state.nicehash.orderId || 'NONE'} ${state.nicehash.speed || '0'} ${state.nicehash.status || 'IDLE'}`;
    }

    case 'NH_START': {
      const cfg = nicehash.loadUserConfig();
      if (!nicehash.isUserConfigReady(cfg)) {
        return `ERR NH_NOT_CONFIGURED ${nicehash.USER_CONFIG_PATH}`;
      }
      if (state.nicehash.active && state.nicehash.orderId) {
        return `OK NH_STARTED ${state.nicehash.orderId}`;
      }
      try {
        const order = await nicehash.createRandomXOrder(cfg);
        state.nicehash.active = true;
        state.nicehash.orderId = (order && order.id) ? String(order.id) : 'UNKNOWN';
        state.nicehash.status = 'ACTIVE';
        state.nicehash.speed = '0';
        console.log(`[WorkerIPC] NiceHash order created: id=${state.nicehash.orderId}`);
        return `OK NH_STARTED ${state.nicehash.orderId}`;
      } catch (err) {
        return `ERR NH ${err.message}`;
      }
    }

    case 'NH_STOP': {
      if (!state.nicehash.active || !state.nicehash.orderId) {
        state.nicehash.active = false;
        state.nicehash.orderId = '';
        state.nicehash.status = 'IDLE';
        return 'OK NH_STOPPED';
      }
      const cfg = nicehash.loadUserConfig();
      try {
        await nicehash.cancelOrder(cfg, state.nicehash.orderId);
      } catch (err) {
        return `ERR NH ${err.message}`;
      }
      console.log(`[WorkerIPC] NiceHash order cancelled: id=${state.nicehash.orderId}`);
      state.nicehash.active = false;
      state.nicehash.orderId = '';
      state.nicehash.status = 'IDLE';
      state.nicehash.speed = '0';
      return 'OK NH_STOPPED';
    }

    default:
      return `ERR UNKNOWN_COMMAND ${cmd}`;
  }
}

function startPipeServer() {
  const server = net.createServer((socket) => {
    socket.setEncoding('utf8');
    let buffer = '';

    socket.on('data', (chunk) => {
      buffer += chunk;
      let idx;
      while ((idx = buffer.indexOf('\n')) !== -1) {
        const line = buffer.slice(0, idx).trim();
        buffer = buffer.slice(idx + 1);
        if (!line) continue;

        handlePipeCommand(line)
          .then((reply) => {
            if (!socket.destroyed) {
              socket.write(`${reply}\n`);
            }
          })
          .catch((err) => {
            if (!socket.destroyed) {
              socket.write(`ERR ${err.message}\n`);
            }
          });
      }
    });

    socket.on('error', (err) => {
      console.warn(`[WorkerIPC] Pipe client error: ${err.message}`);
    });
  });

  server.listen(PIPE_PATH, () => {
    const xmrigBin = findXmrigBinary();
    console.log(`[WorkerIPC] Named Pipe listening at ${PIPE_PATH}`);
    console.log(
      `[WorkerIPC] Miner backend: ${xmrigBin ? `xmrig (${xmrigBin})` : 'built-in RandomX-compatible test mode (xmrig.exe not found)'}`
    );
  });

  const shutdown = async () => {
    console.log('\n[WorkerIPC] Shutting down...');
    await stopMining();
    server.close();
    process.exit(0);
  };

  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);
}

startPipeServer();
